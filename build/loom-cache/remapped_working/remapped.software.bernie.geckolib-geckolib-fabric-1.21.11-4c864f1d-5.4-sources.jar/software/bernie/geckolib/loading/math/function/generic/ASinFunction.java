package software.bernie.geckolib.loading.math.function.generic;

import net.minecraft.util.math.MathHelper;
import software.bernie.geckolib.animation.state.ControllerState;
import software.bernie.geckolib.loading.math.MathValue;
import software.bernie.geckolib.loading.math.function.MathFunction;

/**
 * {@link MathFunction} value supplier
 *
 * <p>
 * <b>Contract:</b>
 * <br>
 * Returns the arc-sine of the input value angle, with the input angle converted to radians
 */
public final class ASinFunction extends MathFunction {
    private final MathValue value;

    public ASinFunction(MathValue... values) {
        super(values);

        this.value = values[0];
    }

    @Override
    public String getName() {
        return "math.asin";
    }

    @Override
    public double compute(ControllerState controllerState) {
        return Math.asin(this.value.get(controllerState) * MathHelper.RADIANS_PER_DEGREE);
    }

    @Override
    public int getMinArgs() {
        return 1;
    }

    @Override
    public MathValue[] getArgs() {
        return new MathValue[] {this.value};
    }
}
