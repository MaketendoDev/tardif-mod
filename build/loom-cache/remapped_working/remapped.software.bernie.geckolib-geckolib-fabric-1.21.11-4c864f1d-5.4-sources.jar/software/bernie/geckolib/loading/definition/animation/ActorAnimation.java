package software.bernie.geckolib.loading.definition.animation;

import com.google.gson.*;
import com.mojang.datafixers.util.Either;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.util.JsonUtil;

import java.util.Map;
import net.minecraft.util.JsonHelper;

/**
 * Container class for a single actor animation, only used for intermediary steps between .json deserialization and GeckoLib object creation
 * <p>
 * Note that the name of the animation isn't contained here, and is instead held by the {@link ActorAnimations#animations()} map
 *
 * @param animLength The defined length (in seconds) of the animation. Defaults to the time of the last keyframe, but can be overridden manually
 * @param loop The loop type for this animation, or just a true/false for default looping or non-looping
 * @param startDelay The optional delay (in Molang-seconds) before starting this animation. Not used by GeckoLib
 * @param loopDelay The optional delay (in Molang-seconds) between the end of the animation, and when it loops, if a loop is required. Not used by GeckoLib
 * @param animTimeUpdate The optional expression (in Molang-seconds) defining how to evaluate the current animation time. Not used by GeckoLib
 * @param blendWeight The weight value defining this animation's interpolation relationship to another conflicting animation. Not used by GeckoLib
 * @param overridePrevAnimation An optional toggle to force this animation to animate as absolute, and not additive to another conflicting animation. Not used by GeckoLib
 * @param boneAnimations The bone animation map for this animation, defining the actual animation itself
 * @param particleEffects The defined particle effects track keyframe markers for this animation
 * @param soundEffects The defined sound effects track keyframe markers for this animation
 * @param timeline The defined custom instruction track keyframe markers for this animation
 * @see <a href="https://learn.microsoft.com/en-us/minecraft/creator/reference/content/schemasreference/schemas/minecraftschema_actor_animation_1.8.0?view=minecraft-bedrock-stable">Bedrock Actor Animation Spec 1.8.0</a>
 */
@ApiStatus.Internal
public record ActorAnimation(@Nullable Float animLength, @Nullable Either<Boolean, String> loop, @Nullable String startDelay, @Nullable String loopDelay, @Nullable String animTimeUpdate,
                             @Nullable String blendWeight, @Nullable Boolean overridePrevAnimation, @Nullable Map<String, ActorBoneAnimation> boneAnimations,
                             @Nullable Map<String, ActorAnimationParticleEffect> particleEffects, @Nullable Map<String, ActorAnimationSoundEffect> soundEffects, @Nullable Map<String, String> timeline) {
    /**
     * Parse an ActorAnimation instance from raw .json input via {@link Gson}
     */
    public static JsonDeserializer<ActorAnimation> gsonDeserializer() throws JsonParseException {
        return (json, type, context) -> {
            final JsonObject obj = json.getAsJsonObject();
            final Float animLength = JsonUtil.getOptionalFloat(obj, "animation_length");
            final Either<Boolean, String> loop = !obj.has("loop") || !(obj.get("loop") instanceof JsonPrimitive primitive) ? null : primitive.isBoolean() ?
                                                                           Either.left(primitive.getAsBoolean()) :
                                                                           Either.right(primitive.getAsString());
            final String startDelay = JsonHelper.getString(obj, "start_delay", null);
            final String loopDelay = JsonHelper.getString(obj, "loop_delay", null);
            final String animTimeUpdate = JsonHelper.getString(obj, "anim_time_update", null);
            final String blendWeight = JsonHelper.getString(obj, "blend_weight", null);
            final Boolean overridePrevAnimation = JsonUtil.getOptionalBoolean(obj, "override_previous_animation");
            final Map<String, ActorBoneAnimation> boneAnimations = JsonUtil.jsonObjToMap(JsonHelper.getObject(obj, "bones", null), context, ActorBoneAnimation.class);
            final Map<String, ActorAnimationParticleEffect> particleEffects = JsonUtil.jsonObjToMap(JsonHelper.getObject(obj, "particle_effects", null), context, ActorAnimationParticleEffect.class);
            final Map<String, ActorAnimationSoundEffect> soundEffects = JsonUtil.jsonObjToMap(JsonHelper.getObject(obj, "sound_effects", null), context, ActorAnimationSoundEffect.class);
            final Map<String, String> timeline = JsonUtil.jsonObjToPrimitiveMap(JsonHelper.getObject(obj, "timeline", null), context, JsonElement::getAsString);

            return new ActorAnimation(animLength, loop, startDelay, loopDelay, animTimeUpdate, blendWeight, overridePrevAnimation, boneAnimations, particleEffects, soundEffects, timeline);
        };
    }
}
