package software.bernie.geckolib.renderer.layer.builtin;

import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.GeckoLibClientServices;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animation.state.BoneSnapshot;
import software.bernie.geckolib.cache.model.GeoBone;
import software.bernie.geckolib.cache.model.cuboid.CuboidGeoBone;
import software.bernie.geckolib.cache.model.cuboid.GeoCube;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.constant.dataticket.DataTicket;
import software.bernie.geckolib.renderer.GeoArmorRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;
import software.bernie.geckolib.renderer.base.GeoRenderer;
import software.bernie.geckolib.renderer.base.PerBoneRender;
import software.bernie.geckolib.renderer.base.RenderPassInfo;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;
import software.bernie.geckolib.service.GeckoLibClient;
import software.bernie.geckolib.util.RenderStateUtil;
import software.bernie.geckolib.util.RenderUtil;

import java.util.EnumMap;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.SkullBlock;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPart.Cuboid;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.block.entity.SkullBlockEntityModel;
import net.minecraft.client.render.block.entity.SkullBlockEntityRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.equipment.EquipmentModelLoader;
import net.minecraft.client.render.entity.equipment.EquipmentRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.ElytraEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.texture.PlayerSkinCache;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;

/**
 * Builtin class for handling dynamic armor rendering on GeckoLib entities
 * <p>
 * Supports both {@link GeoItem GeckoLib} and vanilla armor models
 * <p>
 * Unlike a traditional armor renderer, this renderer renders per-bone, giving much more flexible armor rendering
 *
 * @param <T> Animatable class type. Inherited from the renderer this layer is attached to
 * @param <O> Associated object class type, or {@link Void} if none. Inherited from the renderer this layer is attached to
 * @param <R> RenderState class type. Inherited from the renderer this layer is attached to
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public abstract class ItemArmorGeoLayer<T extends LivingEntity & GeoAnimatable, O, R extends EntityRenderState & GeoRenderState> extends GeoRenderLayer<T, O, R> {
	protected final EquipmentRenderer equipmentRenderer;
	protected final EquipmentModelLoader equipmentAssets;
	protected final Function<SkullBlock.SkullType, @Nullable SkullBlockEntityModel> skullModels;
    protected final PlayerSkinCache skinCache;

	public ItemArmorGeoLayer(GeoRenderer<T, O, R> geoRenderer, EntityRendererFactory.Context context) {
		super(geoRenderer);

		this.equipmentRenderer = context.getEquipmentRenderer();
		this.equipmentAssets = context.getEquipmentModelLoader();
		this.skullModels = Util.memoize(type -> SkullBlockEntityRenderer.getModels(context.getEntityModels(), type));
        this.skinCache = context.getPlayerSkinCache();
	}

	/**
	 * Return a list of the bone names that this layer will render for.
	 * <p>
	 * Ideally, you would cache this list in a static field if you don't need any data from the input renderState or model
	 */
	protected abstract List<RenderData> getRelevantBones(RenderPassInfo<R> renderPassInfo);

	/**
	 * Container for data needed to render an armor piece for a bone.
	 *
	 * @param boneName The name of the bone to render the armor piece for
	 * @param armorSegment The armor segment to render
	 */
	public record RenderData(String boneName, GeoArmorRenderer.ArmorSegment armorSegment) {
		public static RenderData head(String boneName) {
			return new RenderData(boneName, GeoArmorRenderer.ArmorSegment.HEAD);
		}

		public static RenderData body(String boneName) {
			return new RenderData(boneName, GeoArmorRenderer.ArmorSegment.CHEST);
		}

		public static RenderData leftArm(String boneName) {
			return new RenderData(boneName, GeoArmorRenderer.ArmorSegment.LEFT_ARM);
		}

		public static RenderData rightArm(String boneName) {
			return new RenderData(boneName, GeoArmorRenderer.ArmorSegment.RIGHT_ARM);
		}

		public static RenderData leftLeg(String boneName) {
			return new RenderData(boneName, GeoArmorRenderer.ArmorSegment.LEFT_LEG);
		}

		public static RenderData rightLeg(String boneName) {
			return new RenderData(boneName, GeoArmorRenderer.ArmorSegment.RIGHT_LEG);
		}

		public static RenderData leftFoot(String boneName) {
			return new RenderData(boneName, GeoArmorRenderer.ArmorSegment.LEFT_FOOT);
		}

		public static RenderData rightFoot(String boneName) {
			return new RenderData(boneName, GeoArmorRenderer.ArmorSegment.RIGHT_FOOT);
		}
	}

	/**
	 * Override to add any custom {@link DataTicket}s you need to capture for rendering.
	 * <p>
	 * The animatable is discarded from the rendering context after this, so any data needed
	 * for rendering should be captured in the renderState provided
	 *
	 * @param animatable The animatable instance being rendered
	 * @param relatedObject An object related to the render pass or null if not applicable.
	 *                         (E.G. ItemStack for GeoItemRenderer, entity instance for GeoReplacedEntityRenderer).
	 * @param renderState The GeckoLib RenderState to add data to, will be passed through the rest of rendering
	 */
	@Override
	public void addRenderData(T animatable, @Nullable O relatedObject, R renderState, float partialTick) {
		final EnumMap<EquipmentSlot, ItemStack> equipment = renderState.getOrDefaultGeckolibData(DataTickets.EQUIPMENT_BY_SLOT, new EnumMap<>(EquipmentSlot.class));

        collectArmorData(renderState, animatable, partialTick, equipment);

		if (!equipment.get(EquipmentSlot.CHEST).isEmpty()) {
			renderState.addGeckolibData(DataTickets.ELYTRA_ROTATION, new Vec3d(animatable.elytraFlightController.leftWingPitch(partialTick),
																			  animatable.elytraFlightController.leftWingYaw(partialTick),
																			  animatable.elytraFlightController.leftWingRoll(partialTick)));
		}
	}

    protected <S extends BipedEntityRenderState & GeoRenderState, A extends BipedEntityModel<S>> void collectArmorData(
            R baseRenderState, T animatable, float partialTick, EnumMap<EquipmentSlot, ItemStack> equipment) {
        S headRenderState = getOrCreateHumanoidRenderState(baseRenderState, false);

        equipment.put(EquipmentSlot.HEAD, headRenderState.equippedHeadStack = animatable.getEquippedStack(EquipmentSlot.HEAD));
        equipment.put(EquipmentSlot.CHEST, headRenderState.equippedChestStack = animatable.getEquippedStack(EquipmentSlot.CHEST));
        equipment.put(EquipmentSlot.LEGS, headRenderState.equippedLegsStack = animatable.getEquippedStack(EquipmentSlot.LEGS));
        equipment.put(EquipmentSlot.FEET, headRenderState.equippedFeetStack = animatable.getEquippedStack(EquipmentSlot.FEET));

        GeoArmorRenderer.captureRenderStates(headRenderState, animatable, partialTick,
                                             (renderState, slot) -> (A)GeckoLibClient.HUMANOID_ARMOR_MODEL.get().getModelData(slot),
                                             slot -> slot == EquipmentSlot.HEAD ? headRenderState : getOrCreateHumanoidRenderState(baseRenderState, true));

        baseRenderState.addGeckolibData(DataTickets.EQUIPMENT_BY_SLOT, equipment);

        if (headRenderState != baseRenderState && headRenderState.hasGeckolibData(DataTickets.PER_SLOT_RENDER_DATA))
            baseRenderState.addGeckolibData(DataTickets.PER_SLOT_RENDER_DATA, headRenderState.getGeckolibData(DataTickets.PER_SLOT_RENDER_DATA));
    }

	/**
	 * Register per-bone render operations, to be rendered after the main model is done.
	 * <p>
	 * Even though the task is called after the main model renders, the {@link MatrixStack} provided will be posed as if the bone
	 * is currently rendering.
	 *
	 * @param consumer The registrar to accept the per-bone render tasks
	 */
    @Override
    public void addPerBoneRender(RenderPassInfo<R> renderPassInfo, BiConsumer<GeoBone, PerBoneRender<R>> consumer) {
		for (RenderData renderData : getRelevantBones(renderPassInfo)) {
            renderPassInfo.model().getBone(renderData.boneName).filter(CuboidGeoBone.class::isInstance)
                    .ifPresentOrElse(bone -> createPerBoneRender(renderPassInfo, bone, renderData, consumer),
                                     () -> GeckoLibConstants.LOGGER.error("Unable to find bone for ItemArmorGeoLayer: {}, skipping", renderData.boneName));
		}
	}

	private void createPerBoneRender(RenderPassInfo<R> renderPassInfo, GeoBone bone, RenderData renderData, BiConsumer<GeoBone, PerBoneRender<R>> consumer) {
        GeoArmorRenderer.ArmorSegment armorSegment = renderData.armorSegment;
		ItemStack stack = getEquipmentStack(renderPassInfo, bone, armorSegment.equipmentSlot);

		if (!stack.isEmpty()) {
			consumer.accept(bone, (renderPassInfo2, bone2, renderTasks) ->
					buildRenderTask(renderPassInfo2, armorSegment.equipmentSlot, armorSegment.modelPartGetter, stack, (CuboidGeoBone)bone2, renderTasks));
		}
	}

	/**
	 * Perform the actual rendering operation for the given bone and equipment
	 */
	protected void buildRenderTask(RenderPassInfo<R> renderPassInfo, EquipmentSlot slot, Function<BipedEntityModel<?>, ModelPart> modelPartFactory, ItemStack equipmentStack, CuboidGeoBone bone,
                                   OrderedRenderCommandQueue renderTasks) {
		// TODO Rewrite this Geo layer to make work :(
		if (true || equipmentStack.isEmpty())
			return;

        final MatrixStack poseStack = renderPassInfo.poseStack();
        final R renderState = renderPassInfo.renderState();

		if (equipmentStack.getItem() instanceof BlockItem blockItem && blockItem.getBlock() instanceof AbstractSkullBlock skullBlock) {
            renderSkullAsArmor(renderPassInfo, bone, equipmentStack, skullBlock, renderTasks);
		}
        else if (RenderUtil.getGeckoLibArmorRenderer(equipmentStack, slot) instanceof GeoArmorRenderer geoArmorRenderer) {
            EnumMap<EquipmentSlot, R> perSlotData = renderState.getGeckolibData(DataTickets.PER_SLOT_RENDER_DATA);

            if (perSlotData != null) {
                R slotRenderState = perSlotData.get(slot);

                if (slotRenderState != null) {
                    poseStack.push();
                    poseStack.scale(-1, -1, 1);

                    GeoRenderState humanoidRenderState = getOrCreateHumanoidRenderState(slotRenderState, false);
                    RenderPassInfo.BoneUpdater<R> boneUpdater = positionModelPartFromBone(poseStack, bone, modelPartFactory.apply(slotRenderState.getGeckolibData(DataTickets.HUMANOID_MODEL)));

                    renderPassInfo.addBoneUpdater(boneUpdater);

                    geoArmorRenderer.performRenderPass(humanoidRenderState, poseStack, renderTasks, renderPassInfo.cameraState());
                    poseStack.pop();
                }
            }
        }
		else {
			Model<?> vanillaModel = getArmorModelForRender(bone, slot, equipmentStack, renderState);
			ModelPart modelPart = vanillaModel instanceof BipedEntityModel<?> humanoidModel ? modelPartFactory.apply(humanoidModel) : vanillaModel.getRootPart();

			if (!modelPart.cuboids.isEmpty()) {
				poseStack.push();
				poseStack.scale(-1, -1, 1);

                EquippableComponent equippable = equipmentStack.get(DataComponentTypes.EQUIPPABLE);

                if (equippable != null) {
                    equippable.assetId().ifPresent(assetId -> {
                        positionModelPartFromBone(poseStack, bone, modelPart);
                        renderVanillaArmorPiece(renderPassInfo, poseStack, bone, slot, equipmentStack, equippable, assetId, vanillaModel, modelPart, renderTasks);
                    });
                }

				poseStack.pop();
			}
		}
	}

	/**
	 * Helper method to retrieve a stored held or worn ItemStack by the slot it's in, as computed in {@link GeoRenderLayer#addRenderData(GeoAnimatable, Object, GeoRenderState, float)}
	 */
	protected ItemStack getEquipmentStack(RenderPassInfo<R> renderPassInfo, GeoBone bone, EquipmentSlot slot) {
		return (ItemStack)renderPassInfo.getGeckolibData(DataTickets.EQUIPMENT_BY_SLOT).getOrDefault(slot, ItemStack.EMPTY);
	}

	/**
	 * Get the LayerType for the given armor piece. This defines the asset type to use in rendering a vanilla armor piece.
	 */
	protected EquipmentModel.LayerType getEquipmentLayerType(RenderPassInfo<R> renderPassInfo, GeoBone bone, EquipmentSlot slot, ItemStack armorStack, RegistryKey<EquipmentAsset> assetId) {
		if (slot == EquipmentSlot.LEGS)
			return EquipmentModel.LayerType.HUMANOID_LEGGINGS;

		if (slot == EquipmentSlot.CHEST && !this.equipmentAssets.get(assetId).getLayers(EquipmentModel.LayerType.WINGS).isEmpty())
			return EquipmentModel.LayerType.WINGS;

		return EquipmentModel.LayerType.HUMANOID;
	}

	/**
	 * Renders an individual armor piece base on the given {@link GeoBone} and {@link ItemStack}
	 */
	protected void renderVanillaArmorPiece(RenderPassInfo<R> renderPassInfo, MatrixStack poseStack, GeoBone bone, EquipmentSlot slot, ItemStack armorStack,
										   EquippableComponent equippable, RegistryKey<EquipmentAsset> assetId, Model<?> model, ModelPart modelPart, OrderedRenderCommandQueue renderTasks) {
		EquipmentModel.LayerType layerType = getEquipmentLayerType(renderPassInfo, bone, slot, armorStack, assetId);
		Model modelToRender = model;

		if (layerType == EquipmentModel.LayerType.WINGS) {
			if (model instanceof BipedEntityModel humanoidModel && modelPart != humanoidModel.body)
				return;

			modelToRender = checkForElytraModel(renderPassInfo, layerType, bone, poseStack);
		}

		this.equipmentRenderer.render(layerType, assetId, modelToRender, renderPassInfo.renderState(), armorStack, poseStack, renderTasks, renderPassInfo.packedLight(), renderPassInfo.renderState().outlineColor);
	}

	/**
	 * Check for the presence of {@link ElytraEntityModel Elytra} wings, and adjust the model as necessary
	 */
	protected Model checkForElytraModel(RenderPassInfo<R> renderPassInfo, EquipmentModel.LayerType layerType, GeoBone bone, MatrixStack poseStack) {
		ElytraEntityModel model = GeckoLibClient.GENERIC_ELYTRA_MODEL.get();
		BipedEntityRenderState humanoidRenderState = new BipedEntityRenderState();
        R renderState = renderPassInfo.renderState();
		Vec3d elytraRotation = renderState.getOrDefaultGeckolibData(DataTickets.ELYTRA_ROTATION, Vec3d.ZERO);
		humanoidRenderState.isInSneakingPose = renderState.getOrDefaultGeckolibData(DataTickets.IS_CROUCHING, false);
		humanoidRenderState.leftWingPitch = (float)elytraRotation.x;
		humanoidRenderState.leftWingYaw = (float)elytraRotation.y;
		humanoidRenderState.leftWingRoll = (float)elytraRotation.z;

		model.setAngles(humanoidRenderState);
		poseStack.translate(0, -1.5f, 0.125f);

		return model;
	}

	/**
	 * Returns a cached instance of a base HumanoidModel that is used for rendering/modelling the provided {@link ItemStack}
	 */
	@ApiStatus.Internal
	protected <S extends BipedEntityRenderState & GeoRenderState> Model<?> getArmorModelForRender(GeoBone bone, EquipmentSlot slot, ItemStack stack, R renderState) {
		final S humanoidRenderState = renderState instanceof BipedEntityRenderState humanoidRenderState1 ? (S)humanoidRenderState1 : (S)new BipedEntityRenderState();
		final EquipmentModel.LayerType layerType = slot == EquipmentSlot.LEGS ? EquipmentModel.LayerType.HUMANOID_LEGGINGS : EquipmentModel.LayerType.HUMANOID;
		final BipedEntityModel defaultModel = GeckoLibClient.HUMANOID_ARMOR_MODEL.get().getModelData(slot);

		return GeckoLibClientServices.ITEM_RENDERING.getArmorModelForItem(humanoidRenderState, stack, slot, layerType, defaultModel);
	}

	/**
	 * Render a given {@link AbstractSkullBlock} as a worn armor piece in relation to a given {@link GeoBone}
	 */
	protected void renderSkullAsArmor(RenderPassInfo<R> renderPassInfo, GeoBone bone, ItemStack stack, AbstractSkullBlock skullBlock, OrderedRenderCommandQueue renderTasks) {
		SkullBlock.SkullType type = skullBlock.getSkullType();
		SkullBlockEntityModel model = this.skullModels.apply(type);

		if (model == null)
			return;

		ProfileComponent profile = stack.get(DataComponentTypes.PROFILE);
		RenderLayer renderType = profile == null ? PlayerSkinCache.DEFAULT_RENDER_LAYER : this.skinCache.get(profile).getRenderLayer();
		MatrixStack poseStack = renderPassInfo.poseStack();

		poseStack.push();
		RenderUtil.translateAndRotateMatrixForBone(poseStack, bone);
		poseStack.scale(1.1875f, 1.1875f, 1.1875f);
		poseStack.translate(-0.5f, 0, -0.5f);

		SkullBlockEntityRenderer.render(null, 0, 0, poseStack, renderTasks, renderPassInfo.packedLight(), model, renderType, renderPassInfo.renderState().outlineColor, null);
		poseStack.pop();
	}

	/**
	 * Prepares the given {@link ModelPart} for render by setting its translation, position, and rotation values based on the provided {@link GeoBone}
	 * <p>
	 * This implementation uses the <b><u>FIRST</u></b> cube in the source part
	 * to determine the scale and position of the GeoArmor to be rendered
	 *
	 * @param poseStack The PoseStack being used for rendering
	 * @param bone The GeoBone to base the translations on
	 * @param sourcePart The ModelPart to translate
	 */
	protected RenderPassInfo.BoneUpdater<R> positionModelPartFromBone(MatrixStack poseStack, CuboidGeoBone bone, ModelPart sourcePart) {
		final GeoCube firstCube = bone.cubes[0];
		final Cuboid armorCube = sourcePart.cuboids.getFirst();
		final double armorBoneSizeX = firstCube.size().getX();
		final double armorBoneSizeY = firstCube.size().getY();
		final double armorBoneSizeZ = firstCube.size().getZ();
		final double actualArmorSizeX = Math.abs(armorCube.maxX - armorCube.minX);
		final double actualArmorSizeY = Math.abs(armorCube.maxY - armorCube.minY);
		final double actualArmorSizeZ = Math.abs(armorCube.maxZ - armorCube.minZ);
		float scaleX = (float)(armorBoneSizeX / actualArmorSizeX);
		float scaleY = (float)(armorBoneSizeY / actualArmorSizeY);
		float scaleZ = (float)(armorBoneSizeZ / actualArmorSizeZ);
        final RenderPassInfo.BoneUpdater<R> modelPositioner = (renderPassInfo, snapshots) -> {
            final BoneSnapshot snapshot = snapshots.get(bone);

            sourcePart.setOrigin(-(bone.pivotX() - ((bone.pivotX() * scaleX) - bone.pivotX()) / scaleX),
                              -(bone.pivotY() - ((bone.pivotY() * scaleY) - bone.pivotY()) / scaleY),
                              (bone.pivotZ() - ((bone.pivotZ() * scaleZ) - bone.pivotZ()) / scaleZ));

            sourcePart.pitch = -snapshot.getRotX();
            sourcePart.yaw = -snapshot.getRotY();
            sourcePart.roll = snapshot.getRotZ();
        };

		poseStack.scale(scaleX, scaleY, scaleZ);

        return modelPositioner;
	}

    /**
     * Convert an existing RenderState to a HumanoidRenderState, either by casting or creating a new one, for the purposes of RenderState filling
     */
    protected <S extends BipedEntityRenderState & GeoRenderState> S getOrCreateHumanoidRenderState(R renderState, boolean forceNew) {
        S newState = (S)(!forceNew && renderState instanceof BipedEntityRenderState state ? state : new BipedEntityRenderState());

        if (newState != renderState)
            RenderStateUtil.makeMinimalArmorRenderingClone(newState, renderState);

        return newState;
    }
}
