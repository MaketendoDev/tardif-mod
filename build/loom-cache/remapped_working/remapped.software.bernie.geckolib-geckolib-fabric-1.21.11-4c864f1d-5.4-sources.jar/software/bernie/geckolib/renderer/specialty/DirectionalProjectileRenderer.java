package software.bernie.geckolib.renderer.specialty;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;
import software.bernie.geckolib.renderer.base.RenderPassInfo;

/**
 * Specialty class for rendering directionally oriented projectiles.
 * <p>
 * Automatically handles transforms for the entity based on its current rotation.
 * <p>
 * <b><u>NOTE:</u></b> This renderer assumes your model is laying flat, pointing directly north
 */
public class DirectionalProjectileRenderer<T extends ProjectileEntity & GeoAnimatable, R extends EntityRenderState & GeoRenderState> extends GeoEntityRenderer<T, R> {
    /**
     * Creates a new defaulted renderer instance, using the entity's registered id as the file name for its assets
     */
    public DirectionalProjectileRenderer(EntityRendererFactory.Context context, EntityType<? extends T> entityType) {
        this(context, new DefaultedEntityGeoModel<>(Registries.ENTITY_TYPE.getId(entityType)));
    }

    public DirectionalProjectileRenderer(EntityRendererFactory.Context context, GeoModel<T> model) {
        super(context, model);
    }

    /**
     * Applies rotation transformations to the renderer prior to render time to account for various entity states
     */
    @Override
    protected void applyRotations(RenderPassInfo<R> renderPassInfo, MatrixStack poseStack, float nativeScale) {
        poseStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(renderPassInfo.getOrDefaultGeckolibData(DataTickets.ENTITY_YAW, 0f)));
        poseStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(renderPassInfo.getOrDefaultGeckolibData(DataTickets.ENTITY_PITCH, 0f)));
    }

    /**
     * Calculate the yaw of the given animatable.
     * <p>
     * Normally only called for non-{@link LivingEntity LivingEntities}, and shouldn't be considered a safe place to modify rotation<br>
     * Do that in {@link software.bernie.geckolib.renderer.base.GeoRendererInternals#addRenderData(GeoAnimatable, Object, GeoRenderState, float)} instead
     */
    @Override
    protected float calculateYRot(T animatable, float yHeadRot, float partialTick) {
        return MathHelper.lerp(partialTick, animatable.lastYaw, animatable.getYaw()) + 180f;
    }
}
