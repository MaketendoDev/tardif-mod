package software.bernie.geckolib.mixin.client;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import software.bernie.geckolib.renderer.GeoArmorRenderer;
import software.bernie.geckolib.renderer.base.GeoRenderState;

@Mixin(ArmorFeatureRenderer.class)
public abstract class HumanoidArmorLayerMixin<S extends BipedEntityRenderState, M extends BipedEntityModel<S>, A extends BipedEntityModel<S>> extends FeatureRenderer<S, M> {
    public HumanoidArmorLayerMixin(FeatureRendererContext<S, M> renderer) {
        super(renderer);
    }

    /**
     * Injection into the render point for armor on HumanoidModels (Players, Zombies, etc.) to defer to GeckoLib item-armor rendering as applicable
     * <p>
     * Does nothing if GeckoLib has nothing to handle for the given arguments
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    @WrapWithCondition(method = "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/entity/layers/HumanoidArmorLayer;renderArmorPiece(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/EquipmentSlot;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;)V"))
    public boolean geckolib$wrapArmorPieceRender(ArmorFeatureRenderer<S, M, A> layer, MatrixStack poseStack, OrderedRenderCommandQueue renderTasks, ItemStack stack, EquipmentSlot slot, int packedLight, S entityRenderState) {
        return entityRenderState instanceof BipedEntityRenderState && !GeoArmorRenderer.tryRenderGeoArmorPiece(
                (renderState, equipmentSlot) -> (BipedEntityModel)layer.getModel((S)renderState, equipmentSlot),
                poseStack, renderTasks, stack, slot, packedLight, (BipedEntityRenderState & GeoRenderState)entityRenderState);
    }
}