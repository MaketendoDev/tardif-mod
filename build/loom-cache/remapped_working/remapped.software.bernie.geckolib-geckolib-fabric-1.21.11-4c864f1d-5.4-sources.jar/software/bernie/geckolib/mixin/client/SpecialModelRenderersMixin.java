package software.bernie.geckolib.mixin.client;

import com.mojang.serialization.MapCodec;
import net.minecraft.client.render.item.model.special.SpecialModelRenderer;
import net.minecraft.client.render.item.model.special.SpecialModelTypes;
import net.minecraft.util.Identifier;
import net.minecraft.util.dynamic.Codecs;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.renderer.internal.GeckolibItemSpecialRenderer;

@Mixin(SpecialModelTypes.class)
public class SpecialModelRenderersMixin {
    @Shadow
    @Final
    private static Codecs.IdMapper<Identifier, MapCodec<? extends SpecialModelRenderer.Unbaked>> ID_MAPPER;

    /**
     * Inject GeckoLib's custom item model renderer into the vanilla map of special renderers
     */
    @Inject(method = "bootstrap", at = @At("TAIL"))
    private static void geckolib$addSpecialRenderer(CallbackInfo ci) {
        ID_MAPPER.put(GeckoLibConstants.id("geckolib"), GeckolibItemSpecialRenderer.Unbaked.MAP_CODEC);
    }
}