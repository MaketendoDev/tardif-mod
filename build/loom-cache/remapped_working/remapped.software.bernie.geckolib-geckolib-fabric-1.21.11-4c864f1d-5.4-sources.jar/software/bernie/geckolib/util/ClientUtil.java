package software.bernie.geckolib.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.GlfwUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.MoonPhase;
import net.minecraft.world.World;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;

/**
 * Helper class for segregating client-side code
 */
public final class ClientUtil {
	/**
	 * Get the player on the client
	 */
	public static @Nullable PlayerEntity getClientPlayer() {
		return MinecraftClient.getInstance().player;
	}

	/**
	 * Gets the current level on the client
	 */
	public static @Nullable World getLevel() {
		return MinecraftClient.getInstance().world;
	}

	/**
	 * Whether the local (client) player has a cape
	 */
	public static boolean clientPlayerHasCape() {
		final ClientPlayerEntity player = MinecraftClient.getInstance().player;

		return player != null && player.getSkin().cape() != null;
	}

	/**
	 * Get the current camera position
	 */
	public static Vec3d getCameraPos() {
		return MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
	}

	/**
	 * Helper method to check for first-person camera mode
	 * <p>
	 * Split off to preserve side-agnosticism of the Molang system
	 */
	public static boolean isFirstPerson() {
		return MinecraftClient.getInstance().options.getPerspective().isFirstPerson();
	}

	/**
	 * Get the current phase of the moon on the client world
	 */
	public static MoonPhase getClientMoonPhase() {
		return MinecraftClient.getInstance().worldRenderer.worldRenderState.skyRenderState.moonPhase;
	}

    /**
     * Get the game time for the client world, or a global game time if no world is loaded<br>
     * Returned value is in ticks
     */
    public static double getCurrentTick() {
        final MinecraftClient mc = MinecraftClient.getInstance();

        return mc.world != null ?
               mc.world.getTime() + mc.getRenderTickCounter().getTickProgress(false) :
               GlfwUtil.getTime() * 20d;
    }

    @ApiStatus.Internal
	public static int getVisibleEntityCount() {
        final MinecraftClient mc = MinecraftClient.getInstance();

        if (mc.world == null)
            return 0;

        return mc.field_1769.field_61737.field_61735.size();
	}

    private ClientUtil() {}
}
