package software.bernie.geckolib.constant.dataticket;

import it.unimi.dsi.fastutil.Pair;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import software.bernie.geckolib.constant.DataTickets;

/**
 * Network-compatible {@link DataTicket} implementation
 * <p>
 * Used for sending data from {@code server -> client} in an easy manner
 *
 * @param <D> Data type for this ticket
 */
public final class SerializableDataTicket<D> extends DataTicket<D> {
	public static final PacketCodec<RegistryByteBuf, SerializableDataTicket<?>> STREAM_CODEC = PacketCodec.tuple(
			Identifier.PACKET_CODEC,
			SerializableDataTicket::getRegisteredId,
            SerializableDataTicket::enforceValidTicket);

	private final PacketCodec<? super RegistryByteBuf, D> streamCodec;
	private final Identifier registeredId;

	private SerializableDataTicket(Identifier id, Class<? extends D> objectType, PacketCodec<? super RegistryByteBuf, D> streamCodec) {
		super(id.toString(), objectType);

		this.streamCodec = streamCodec;
		this.registeredId = id;
	}

	/**
	 * Get the registered ID for this ticket
	 */
	public Identifier getRegisteredId() {
		return this.registeredId;
	}

	/**
	 * Create a new network-syncable DataTicket for a given name and object type
	 * <p>
	 * <b><u>MUST</u></b> be created during mod construct
	 * <p>
	 * This DataTicket should then be stored statically somewhere and re-used.
	 */
	@SuppressWarnings("unchecked")
    public static <D> SerializableDataTicket<D> create(Identifier id, Class<? extends D> objectType, PacketCodec<? super RegistryByteBuf, D> streamCodec) {
		return (SerializableDataTicket<D>)IDENTITY_CACHE.computeIfAbsent(Pair.of(objectType, id.toString()), pair -> DataTickets.registerSerializable(new SerializableDataTicket<>(id, objectType, streamCodec)));
	}

	/**
	 * @return The {@link PacketCodec} for the given SerializableDataTicket
	 */
	public PacketCodec<? super RegistryByteBuf, D> streamCodec() {
		return this.streamCodec;
	}

	// Pre-defined common types for use

	/**
	 * Generate a new {@code SerializableDataTicket<Double>} for the given id
	 *
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<Double> ofDouble(Identifier id) {
		return SerializableDataTicket.create(id, Double.class, PacketCodecs.DOUBLE);
	}

	/**
	 * Generate a new {@code SerializableDataTicket<Float>} for the given id
	 *
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<Float> ofFloat(Identifier id) {
		return SerializableDataTicket.create(id, Float.class, PacketCodecs.FLOAT);
	}

	/**
	 * Generate a new {@code SerializableDataTicket<Boolean>} for the given id
	 *
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<Boolean> ofBoolean(Identifier id) {
		return SerializableDataTicket.create(id, Boolean.class, PacketCodecs.BOOLEAN);
	}

	/**
	 * Generate a new {@code SerializableDataTicket<Integer>} for the given id
	 *
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<Integer> ofInt(Identifier id) {
		return SerializableDataTicket.create(id, Integer.class, PacketCodecs.INTEGER);
	}

	/**
	 * Generate a new {@code SerializableDataTicket<String>} for the given id
	 *
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<String> ofString(Identifier id) {
		return SerializableDataTicket.create(id, String.class, PacketCodecs.STRING);
	}

	/**
	 * Generate a new {@code SerializableDataTicket<Enum>} for the given id
	 *
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static <E extends Enum<E>> SerializableDataTicket<E> ofEnum(Identifier id, Class<E> enumClass) {
		return SerializableDataTicket.create(id, enumClass, new PacketCodec<>() {
			@Override
			public E decode(RegistryByteBuf buf) {
				return Enum.valueOf(enumClass, buf.readString());
			}

			@Override
			public void encode(RegistryByteBuf buf, E data) {
				buf.writeString(data.toString());
			}
		});
	}

	/**
	 * Generate a new {@code SerializableDataTicket<Vec3>} for the given id
	 *
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<Vec3d> ofVec3(Identifier id) {
		return SerializableDataTicket.create(id, Vec3d.class, PacketCodecs.VECTOR_3F.xmap(Vec3d::new, Vec3d::toVector3f));
	}

	/**
	 * Generate a new {@code SerializableDataTicket<BlockPos>} for the given id
	 *
	 * @param id The unique id of your ticket. Include your modid
	 */
	public static SerializableDataTicket<BlockPos> ofBlockPos(Identifier id) {
		return SerializableDataTicket.create(id, BlockPos.class, new PacketCodec<>() {
			@Override
			public BlockPos decode(RegistryByteBuf buf) {
				return buf.readBlockPos();
			}

			@Override
			public void encode(RegistryByteBuf buf, BlockPos blockPos) {
				buf.writeBlockPos(blockPos);
			}
		});
	}

	/**
	 * Retrieve a SerializableDataTicket by its registered ID, throwing an exception if not found
	 */
	public static SerializableDataTicket<?> enforceValidTicket(Identifier name) throws IllegalStateException {
		final SerializableDataTicket<?> ticket = DataTickets.byName(name);

		if (ticket == null)
			throw new IllegalStateException("Attempted to retrieve a SerializableDataTicket that does not exist! Likely didn't register the ticket properly: " + name);

		return ticket;
	}
}
