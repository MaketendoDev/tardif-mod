package software.bernie.geckolib.service;

import com.google.common.base.Suppliers;
import software.bernie.geckolib.renderer.base.GeoRenderState;

import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.ElytraEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.EquipmentModelData;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

/**
 * Loader-agnostic service interface for clientside functionalities
 */
public interface GeckoLibClient {
    Supplier<EquipmentModelData<BipedEntityModel<?>>> HUMANOID_ARMOR_MODEL = Suppliers.memoize(() -> EquipmentModelData.mapToEntityModel(EntityModelLayers.PLAYER_EQUIPMENT, MinecraftClient.getInstance().getLoadedEntityModels(), BipedEntityModel::new));
    Supplier<ElytraEntityModel> GENERIC_ELYTRA_MODEL = Suppliers.memoize(() -> new ElytraEntityModel(MinecraftClient.getInstance().getLoadedEntityModels().getModelPart(EntityModelLayers.ELYTRA)));

    /**
     * Helper method for retrieving an (ideally) cached instance of the armor model for a given Item
     * <p>
     * If no custom model applies to this item, the {@code defaultModel} is returned
     */
    <S extends BipedEntityRenderState & GeoRenderState> Model<?> getArmorModelForItem(S entityRenderState, ItemStack stack, EquipmentSlot slot, EquipmentModel.LayerType type, BipedEntityModel<S> defaultModel);

    /**
     * Return the dye value for a given ItemStack, or the default value if not present.
     * <p>
     * This is split off to allow for handling of loader-specific handling for dyed items
     */
    int getDyedItemColor(ItemStack itemStack, int defaultColor);
}
