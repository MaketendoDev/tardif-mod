package software.bernie.geckolib.network.packet.singleton;

import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.SingletonGeoAnimatable;
import software.bernie.geckolib.cache.SyncedSingletonAnimatableCache;
import software.bernie.geckolib.constant.dataticket.SerializableDataTicket;
import software.bernie.geckolib.network.packet.MultiloaderPacket;
import software.bernie.geckolib.util.ClientUtil;

import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

public record SingletonDataSyncPacket<D>(String syncableId, long instanceId, SerializableDataTicket<D> dataTicket, D data) implements MultiloaderPacket {
    public static final CustomPayload.Id<SingletonDataSyncPacket<?>> TYPE = new Id<>(GeckoLibConstants.id("singleton_data_sync"));
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static final PacketCodec<RegistryByteBuf, SingletonDataSyncPacket<?>> CODEC = PacketCodec.ofStatic((buf, packet) -> {
        SerializableDataTicket.STREAM_CODEC.encode(buf, packet.dataTicket);
        buf.writeString(packet.syncableId);
        buf.writeVarLong(packet.instanceId);
        ((PacketCodec)packet.dataTicket.streamCodec()).encode(buf, packet.data);
    }, buf -> {
        final SerializableDataTicket dataTicket = SerializableDataTicket.STREAM_CODEC.decode(buf);

        return new SingletonDataSyncPacket<>(buf.readString(), buf.readVarLong(), dataTicket, dataTicket.streamCodec().decode(buf));
    });

    @Override
    public Id<? extends CustomPayload> getId() {
        return TYPE;
    }

    @Override
    public void receiveMessage(@Nullable PlayerEntity sender, Consumer<Runnable> workQueue) {
        workQueue.accept(() -> {
            final PlayerEntity player = ClientUtil.getClientPlayer();
            final GeoAnimatable animatable;

            if (player == null || (animatable = SyncedSingletonAnimatableCache.getSyncedAnimatable(this.syncableId)) == null)
                return;

            if (animatable instanceof SingletonGeoAnimatable singleton)
                singleton.setAnimData(player, this.instanceId, this.dataTicket, this.data);
        });
    }
}
