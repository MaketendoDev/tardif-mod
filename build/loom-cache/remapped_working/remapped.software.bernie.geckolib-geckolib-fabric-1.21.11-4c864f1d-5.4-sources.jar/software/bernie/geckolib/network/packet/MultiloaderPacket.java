package software.bernie.geckolib.network.packet;

import org.jspecify.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.CustomPayload;

/**
 * Multiloader implementation of a packet base, for loader-agnostic packet handling
 */
public interface MultiloaderPacket extends CustomPayload {
    /**
     * Handle the message after being received and decoded
     * <p>
     * This method is side-agnostic, so make sure you call out to client proxies as needed
     * <p>
     * The player may be null if the packet is being sent before the player loads in
     */
    void receiveMessage(@Nullable PlayerEntity sender, Consumer<Runnable> workQueue);
}
