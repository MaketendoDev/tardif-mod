package software.bernie.geckolib.network.packet.blockentity;

import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.network.packet.MultiloaderPacket;
import software.bernie.geckolib.util.ClientUtil;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public record StopTriggeredBlockEntityAnimPacket(BlockPos pos, Optional<String> controllerName, Optional<String> animName) implements MultiloaderPacket {
    public static final Id<StopTriggeredBlockEntityAnimPacket> TYPE = new Id<>(GeckoLibConstants.id("stop_triggered_blockentity_anim"));
    public static final PacketCodec<PacketByteBuf, StopTriggeredBlockEntityAnimPacket> CODEC = PacketCodec.tuple(
            BlockPos.PACKET_CODEC, StopTriggeredBlockEntityAnimPacket::pos,
            PacketCodecs.STRING.collect(PacketCodecs::optional), StopTriggeredBlockEntityAnimPacket::controllerName,
            PacketCodecs.STRING.collect(PacketCodecs::optional), StopTriggeredBlockEntityAnimPacket::animName,
            StopTriggeredBlockEntityAnimPacket::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return TYPE;
    }

    @Override
    public void receiveMessage(@Nullable PlayerEntity sender, Consumer<Runnable> workQueue) {
        workQueue.accept(() -> {
            final World level = ClientUtil.getLevel();

            if (level != null && level.getBlockEntity(this.pos) instanceof GeoBlockEntity blockEntity)
                blockEntity.stopTriggeredAnim(this.controllerName.orElse(null), this.animName.orElse(null));
        });
    }
}
