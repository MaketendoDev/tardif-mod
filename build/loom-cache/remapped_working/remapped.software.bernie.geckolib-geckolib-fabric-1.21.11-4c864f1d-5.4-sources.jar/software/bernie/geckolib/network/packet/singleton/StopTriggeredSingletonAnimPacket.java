package software.bernie.geckolib.network.packet.singleton;

import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.cache.SyncedSingletonAnimatableCache;
import software.bernie.geckolib.network.packet.MultiloaderPacket;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

public record StopTriggeredSingletonAnimPacket(String syncableId, long instanceId, Optional<String> controllerName, Optional<String> animName) implements MultiloaderPacket {
    public static final Id<StopTriggeredSingletonAnimPacket> TYPE = new Id<>(GeckoLibConstants.id("stop_triggered_singleton_anim"));
    public static final PacketCodec<PacketByteBuf, StopTriggeredSingletonAnimPacket> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, StopTriggeredSingletonAnimPacket::syncableId,
            PacketCodecs.VAR_LONG, StopTriggeredSingletonAnimPacket::instanceId,
            PacketCodecs.STRING.collect(PacketCodecs::optional), StopTriggeredSingletonAnimPacket::controllerName,
            PacketCodecs.STRING.collect(PacketCodecs::optional), StopTriggeredSingletonAnimPacket::animName,
            StopTriggeredSingletonAnimPacket::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return TYPE;
    }

    @Override
    public void receiveMessage(@Nullable PlayerEntity sender, Consumer<Runnable> workQueue) {
        workQueue.accept(() -> {
            GeoAnimatable animatable = SyncedSingletonAnimatableCache.getSyncedAnimatable(this.syncableId);

            if (animatable != null) {
                AnimatableManager<GeoAnimatable> animatableManager = animatable.getAnimatableInstanceCache().getManagerForId(this.instanceId);

                if (this.controllerName.isPresent()) {
                    animatableManager.stopTriggeredAnimation(this.controllerName.get(), this.animName.orElse(null));
                }
                else {
                    animatableManager.stopTriggeredAnimation(this.animName.orElse(null));
                }
            }
        });
    }
}
