package software.bernie.geckolib.animatable.stateless;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.server.world.ServerWorld;
import software.bernie.geckolib.GeckoLibServices;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.network.packet.blockentity.StatelessBlockEntityPlayAnimPacket;
import software.bernie.geckolib.network.packet.blockentity.StatelessBlockEntityStopAnimPacket;

/**
 * Extension of {@link StatelessAnimatable} for {@link GeoBlockEntity} animatables
 */
public non-sealed interface StatelessGeoBlockEntity extends StatelessAnimatable, GeoBlockEntity {
    /**
     * Start or continue a pre-defined animation
     */
    @Override
    default void playAnimation(RawAnimation animation) {
        if (!(this instanceof BlockEntity self))
            throw new ClassCastException("Cannot use StatelessGeoBlockEntity on a non-BlockEntity animatable!");

        if (self.getWorld() instanceof ServerWorld level) {
            GeckoLibServices.NETWORK.sendToAllPlayersTrackingBlock(new StatelessBlockEntityPlayAnimPacket(self.getPos(), animation), level, self.getPos());
        }
        else {
            handleClientAnimationPlay(this, 0, animation);
        }
    }

    /**
     * Stop an already-playing animation
     */
    @Override
    default void stopAnimation(String animation) {
        if (!(this instanceof BlockEntity self))
            throw new ClassCastException("Cannot use StatelessGeoBlockEntity on a non-BlockEntity animatable!");

        if (self.getWorld() instanceof ServerWorld level) {
            GeckoLibServices.NETWORK.sendToAllPlayersTrackingBlock(new StatelessBlockEntityStopAnimPacket(self.getPos(), animation), level, self.getPos());
        }
        else {
            handleClientAnimationStop(this, 0, animation);
        }
    }
}
