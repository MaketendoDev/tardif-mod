package software.bernie.geckolib.cache.model.cuboid;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.model.GeoBone;
import software.bernie.geckolib.cache.model.GeoQuad;
import software.bernie.geckolib.util.RenderUtil;

/**
 * Baked cuboid for a {@link GeoBone}
 *
 * @param quads The quad array for this cube, pre-sorted to render in correct order
 * @param pivot The pivot point of this cube
 * @param rotation The baked rotation value of this cube
 * @param size The x/y/z dimensions of this cube
 */
public record GeoCube(@Nullable GeoQuad[] quads, Vec3d pivot, Vec3d rotation, Vec3d size) {
    /**
     * Submit this cuboid's quads to the vertex consumer
     */
    public void render(MatrixStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, int renderColor) {
        translateToPivotPoint(poseStack);
        rotate(poseStack);
        translateAwayFromPivotPoint(poseStack);

        Matrix3f normalisedPoseState = poseStack.peek().getNormalMatrix();
        Matrix4f poseState = new Matrix4f(poseStack.peek().getPositionMatrix());

        for (GeoQuad quad : this.quads) {
            if (quad == null)
                continue;

            Vector3f normal = normalisedPoseState.transform(quad.normalVec());

            RenderUtil.fixInvertedFlatCube(this, normal);
            quad.render(poseState, normal, vertexConsumer, packedLight, packedOverlay, renderColor);
        }

    }

    /**
     * Apply a rotation to the provided PoseStack by this cube's rotation values
     */
    public void rotate(MatrixStack poseStack) {
        final Vec3d rotation = rotation();

        poseStack.multiply(new Quaternionf().rotationXYZ(0, 0, (float)rotation.getZ()));
        poseStack.multiply(new Quaternionf().rotationXYZ(0, (float)rotation.getY(), 0));
        poseStack.multiply(new Quaternionf().rotationXYZ((float)rotation.getX(), 0, 0));
    }

    /**
     * Apply a translation to the provided PoseStack to this cube's pivot point
     */
    public void translateToPivotPoint(MatrixStack poseStack) {
        poseStack.translate(pivot().getX() / 16f, pivot().getY() / 16f, pivot().getZ() / 16f);
    }

    /**
     * Apply a translation to the provided PoseStack away from this cube's pivot point
     */
    public void translateAwayFromPivotPoint(MatrixStack poseStack) {
        poseStack.translate(-pivot().getX() / 16f, -pivot().getY() / 16f, -pivot().getZ() / 16f);
    }
}
