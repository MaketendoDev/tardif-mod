package software.bernie.geckolib.cache.model.cuboid;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import org.jspecify.annotations.Nullable;
import software.bernie.geckolib.cache.model.GeoBone;
import software.bernie.geckolib.renderer.base.GeoRenderState;
import software.bernie.geckolib.renderer.base.RenderPassInfo;

/**
 * Implementation of GeoBone for cuboid rendering
 */
public final class CuboidGeoBone extends GeoBone {
    public final GeoCube[] cubes;

    public CuboidGeoBone(@Nullable GeoBone parent, String name, GeoBone[] children, GeoCube[] cubes, float pivotX, float pivotY, float pivotZ, float rotX, float rotY, float rotZ) {
        super(parent, name, children, pivotX, pivotY, pivotZ, rotX, rotY, rotZ);

        this.cubes = cubes;
    }

    @Override
    public <R extends GeoRenderState> void render(RenderPassInfo<R> renderPassInfo, MatrixStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, int renderColor) {
        if (this.frameSnapshot == null || !this.frameSnapshot.isHidden()) {
            for (GeoCube cube : this.cubes) {
                poseStack.push();
                cube.render(poseStack, vertexConsumer, packedLight, packedOverlay, renderColor);
                poseStack.pop();
            }
        }
    }
}
