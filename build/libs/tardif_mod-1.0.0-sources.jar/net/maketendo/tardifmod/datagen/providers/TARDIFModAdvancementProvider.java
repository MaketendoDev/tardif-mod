package net.maketendo.tardifmod.datagen.providers;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.class_7225;
import net.minecraft.class_8779;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public class TARDIFModAdvancementProvider extends FabricAdvancementProvider {
    public TARDIFModAdvancementProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(output, registryLookup);
    }

    @Override
    public void generateAdvancement(class_7225.class_7874 wrapperLookup, Consumer<class_8779> consumer) {

    }
}
