package net.maketendo.tardifmod.datagen.providers;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.main.TARDIFBlocks;
import net.maketendo.tardifmod.main.TARDIFItems;
import net.minecraft.class_1856;
import net.minecraft.class_2246;
import net.minecraft.class_2446;
import net.minecraft.class_2960;
import net.minecraft.class_3981;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_7924;
import net.minecraft.class_8790;
import net.minecraft.data.recipes.*;
import java.util.concurrent.CompletableFuture;

import static net.minecraft.class_2446.*;

public class TARDIFRecipeProvider extends FabricRecipeProvider {


    public TARDIFRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 wrapperLookup, class_8790 recipeExporter) {
        return new class_2446(wrapperLookup, recipeExporter) {
            @Override
            public void method_10419() {

                // WHITE
                class_3981.method_17969(class_1856.method_8101(class_2246.field_9978), class_7800.field_40634, TARDIFBlocks.WHITE_ROUNDEL, 1).method_17970("has_grey_stained_quartz", method_10426(class_2246.field_9978)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/white_roundel")));
                class_3981.method_17969(class_1856.method_8101(class_2246.field_9978), class_7800.field_40634, TARDIFBlocks.WHITE_ROUNDEL_HALF, 2).method_17970("has_grey_stained_quartz", method_10426(class_2246.field_9978)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/white_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(class_2246.field_9978), class_7800.field_40634, class_2246.field_10601, 2).method_17970("has_grey_stained_quartz", method_10426(class_2246.field_9978)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(class_2246.field_9978), class_7800.field_40634, class_2246.field_10245, 1).method_17970("has_grey_stained_quartz", method_10426(class_2246.field_9978)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/quartz_stairs")));

                // GREY
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.GRAY_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.GRAY_ROUNDEL, 1).method_17970("has_grey_stained_quartz", method_10426(TARDIFBlocks.GRAY_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/grey_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.GRAY_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.GRAY_ROUNDEL_HALF, 2).method_17970("has_grey_stained_quartz", method_10426(TARDIFBlocks.GRAY_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/grey_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.GRAY_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.GRAY_STAINED_QUARTZ_SLAB, 2).method_17970("has_grey_stained_quartz", method_10426(TARDIFBlocks.GRAY_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/grey_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.GRAY_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.GRAY_STAINED_QUARTZ_STAIRS, 1).method_17970("has_grey_stained_quartz", method_10426(TARDIFBlocks.GRAY_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/grey_stained_quartz_stairs")));

                // DARK GREY
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.DARK_GRAY_ROUNDEL, 1).method_17970("has_dark_grey_stained_quartz", method_10426(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/dark_grey_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.DARK_GRAY_ROUNDEL_HALF, 2).method_17970("has_dark_grey_stained_quartz", method_10426(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/dark_grey_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ_SLAB, 2).method_17970("has_dark_grey_stained_quartz", method_10426(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/dark_grey_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ_STAIRS, 1).method_17970("has_dark_grey_stained_quartz", method_10426(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/dark_grey_stained_quartz_stairs")));

                // BLACK
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BLACK_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BLACK_ROUNDEL, 1).method_17970("has_black_stained_quartz", method_10426(TARDIFBlocks.BLACK_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/black_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BLACK_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BLACK_ROUNDEL_HALF, 2).method_17970("has_black_stained_quartz", method_10426(TARDIFBlocks.BLACK_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/black_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BLACK_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BLACK_STAINED_QUARTZ_SLAB, 2).method_17970("has_black_stained_quartz", method_10426(TARDIFBlocks.BLACK_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/black_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BLACK_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BLACK_STAINED_QUARTZ_STAIRS, 1).method_17970("has_black_stained_quartz", method_10426(TARDIFBlocks.BLACK_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/black_stained_quartz_stairs")));

                // BROWN
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BROWN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BROWN_ROUNDEL, 1).method_17970("has_brown_stained_quartz", method_10426(TARDIFBlocks.BROWN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/brown_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BROWN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BROWN_ROUNDEL_HALF, 2).method_17970("has_brown_stained_quartz", method_10426(TARDIFBlocks.BROWN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/brown_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BROWN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BROWN_STAINED_QUARTZ_SLAB, 2).method_17970("has_brown_stained_quartz", method_10426(TARDIFBlocks.BROWN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/brown_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BROWN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BROWN_STAINED_QUARTZ_STAIRS, 1).method_17970("has_brown_stained_quartz", method_10426(TARDIFBlocks.BROWN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/brown_stained_quartz_stairs")));

                // RED
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.RED_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.RED_ROUNDEL, 1).method_17970("has_red_stained_quartz", method_10426(TARDIFBlocks.RED_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/red_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.RED_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.RED_ROUNDEL_HALF, 2).method_17970("has_red_stained_quartz", method_10426(TARDIFBlocks.RED_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/red_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.RED_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.RED_STAINED_QUARTZ_SLAB, 2).method_17970("has_red_stained_quartz", method_10426(TARDIFBlocks.RED_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/red_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.RED_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.RED_STAINED_QUARTZ_STAIRS, 1).method_17970("has_red_stained_quartz", method_10426(TARDIFBlocks.RED_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/red_stained_quartz_stairs")));

                // ORANGE
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.ORANGE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.ORANGE_ROUNDEL, 1).method_17970("has_orange_stained_quartz", method_10426(TARDIFBlocks.ORANGE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/orange_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.ORANGE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.ORANGE_ROUNDEL_HALF, 2).method_17970("has_orange_stained_quartz", method_10426(TARDIFBlocks.ORANGE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/orange_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.ORANGE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.ORANGE_STAINED_QUARTZ_SLAB, 2).method_17970("has_orange_stained_quartz", method_10426(TARDIFBlocks.ORANGE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/orange_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.ORANGE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.ORANGE_STAINED_QUARTZ_STAIRS, 1).method_17970("has_orange_stained_quartz", method_10426(TARDIFBlocks.ORANGE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/orange_stained_quartz_stairs")));

                // YELLOW
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.YELLOW_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.YELLOW_ROUNDEL, 1).method_17970("has_yellow_stained_quartz", method_10426(TARDIFBlocks.YELLOW_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/yellow_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.YELLOW_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.YELLOW_ROUNDEL_HALF, 2).method_17970("has_yellow_stained_quartz", method_10426(TARDIFBlocks.YELLOW_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/yellow_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.YELLOW_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.YELLOW_STAINED_QUARTZ_SLAB, 2).method_17970("has_yellow_stained_quartz", method_10426(TARDIFBlocks.YELLOW_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/yellow_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.YELLOW_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.YELLOW_STAINED_QUARTZ_STAIRS, 1).method_17970("has_yellow_stained_quartz", method_10426(TARDIFBlocks.YELLOW_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/yellow_stained_quartz_stairs")));

                // LIME
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.LIME_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.LIME_ROUNDEL, 1).method_17970("has_lime_stained_quartz", method_10426(TARDIFBlocks.LIME_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/lime_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.LIME_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.LIME_ROUNDEL_HALF, 2).method_17970("has_lime_stained_quartz", method_10426(TARDIFBlocks.LIME_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/lime_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.LIME_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.LIME_STAINED_QUARTZ_SLAB, 2).method_17970("has_lime_stained_quartz", method_10426(TARDIFBlocks.LIME_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/lime_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.LIME_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.LIME_STAINED_QUARTZ_STAIRS, 1).method_17970("has_lime_stained_quartz", method_10426(TARDIFBlocks.LIME_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/lime_stained_quartz_stairs")));

                // GREEN
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.GREEN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.GREEN_ROUNDEL, 1).method_17970("has_green_stained_quartz", method_10426(TARDIFBlocks.GREEN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/green_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.GREEN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.GREEN_ROUNDEL_HALF, 2).method_17970("has_green_stained_quartz", method_10426(TARDIFBlocks.GREEN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/green_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.GREEN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.GREEN_STAINED_QUARTZ_SLAB, 2).method_17970("has_green_stained_quartz", method_10426(TARDIFBlocks.GREEN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/green_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.GREEN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.GREEN_STAINED_QUARTZ_STAIRS, 1).method_17970("has_green_stained_quartz", method_10426(TARDIFBlocks.GREEN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/green_stained_quartz_stairs")));

                // CYAN
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.CYAN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.CYAN_ROUNDEL, 1).method_17970("has_cyan_stained_quartz", method_10426(TARDIFBlocks.CYAN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/cyan_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.CYAN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.CYAN_ROUNDEL_HALF, 2).method_17970("has_cyan_stained_quartz", method_10426(TARDIFBlocks.CYAN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/cyan_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.CYAN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.CYAN_STAINED_QUARTZ_SLAB, 2).method_17970("has_cyan_stained_quartz", method_10426(TARDIFBlocks.CYAN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/cyan_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.CYAN_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.CYAN_STAINED_QUARTZ_STAIRS, 1).method_17970("has_cyan_stained_quartz", method_10426(TARDIFBlocks.CYAN_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/cyan_stained_quartz_stairs")));

                // LIGHT_BLUE
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.LIGHT_BLUE_ROUNDEL, 1).method_17970("has_light_blue_stained_quartz", method_10426(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/light_blue_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.LIGHT_BLUE_ROUNDEL_HALF, 2).method_17970("has_light_blue_stained_quartz", method_10426(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/light_blue_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ_SLAB, 2).method_17970("has_light_blue_stained_quartz", method_10426(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/light_blue_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ_STAIRS, 1).method_17970("has_light_blue_stained_quartz", method_10426(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/light_blue_stained_quartz_stairs")));

                // BLUE
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BLUE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BLUE_ROUNDEL, 1).method_17970("has_blue_stained_quartz", method_10426(TARDIFBlocks.BLUE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/blue_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BLUE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BLUE_ROUNDEL_HALF, 2).method_17970("has_blue_stained_quartz", method_10426(TARDIFBlocks.BLUE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/blue_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BLUE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BLUE_STAINED_QUARTZ_SLAB, 2).method_17970("has_blue_stained_quartz", method_10426(TARDIFBlocks.BLUE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/blue_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.BLUE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.BLUE_STAINED_QUARTZ_STAIRS, 1).method_17970("has_blue_stained_quartz", method_10426(TARDIFBlocks.BLUE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/blue_stained_quartz_stairs")));

                // PURPLE
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.PURPLE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.PURPLE_ROUNDEL, 1).method_17970("has_purple_stained_quartz", method_10426(TARDIFBlocks.PURPLE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/purple_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.PURPLE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.PURPLE_ROUNDEL_HALF, 2).method_17970("has_purple_stained_quartz", method_10426(TARDIFBlocks.PURPLE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/purple_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.PURPLE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.PURPLE_STAINED_QUARTZ_SLAB, 2).method_17970("has_purple_stained_quartz", method_10426(TARDIFBlocks.PURPLE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/purple_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.PURPLE_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.PURPLE_STAINED_QUARTZ_STAIRS, 1).method_17970("has_purple_stained_quartz", method_10426(TARDIFBlocks.PURPLE_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/purple_stained_quartz_stairs")));

                // MAGENTA
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.MAGENTA_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.MAGENTA_ROUNDEL, 1).method_17970("has_magenta_stained_quartz", method_10426(TARDIFBlocks.MAGENTA_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/magenta_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.MAGENTA_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.MAGENTA_ROUNDEL_HALF, 2).method_17970("has_magenta_stained_quartz", method_10426(TARDIFBlocks.MAGENTA_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/magenta_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.MAGENTA_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.MAGENTA_STAINED_QUARTZ_SLAB, 2).method_17970("has_magenta_stained_quartz", method_10426(TARDIFBlocks.MAGENTA_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/magenta_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.MAGENTA_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.MAGENTA_STAINED_QUARTZ_STAIRS, 1).method_17970("has_magenta_stained_quartz", method_10426(TARDIFBlocks.MAGENTA_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/magenta_stained_quartz_stairs")));

                // PINK
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.PINK_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.PINK_ROUNDEL, 1).method_17970("has_pink_stained_quartz", method_10426(TARDIFBlocks.PINK_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/pink_roundel")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.PINK_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.PINK_ROUNDEL_HALF, 2).method_17970("has_pink_stained_quartz", method_10426(TARDIFBlocks.PINK_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/pink_roundel_half")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.PINK_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.PINK_STAINED_QUARTZ_SLAB, 2).method_17970("has_pink_stained_quartz", method_10426(TARDIFBlocks.PINK_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/pink_stained_quartz_slab")));
                class_3981.method_17969(class_1856.method_8101(TARDIFBlocks.PINK_STAINED_QUARTZ), class_7800.field_40634, TARDIFBlocks.PINK_STAINED_QUARTZ_STAIRS, 1).method_17970("has_pink_stained_quartz", method_10426(TARDIFBlocks.PINK_STAINED_QUARTZ)).method_17972(field_53721, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TARDIFMod.MOD_ID, "stonecutting/pink_stained_quartz_stairs")));

                method_62746(class_7800.field_40634, TARDIFBlocks.CRYSTALLINE_BLOCK)
                        .method_10439("###")
                        .method_10439("###")
                        .method_10439("###")
                        .method_10434('#', TARDIFItems.CRYSTALLINE_SHARD)
                        .method_10429("has_tardis_crystal", method_10426(TARDIFItems.CRYSTALLINE_SHARD))
                        .method_10431(recipeExporter);

                method_32808(
                        TARDIFBlocks.CRYSTALLINE_STAIR,
                        class_1856.method_8101(TARDIFItems.CRYSTALLINE_SHARD));

                method_32804(
                        class_7800.field_40634,
                        TARDIFBlocks.CRYSTALLINE_SLAB,
                        class_1856.method_8101(TARDIFItems.CRYSTALLINE_SHARD));

            }
        };
    }

    @Override
    public String method_10321() {
        return "TARDIF Mod Recipes";
    }
}