package net.maketendo.tardifmod.datagen.providers;

import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.main.TARDIFBlocks;
import net.maketendo.tardifmod.main.TARDIFItems;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4925;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.class_4946;
import net.minecraft.class_807;
import net.minecraft.client.data.models.model.*;
import java.util.*;


public class TARDIFModModelProvider extends FabricModelProvider {
    public TARDIFModModelProvider(FabricDataOutput output) {
        super(output);
    }

    public static final class_4942 GENERATED_KEY = item("key_generated", class_4945.field_23006);;

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {

        blockStateModelGenerator.method_25631(TARDIFBlocks.WHITE_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.WHITE_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.GRAY_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.GRAY_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.DARK_GRAY_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.DARK_GRAY_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.BLACK_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.BLACK_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.BROWN_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.BROWN_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.RED_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.RED_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.ORANGE_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.ORANGE_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.YELLOW_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.YELLOW_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.LIME_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.LIME_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.GREEN_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.GREEN_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.CYAN_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.CYAN_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.LIGHT_BLUE_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.LIGHT_BLUE_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.BLUE_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.BLUE_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.PURPLE_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.PURPLE_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.MAGENTA_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.MAGENTA_ROUNDEL_HALF);
        blockStateModelGenerator.method_25631(TARDIFBlocks.PINK_ROUNDEL);
        blockStateModelGenerator.method_25631(TARDIFBlocks.PINK_ROUNDEL_HALF);

        blockStateModelGenerator.method_25553(
                TARDIFBlocks.HALF_CHISELED_QUARTZ,
                class_4946.field_23038
        );

        createRedstoneLamp(blockStateModelGenerator, TARDIFBlocks.REDSTONE_ROUNDEL);
        createRedstoneLamp(blockStateModelGenerator, TARDIFBlocks.REDSTONE_ROUNDEL_HALF);

        blockStateModelGenerator.method_25641(TARDIFBlocks.INTERIOR_DOOR_GENERATOR_BLOCK);
        blockStateModelGenerator.method_25641(TARDIFBlocks.TARDIS_LIGHT_BLOCK);

//        blockStateModelGenerator.registerBuiltinWithParticle(TARDIFBlocks.POWER_PANEL, Blocks.IRON_BLOCK);
//        blockStateModelGenerator.registerBuiltinWithParticle(TARDIFBlocks.COORDINATES_PANEL, Blocks.IRON_BLOCK);
//        blockStateModelGenerator.registerBuiltinWithParticle(TARDIFBlocks.DEMATERIALISATION_PANEL, Blocks.IRON_BLOCK);
        blockStateModelGenerator.method_65403(TARDIFBlocks.TARDIS_CONSOLE_BLOCK, class_2246.field_22122);

        class_4910.class_4912 crystallinePool = blockStateModelGenerator.method_25650(TARDIFBlocks.CRYSTALLINE_BLOCK);
        crystallinePool.method_25725(TARDIFBlocks.CRYSTALLINE_STAIR);
        crystallinePool.method_25724(TARDIFBlocks.CRYSTALLINE_SLAB);

        class_4910.class_4912 greyStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.GRAY_STAINED_QUARTZ);
        greyStainedQuartzPool.method_25725(TARDIFBlocks.GRAY_STAINED_QUARTZ_STAIRS);
        greyStainedQuartzPool.method_25724(TARDIFBlocks.GRAY_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 darkGreyStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ);
        darkGreyStainedQuartzPool.method_25725(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ_STAIRS);
        darkGreyStainedQuartzPool.method_25724(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 blackStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.BLACK_STAINED_QUARTZ);
        blackStainedQuartzPool.method_25725(TARDIFBlocks.BLACK_STAINED_QUARTZ_STAIRS);
        blackStainedQuartzPool.method_25724(TARDIFBlocks.BLACK_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 brownStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.BROWN_STAINED_QUARTZ);
        brownStainedQuartzPool.method_25725(TARDIFBlocks.BROWN_STAINED_QUARTZ_STAIRS);
        brownStainedQuartzPool.method_25724(TARDIFBlocks.BROWN_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 redStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.RED_STAINED_QUARTZ);
        redStainedQuartzPool.method_25725(TARDIFBlocks.RED_STAINED_QUARTZ_STAIRS);
        redStainedQuartzPool.method_25724(TARDIFBlocks.RED_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 orangeStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.ORANGE_STAINED_QUARTZ);
        orangeStainedQuartzPool.method_25725(TARDIFBlocks.ORANGE_STAINED_QUARTZ_STAIRS);
        orangeStainedQuartzPool.method_25724(TARDIFBlocks.ORANGE_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 yellowStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.YELLOW_STAINED_QUARTZ);
        yellowStainedQuartzPool.method_25725(TARDIFBlocks.YELLOW_STAINED_QUARTZ_STAIRS);
        yellowStainedQuartzPool.method_25724(TARDIFBlocks.YELLOW_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 limeStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.LIME_STAINED_QUARTZ);
        limeStainedQuartzPool.method_25725(TARDIFBlocks.LIME_STAINED_QUARTZ_STAIRS);
        limeStainedQuartzPool.method_25724(TARDIFBlocks.LIME_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 greenStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.GREEN_STAINED_QUARTZ);
        greenStainedQuartzPool.method_25725(TARDIFBlocks.GREEN_STAINED_QUARTZ_STAIRS);
        greenStainedQuartzPool.method_25724(TARDIFBlocks.GREEN_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 cyanStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.CYAN_STAINED_QUARTZ);
        cyanStainedQuartzPool.method_25725(TARDIFBlocks.CYAN_STAINED_QUARTZ_STAIRS);
        cyanStainedQuartzPool.method_25724(TARDIFBlocks.CYAN_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 lightBlueStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ);
        lightBlueStainedQuartzPool.method_25725(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ_STAIRS);
        lightBlueStainedQuartzPool.method_25724(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 blueStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.BLUE_STAINED_QUARTZ);
        blueStainedQuartzPool.method_25725(TARDIFBlocks.BLUE_STAINED_QUARTZ_STAIRS);
        blueStainedQuartzPool.method_25724(TARDIFBlocks.BLUE_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 purpleStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.PURPLE_STAINED_QUARTZ);
        purpleStainedQuartzPool.method_25725(TARDIFBlocks.PURPLE_STAINED_QUARTZ_STAIRS);
        purpleStainedQuartzPool.method_25724(TARDIFBlocks.PURPLE_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 magentaStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.MAGENTA_STAINED_QUARTZ);
        magentaStainedQuartzPool.method_25725(TARDIFBlocks.MAGENTA_STAINED_QUARTZ_STAIRS);
        magentaStainedQuartzPool.method_25724(TARDIFBlocks.MAGENTA_STAINED_QUARTZ_SLAB);

        class_4910.class_4912 pinkStainedQuartzPool = blockStateModelGenerator.method_25650(TARDIFBlocks.PINK_STAINED_QUARTZ);
        pinkStainedQuartzPool.method_25725(TARDIFBlocks.PINK_STAINED_QUARTZ_STAIRS);
        pinkStainedQuartzPool.method_25724(TARDIFBlocks.PINK_STAINED_QUARTZ_SLAB);

    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_65442(TARDIFItems.GOLD_TARDIS_KEY, GENERATED_KEY);
        itemModelGenerator.method_65442(TARDIFItems.SILVER_TARDIS_KEY, GENERATED_KEY);
        itemModelGenerator.method_65442(TARDIFItems.TARDIS_ITEM, class_4943.field_22938);

        itemModelGenerator.method_65442(TARDIFItems.CRYSTALLINE_SHARD, class_4943.field_22938);
        itemModelGenerator.method_65442(TARDIFItems.SONIC_SCREWDRIVER, class_4943.field_22938);

        itemModelGenerator.method_65442(TARDIFBlocks.TARDIS_LIGHT_BLOCK.method_8389(), class_4943.field_22938);
        itemModelGenerator.method_65442(TARDIFBlocks.TARDIS_CONSOLE_BLOCK.method_8389(), class_4943.field_22938);
//        itemModelGenerator.register(TARDIFBlocks.POWER_PANEL.asItem(), Models.GENERATED);
//        itemModelGenerator.register(TARDIFBlocks.COORDINATES_PANEL.asItem(), Models.GENERATED);
//        itemModelGenerator.register(TARDIFBlocks.DEMATERIALISATION_PANEL.asItem(), Models.GENERATED);
    }

    private static class_4942 item(String parent, class_4945... requiredTextureKeys) {
        return new class_4942(Optional.of(class_2960.method_60655(TARDIFMod.MOD_ID, "item/" + parent)), Optional.empty(), requiredTextureKeys);
    }

    private void createRedstoneLamp(class_4910 blockModelGenerators, class_2248 lamp) {
        class_807 multiVariant = blockModelGenerators.method_67835(class_4946.field_23036.method_25923(lamp, blockModelGenerators.field_22831));
        class_807 multiVariant2 = blockModelGenerators.method_67835(blockModelGenerators.method_25557(lamp, "_on", class_4943.field_22972, class_4944::method_25875));
        blockModelGenerators.field_22830.accept(class_4925.method_67852(lamp).method_67859(blockModelGenerators.method_25565(class_2741.field_12548, multiVariant2, multiVariant)));
    }
}
