package net.maketendo.tardifmod.datagen.providers.lootables;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.SimpleFabricLootTableProvider;
import net.minecraft.class_176;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;

public class TARDIFModChestLootTableProvider extends SimpleFabricLootTableProvider {

    public TARDIFModChestLootTableProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registryLookup, class_176 contextType) {
        super(output, registryLookup, contextType);
    }

    @Override
    public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> lootTableBiConsumer) {

    }
}
