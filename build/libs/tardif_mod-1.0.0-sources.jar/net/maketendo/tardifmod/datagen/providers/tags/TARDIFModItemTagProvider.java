package net.maketendo.tardifmod.datagen.providers.tags;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.maketendo.tardifmod.main.TARDIFItems;
import net.maketendo.tardifmod.main.TARDIFTags;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import org.jspecify.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

public class TARDIFModItemTagProvider extends FabricTagProvider.ItemTagProvider {

    public TARDIFModItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        valueLookupBuilder(TARDIFTags.Items.TARDIS_KEYS)
                .method_71554(TARDIFItems.GOLD_TARDIS_KEY)
                .method_71554(TARDIFItems.SILVER_TARDIS_KEY);

        valueLookupBuilder(TARDIFTags.Items.LINKABLE_ITEMS)
                .method_71554(TARDIFItems.GOLD_TARDIS_KEY)
                .method_71554(TARDIFItems.SILVER_TARDIS_KEY);

        valueLookupBuilder(TARDIFTags.Items.PAINT_BRUSH)
                .method_71554(class_1802.field_42716);
    }
}