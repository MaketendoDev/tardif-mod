package net.maketendo.tardifmod.datagen.providers.lootables;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.maketendo.tardifmod.main.TARDIFBlocks;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class TARDIFModBlockLootTableProvider extends FabricBlockLootTableProvider {

    public TARDIFModBlockLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {

        method_46025(TARDIFBlocks.GRAY_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.BLACK_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.BROWN_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.RED_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.ORANGE_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.YELLOW_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.LIME_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.GREEN_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.CYAN_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.BLUE_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.PURPLE_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.MAGENTA_STAINED_QUARTZ);
        method_46025(TARDIFBlocks.PINK_STAINED_QUARTZ);

        method_46025(TARDIFBlocks.HALF_CHISELED_QUARTZ);

        method_46025(TARDIFBlocks.REDSTONE_ROUNDEL);
        method_46025(TARDIFBlocks.REDSTONE_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.WHITE_ROUNDEL);
        method_46025(TARDIFBlocks.WHITE_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.GRAY_ROUNDEL);
        method_46025(TARDIFBlocks.GRAY_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.DARK_GRAY_ROUNDEL);
        method_46025(TARDIFBlocks.DARK_GRAY_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.BLACK_ROUNDEL);
        method_46025(TARDIFBlocks.BLACK_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.BROWN_ROUNDEL);
        method_46025(TARDIFBlocks.BROWN_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.RED_ROUNDEL);
        method_46025(TARDIFBlocks.RED_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.ORANGE_ROUNDEL);
        method_46025(TARDIFBlocks.ORANGE_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.YELLOW_ROUNDEL);
        method_46025(TARDIFBlocks.YELLOW_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.LIME_ROUNDEL);
        method_46025(TARDIFBlocks.LIME_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.GREEN_ROUNDEL);
        method_46025(TARDIFBlocks.GREEN_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.CYAN_ROUNDEL);
        method_46025(TARDIFBlocks.CYAN_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.LIGHT_BLUE_ROUNDEL);
        method_46025(TARDIFBlocks.LIGHT_BLUE_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.BLUE_ROUNDEL);
        method_46025(TARDIFBlocks.BLUE_ROUNDEL);
        method_46025(TARDIFBlocks.PURPLE_ROUNDEL);
        method_46025(TARDIFBlocks.PURPLE_ROUNDEL);
        method_46025(TARDIFBlocks.MAGENTA_ROUNDEL);
        method_46025(TARDIFBlocks.MAGENTA_ROUNDEL_HALF);
        method_46025(TARDIFBlocks.PINK_ROUNDEL);
        method_46025(TARDIFBlocks.PINK_ROUNDEL_HALF);

        method_46025(TARDIFBlocks.CRYSTALLINE_BLOCK);
        method_46025(TARDIFBlocks.CRYSTALLINE_STAIR);
        method_46025(TARDIFBlocks.CRYSTALLINE_SLAB);
    }
}
