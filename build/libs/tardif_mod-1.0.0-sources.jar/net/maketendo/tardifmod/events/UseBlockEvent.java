package net.maketendo.tardifmod.events;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.maketendo.tardifmod.main.TARDIFTags;

import net.maketendo.tardifmod.main.tardis.TardisManager;
import net.maketendo.tardifmod.utils.StainedQuartzRegistry;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class UseBlockEvent {
    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608()) return class_1269.field_5811;
            if (!(world instanceof class_3218 serverWorld)) return class_1269.field_5811;

            class_2338 pos = hitResult.method_17777().method_10093(hitResult.method_17780());

            Integer tardisId = TardisManager.getTardisInteriorId(serverWorld, pos);
            if (tardisId != null) {
                player.method_7353(
                        class_2561.method_43470("Placed block in TARDIS ID: " + tardisId),
                        false
                );
            }

            return class_1269.field_5811;
        });

    }

    public static void registerQuartz() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608()) return class_1269.field_5811;

            class_2338 pos = hitResult.method_17777();
            class_2680 state = world.method_8320(pos);

            if (!state.method_27852(class_2246.field_10153)) return class_1269.field_5811;

            if (!player.method_6079().method_31573(TARDIFTags.Items.PAINT_BRUSH)) {
                return class_1269.field_5811;
            }

            class_1799 brush = player.method_6079();
            class_2248 replacement = StainedQuartzRegistry.getFromDye(brush);
            if (replacement == null) return class_1269.field_5811;

            world.method_8501(pos, replacement.method_9564());
            world.method_8396(
                    null,
                    pos,
                    class_3417.field_29543,
                    class_3419.field_15245,
                    0.5f,
                    1f
            );

            if (!player.method_68878()) {
                brush.method_7934(1);
            }

            return class_1269.field_21466;
        });

    }
}
