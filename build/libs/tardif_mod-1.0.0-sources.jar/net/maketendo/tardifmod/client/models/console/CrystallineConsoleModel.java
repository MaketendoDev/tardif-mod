package net.maketendo.tardifmod.client.models.console;

import net.maketendo.tardifmod.TARDIFMod;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;


public class CrystallineConsoleModel<T extends class_1297> extends class_583<class_10017> {
	public static final class_5601 LAYER_LOCATION = new class_5601(class_2960.method_60655(TARDIFMod.MOD_ID, "crystalline_console"), "main");
	private final class_630 console;
	private final class_630 rotor;
	private final class_630 pannels;
	private final class_630 pannel;
	private final class_630 slope;
	private final class_630 controls;
	private final class_630 switches;
	private final class_630 switch1;
	private final class_630 switch3;
	private final class_630 switch2;
	private final class_630 tap;
	private final class_630 pannel2;
	private final class_630 slope2;
	private final class_630 controls2;
	private final class_630 tap2;
	private final class_630 topofbell;
	private final class_630 pannel3;
	private final class_630 slope3;
	private final class_630 controls3;
	private final class_630 switches2;
	private final class_630 switch4;
	private final class_630 switch5;
	private final class_630 switch6;
	private final class_630 pannel4;
	private final class_630 slope4;
	private final class_630 controls4;
	private final class_630 tap3;
	private final class_630 pannel5;
	private final class_630 slope5;
	private final class_630 controls5;
	private final class_630 switches4;
	private final class_630 switch11;
	private final class_630 switch10;
	private final class_630 switches5;
	private final class_630 switch12;
	private final class_630 switch13;
	private final class_630 switches3;
	private final class_630 switch7;
	private final class_630 switch8;
	private final class_630 switch9;
	private final class_630 pannel6;
	private final class_630 slope6;
	private final class_630 controls6;
	private final class_630 taps;
	private final class_630 taps2;
	private final class_630 taps3;
	private final class_630 taps4;
	private final class_630 dividers;
	private final class_630 dividercontrols5;
	private final class_630 dividercontrols4;
	private final class_630 hourglass2;
	private final class_630 dividercontrols;
	private final class_630 lever;
	private final class_630 lever2;
	private final class_630 dividercontrols2;
	private final class_630 dividercontrols3;
	private final class_630 hourglass;
	private final class_630 scanners;

	public CrystallineConsoleModel(class_630 root) {
        super(root);
        this.console = root.method_32086("console");
		this.rotor = this.console.method_32086("rotor");
		this.pannels = this.console.method_32086("pannels");
		this.pannel = this.pannels.method_32086("pannel");
		this.slope = this.pannel.method_32086("slope");
		this.controls = this.slope.method_32086("controls");
		this.switches = this.controls.method_32086("switches");
		this.switch1 = this.switches.method_32086("switch");
		this.switch3 = this.switches.method_32086("switch3");
		this.switch2 = this.switches.method_32086("switch2");
		this.tap = this.controls.method_32086("tap");
		this.pannel2 = this.pannels.method_32086("pannel2");
		this.slope2 = this.pannel2.method_32086("slope2");
		this.controls2 = this.slope2.method_32086("controls2");
		this.tap2 = this.controls2.method_32086("tap2");
		this.topofbell = this.controls2.method_32086("topofbell");
		this.pannel3 = this.pannels.method_32086("pannel3");
		this.slope3 = this.pannel3.method_32086("slope3");
		this.controls3 = this.slope3.method_32086("controls3");
		this.switches2 = this.controls3.method_32086("switches2");
		this.switch4 = this.switches2.method_32086("switch4");
		this.switch5 = this.switches2.method_32086("switch5");
		this.switch6 = this.switches2.method_32086("switch6");
		this.pannel4 = this.pannels.method_32086("pannel4");
		this.slope4 = this.pannel4.method_32086("slope4");
		this.controls4 = this.slope4.method_32086("controls4");
		this.tap3 = this.controls4.method_32086("tap3");
		this.pannel5 = this.pannels.method_32086("pannel5");
		this.slope5 = this.pannel5.method_32086("slope5");
		this.controls5 = this.slope5.method_32086("controls5");
		this.switches4 = this.controls5.method_32086("switches4");
		this.switch11 = this.switches4.method_32086("switch11");
		this.switch10 = this.switches4.method_32086("switch10");
		this.switches5 = this.controls5.method_32086("switches5");
		this.switch12 = this.switches5.method_32086("switch12");
		this.switch13 = this.switches5.method_32086("switch13");
		this.switches3 = this.controls5.method_32086("switches3");
		this.switch7 = this.switches3.method_32086("switch7");
		this.switch8 = this.switches3.method_32086("switch8");
		this.switch9 = this.switches3.method_32086("switch9");
		this.pannel6 = this.pannels.method_32086("pannel6");
		this.slope6 = this.pannel6.method_32086("slope6");
		this.controls6 = this.slope6.method_32086("controls6");
		this.taps = this.controls6.method_32086("taps");
		this.taps2 = this.taps.method_32086("taps2");
		this.taps3 = this.taps.method_32086("taps3");
		this.taps4 = this.taps.method_32086("taps4");
		this.dividers = this.console.method_32086("dividers");
		this.dividercontrols5 = this.dividers.method_32086("dividercontrols5");
		this.dividercontrols4 = this.dividers.method_32086("dividercontrols4");
		this.hourglass2 = this.dividercontrols4.method_32086("hourglass2");
		this.dividercontrols = this.dividers.method_32086("dividercontrols");
		this.lever = this.dividercontrols.method_32086("lever");
		this.lever2 = this.dividercontrols.method_32086("lever2");
		this.dividercontrols2 = this.dividers.method_32086("dividercontrols2");
		this.dividercontrols3 = this.dividers.method_32086("dividercontrols3");
		this.hourglass = this.dividercontrols3.method_32086("hourglass");
		this.scanners = this.dividers.method_32086("scanners");
	}

	public static class_5607 createBodyLayer() {
		class_5609 meshdefinition = new class_5609();
		class_5610 partdefinition = meshdefinition.method_32111();

		class_5610 console = partdefinition.method_32117("console", class_5606.method_32108(), class_5603.method_32090(0.0F, 24.0F, 0.0F));

		class_5610 rotor = console.method_32117("rotor", class_5606.method_32108(), class_5603.method_32090(8.0F, -2.0F, -8.0F));

		class_5610 cube_r1 = rotor.method_32117("cube_r1", class_5606.method_32108().method_32101(0, 69).method_32098(0.0F, -15.5F, -7.0F, 0.0F, 43.0F, 14.0F, new class_5605(0.0F))
		.method_32101(0, 83).method_32096().method_32098(-7.0F, -15.5F, 0.0F, 14.0F, 43.0F, 0.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32091(-8.0F, -26.5F, 8.0F, 0.0F, 2.3562F, 0.0F));

		class_5610 pannels = console.method_32117("pannels", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 pannel = pannels.method_32117("pannel", class_5606.method_32108().method_32101(44, 12).method_32098(-5.0F, -21.998F, -7.6602F, 10.0F, 11.0F, 1.0F, new class_5605(0.0F))
		.method_32101(-3, 56).method_32098(-5.0F, -22.001F, -10.6602F, 10.0F, 0.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 35).method_32098(-10.0F, -15.1F, -19.0526F, 20.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 cube_r2 = pannel.method_32117("cube_r2", class_5606.method_32108().method_32101(29, 0).method_32098(-11.0F, -6.0F, 5.6F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.5708F, 0.0F, 0.0F));

		class_5610 slope = pannel.method_32117("slope", class_5606.method_32108().method_32101(0, 66).method_32098(-11.0F, -6.0F, -0.2F, 22.0F, 14.0F, 0.0F, new class_5605(0.0F))
		.method_32101(0, 43).method_32098(-11.0F, -4.1F, -0.8F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.2654F, 0.0F, 0.0F));

		class_5610 controls = slope.method_32117("controls", class_5606.method_32108().method_32101(22, 29).method_32098(-1.0F, -2.0F, -3.0F, 2.0F, 2.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 15).method_32098(-2.0F, -3.0F, -4.0F, 4.0F, 4.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 cube_r3 = controls.method_32117("cube_r3", class_5606.method_32108().method_32101(51, 31).method_32098(1.3767F, 0.6696F, -1.4021F, 2.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(-1.0F, -0.3F, -0.5F, 0.0F, 0.0F, 0.7854F));

		class_5610 cube_r4 = controls.method_32117("cube_r4", class_5606.method_32108().method_32101(51, 31).method_32098(1.3767F, 0.6696F, -1.4021F, 2.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(-1.0F, 3.0F, -0.5F, 0.0F, 0.0F, 0.7854F));

		class_5610 switches = controls.method_32117("switches", class_5606.method_32108().method_32101(22, 21).method_32098(-0.5F, -3.0F, -0.5F, 2.0F, 6.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(-7.5F, 4.0F, -0.1F, 0.0F, 0.0F, 0.5236F));

		class_5610 switch1 = switches.method_32117("switch", class_5606.method_32108().method_32101(47, 26).method_32098(-1.0F, 0.0F, -2.0F, 2.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.5F, 2.0F, -0.5F));

		class_5610 switch3 = switches.method_32117("switch3", class_5606.method_32108().method_32101(47, 26).method_32098(-1.0F, 0.0F, -2.0F, 2.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.5F, -2.0F, -0.5F));

		class_5610 switch2 = switches.method_32117("switch2", class_5606.method_32108().method_32101(47, 26).method_32096().method_32098(-1.0F, 0.0F, -2.0F, 2.0F, 0.0F, 2.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32090(0.5F, 0.0F, -0.5F));

		class_5610 tap = controls.method_32117("tap", class_5606.method_32108().method_32101(42, 29).method_32098(-0.4F, -0.5F, -2.6F, 1.0F, 1.0F, 3.0F, new class_5605(0.0F))
		.method_32101(24, 20).method_32098(-0.5F, -0.5F, -2.4F, 2.0F, 1.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32090(1.9F, 3.3F, -0.2F));

		class_5610 pannel2 = pannels.method_32117("pannel2", class_5606.method_32108().method_32101(44, 12).method_32098(-5.0F, -22.0F, -7.6602F, 10.0F, 11.0F, 1.0F, new class_5605(0.0F))
		.method_32101(-3, 56).method_32098(-5.0F, -22.002F, -10.6602F, 10.0F, 0.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 35).method_32098(-10.0F, -15.1F, -19.0526F, 20.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -1.0472F, 0.0F));

		class_5610 cube_r5 = pannel2.method_32117("cube_r5", class_5606.method_32108().method_32101(29, 0).method_32098(-11.0F, -6.0F, 5.6F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.5708F, 0.0F, 0.0F));

		class_5610 slope2 = pannel2.method_32117("slope2", class_5606.method_32108().method_32101(0, 66).method_32098(-11.0F, -6.0F, -0.2F, 22.0F, 14.0F, 0.0F, new class_5605(0.0F))
		.method_32101(0, 43).method_32098(-11.0F, -4.1F, -0.8F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F))
		.method_32101(84, 24).method_32098(-11.0F, -4.1F, -0.9F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.2654F, 0.0F, 0.0F));

		class_5610 controls2 = slope2.method_32117("controls2", class_5606.method_32108().method_32101(32, 29).method_32098(-1.0F, -2.0F, -1.0F, 3.0F, 3.0F, 2.0F, new class_5605(0.02F))
		.method_32101(12, 15).method_32096().method_32098(2.0F, -8.1F, -3.0F, 2.0F, 2.0F, 4.0F, new class_5605(0.0F)).method_32106(false)
		.method_32101(12, 15).method_32098(-3.0F, -8.1F, -3.0F, 2.0F, 2.0F, 4.0F, new class_5605(0.0F)), class_5603.method_32090(-0.5F, 5.0F, -0.7F));

		class_5610 cube_r6 = controls2.method_32117("cube_r6", class_5606.method_32108().method_32101(44, 46).method_32098(-1.5F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new class_5605(0.1F)), class_5603.method_32091(0.5F, -7.1F, -2.0F, -0.7854F, 0.0F, 0.0F));

		class_5610 cube_r7 = controls2.method_32117("cube_r7", class_5606.method_32108().method_32101(51, 31).method_32098(-1.0F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(3.0F, -4.3F, -0.5F, 0.0F, 0.0F, 0.7854F));

		class_5610 tap2 = controls2.method_32117("tap2", class_5606.method_32108().method_32101(53, 24).method_32098(-0.5F, 0.0F, -1.5F, 1.0F, 1.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 34).method_32098(-1.4F, 0.0F, -1.2F, 2.0F, 1.0F, 0.0F, new class_5605(0.0F))
		.method_32101(0, 34).method_32098(-4.4F, 1.0F, -1.2F, 2.0F, 1.0F, 0.0F, new class_5605(0.0F))
		.method_32101(53, 24).method_32098(-3.5F, 1.0F, -1.5F, 1.0F, 1.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32090(0.5F, -5.3F, -0.5F));

		class_5610 topofbell = controls2.method_32117("topofbell", class_5606.method_32108().method_32101(51, 34).method_32098(-1.0F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new class_5605(-0.1F)), class_5603.method_32090(0.5F, -0.5F, -1.1F));

		class_5610 pannel3 = pannels.method_32117("pannel3", class_5606.method_32108().method_32101(44, 12).method_32098(-5.0F, -21.998F, -7.6602F, 10.0F, 11.0F, 1.0F, new class_5605(0.0F))
		.method_32101(-3, 56).method_32098(-5.0F, -22.001F, -10.6602F, 10.0F, 0.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 35).method_32098(-10.0F, -15.1F, -19.0526F, 20.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, -1.0472F, 3.1416F));

		class_5610 cube_r8 = pannel3.method_32117("cube_r8", class_5606.method_32108().method_32101(29, 0).method_32098(-11.0F, -6.0F, 5.6F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.5708F, 0.0F, 0.0F));

		class_5610 slope3 = pannel3.method_32117("slope3", class_5606.method_32108().method_32101(0, 66).method_32098(-11.0F, -6.0F, -0.2F, 22.0F, 14.0F, 0.0F, new class_5605(0.0F))
		.method_32101(0, 43).method_32098(-11.0F, -4.1F, -0.8F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F))
		.method_32101(66, 12).method_32098(-11.0F, -4.1F, -0.9F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.2654F, 0.0F, 0.0F));

		class_5610 controls3 = slope3.method_32117("controls3", class_5606.method_32108().method_32101(12, 21).method_32098(-2.0F, 1.4F, -1.8F, 4.0F, 5.0F, 1.0F, new class_5605(0.0F))
		.method_32101(37, 19).method_32098(-1.0F, -4.0F, -1.4F, 2.0F, 3.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 cube_r9 = controls3.method_32117("cube_r9", class_5606.method_32108().method_32101(10, 32).method_32098(-2.5F, -0.5F, -0.5F, 5.0F, 1.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, -0.9F, 0.0F, 0.0F, 0.0524F));

		class_5610 switches2 = controls3.method_32117("switches2", class_5606.method_32108().method_32101(22, 21).method_32098(-4.0F, -0.5F, 0.5F, 2.0F, 6.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(-3.0F, 3.9F, -1.3F, 0.0F, 0.0F, 0.5236F));

		class_5610 switch4 = switches2.method_32117("switch4", class_5606.method_32108().method_32101(47, 26).method_32098(-1.0F, 0.0F, -2.0F, 2.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(-3.0F, 4.5F, 0.5F));

		class_5610 switch5 = switches2.method_32117("switch5", class_5606.method_32108().method_32101(47, 26).method_32096().method_32098(-1.0F, 0.0F, -2.0F, 2.0F, 0.0F, 2.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32090(-3.0F, 2.5F, 0.5F));

		class_5610 switch6 = switches2.method_32117("switch6", class_5606.method_32108().method_32101(47, 26).method_32098(-1.0F, 0.0F, -2.0F, 2.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(-3.0F, 0.5F, 0.5F));

		class_5610 pannel4 = pannels.method_32117("pannel4", class_5606.method_32108().method_32101(44, 12).method_32098(-5.0F, -22.0F, -7.6602F, 10.0F, 11.0F, 1.0F, new class_5605(0.0F))
		.method_32101(-3, 56).method_32098(-5.0F, -22.002F, -10.6602F, 10.0F, 0.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 35).method_32098(-10.0F, -15.1F, -19.0526F, 20.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 0.0F, 3.1416F));

		class_5610 cube_r10 = pannel4.method_32117("cube_r10", class_5606.method_32108().method_32101(29, 0).method_32098(-11.0F, -6.0F, 5.6F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.5708F, 0.0F, 0.0F));

		class_5610 slope4 = pannel4.method_32117("slope4", class_5606.method_32108().method_32101(0, 66).method_32098(-11.0F, -6.0F, -0.2F, 22.0F, 14.0F, 0.0F, new class_5605(0.0F))
		.method_32101(0, 43).method_32098(-11.0F, -4.1F, -0.8F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.2654F, 0.0F, 0.0F));

		class_5610 controls4 = slope4.method_32117("controls4", class_5606.method_32108().method_32101(12, 15).method_32096().method_32098(1.5F, -3.1F, -3.7F, 2.0F, 2.0F, 4.0F, new class_5605(0.0F)).method_32106(false)
		.method_32101(0, 25).method_32098(-2.0F, -0.1F, -1.7F, 4.0F, 2.0F, 2.0F, new class_5605(0.0F))
		.method_32101(12, 27).method_32098(-0.5F, 2.9F, -2.2F, 2.0F, 2.0F, 3.0F, new class_5605(0.0F))
		.method_32101(12, 15).method_32098(-3.5F, -3.1F, -3.7F, 2.0F, 2.0F, 4.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 cube_r11 = controls4.method_32117("cube_r11", class_5606.method_32108().method_32101(44, 46).method_32098(-1.5F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new class_5605(0.1F)), class_5603.method_32091(0.0F, -2.1F, -2.7F, -0.7854F, 0.0F, 0.0F));

		class_5610 cube_r12 = controls4.method_32117("cube_r12", class_5606.method_32108().method_32101(51, 31).method_32098(-1.0F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(0.5F, 5.7F, -1.2F, 0.0F, 0.0F, 0.7854F));

		class_5610 cube_r13 = controls4.method_32117("cube_r13", class_5606.method_32108().method_32101(51, 31).method_32098(-1.0F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(-1.1F, 3.9F, -1.2F, 0.0F, 0.0F, 0.7854F));

		class_5610 tap3 = controls4.method_32117("tap3", class_5606.method_32108().method_32101(54, 25).method_32098(-0.5F, -0.5F, -1.0F, 1.0F, 1.0F, 2.0F, new class_5605(0.0F))
		.method_32101(0, 34).method_32098(-1.4F, -0.5F, -0.8F, 2.0F, 1.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32090(0.5F, 3.9F, -3.2F));

		class_5610 pannel5 = pannels.method_32117("pannel5", class_5606.method_32108().method_32101(44, 12).method_32098(-5.0F, -21.998F, -7.6602F, 10.0F, 11.0F, 1.0F, new class_5605(0.0F))
		.method_32101(-3, 56).method_32098(-5.0F, -22.001F, -10.6602F, 10.0F, 0.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 35).method_32098(-10.0F, -15.1F, -19.0526F, 20.0F, 4.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, -3.1416F, 1.0472F, 3.1416F));

		class_5610 cube_r14 = pannel5.method_32117("cube_r14", class_5606.method_32108().method_32101(29, 0).method_32098(-11.0F, -6.0F, 5.6F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.5708F, 0.0F, 0.0F));

		class_5610 slope5 = pannel5.method_32117("slope5", class_5606.method_32108().method_32101(0, 66).method_32098(-11.0F, -6.0F, -0.2F, 22.0F, 14.0F, 0.0F, new class_5605(0.0F))
		.method_32101(0, 43).method_32098(-11.0F, -4.1F, -0.8F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.2654F, 0.0F, 0.0F));

		class_5610 controls5 = slope5.method_32117("controls5", class_5606.method_32108().method_32101(0, 15).method_32098(-2.0F, -3.0F, -4.0F, 4.0F, 4.0F, 2.0F, new class_5605(0.0F))
		.method_32101(24, 15).method_32098(-2.0F, 2.9F, -1.8F, 1.0F, 4.0F, 1.0F, new class_5605(0.0F))
		.method_32101(24, 15).method_32096().method_32098(1.0F, 2.9F, -1.8F, 1.0F, 4.0F, 1.0F, new class_5605(0.0F)).method_32106(false)
		.method_32101(22, 0).method_32098(-0.5F, -0.1F, -1.3F, 1.0F, 9.0F, 1.0F, new class_5605(0.0F))
		.method_32101(22, 29).method_32098(-1.0F, -2.0F, -3.0F, 2.0F, 2.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 switches4 = controls5.method_32117("switches4", class_5606.method_32108(), class_5603.method_32090(0.0F, 6.9F, 1.2F));

		class_5610 switch11 = switches4.method_32117("switch11", class_5606.method_32108().method_32101(44, 48).method_32098(-0.5F, 0.0F, -2.0F, 1.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(-1.5F, -3.0F, -3.0F));

		class_5610 switch10 = switches4.method_32117("switch10", class_5606.method_32108().method_32101(44, 48).method_32098(-0.5F, 0.0F, -2.0F, 1.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(-1.5F, -1.0F, -3.0F));

		class_5610 switches5 = controls5.method_32117("switches5", class_5606.method_32108(), class_5603.method_32090(0.0F, 6.9F, 1.2F));

		class_5610 switch12 = switches5.method_32117("switch12", class_5606.method_32108().method_32101(44, 48).method_32096().method_32098(-0.5F, 0.0F, -2.0F, 1.0F, 0.0F, 2.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32090(1.5F, -3.0F, -3.0F));

		class_5610 switch13 = switches5.method_32117("switch13", class_5606.method_32108().method_32101(44, 48).method_32096().method_32098(-0.5F, 0.0F, -2.0F, 1.0F, 0.0F, 2.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32090(1.5F, -1.0F, -3.0F));

		class_5610 switches3 = controls5.method_32117("switches3", class_5606.method_32108().method_32101(22, 21).method_32098(-0.5F, -3.0F, -0.5F, 2.0F, 6.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(6.5F, 4.0F, -0.1F, 0.0F, 0.0F, -0.5236F));

		class_5610 switch7 = switches3.method_32117("switch7", class_5606.method_32108().method_32101(47, 26).method_32098(-1.0F, 0.0F, -2.0F, 2.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.5F, 2.0F, -0.5F));

		class_5610 switch8 = switches3.method_32117("switch8", class_5606.method_32108().method_32101(47, 26).method_32098(-1.0F, 0.0F, -2.0F, 2.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.5F, 0.0F, -0.5F));

		class_5610 switch9 = switches3.method_32117("switch9", class_5606.method_32108().method_32101(47, 26).method_32098(-1.0F, 0.0F, -2.0F, 2.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.5F, -2.0F, -0.5F));

		class_5610 pannel6 = pannels.method_32117("pannel6", class_5606.method_32108().method_32101(44, 12).method_32098(-5.0F, -22.0F, -7.6602F, 10.0F, 11.0F, 1.0F, new class_5605(0.0F))
		.method_32101(-3, 56).method_32098(-5.0F, -22.002F, -10.6602F, 10.0F, 0.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 35).method_32098(-10.0F, -15.1F, -19.0526F, 20.0F, 4.0F, 3.0F, new class_5605(0.0F))
		.method_32101(54, 61).method_32098(5.0F, -15.1F, -23.0526F, 3.0F, 15.0F, 3.0F, new class_5605(0.0F))
		.method_32101(64, 35).method_32098(5.0F, -18.1F, -23.0526F, 3.0F, 3.0F, 5.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 1.0472F, 0.0F));

		class_5610 cube_r15 = pannel6.method_32117("cube_r15", class_5606.method_32108().method_32101(29, 0).method_32098(-11.0F, -6.0F, 5.6F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.5708F, 0.0F, 0.0F));

		class_5610 slope6 = pannel6.method_32117("slope6", class_5606.method_32108().method_32101(0, 66).method_32098(-11.0F, -6.0F, -0.2F, 22.0F, 14.0F, 0.0F, new class_5605(0.0F))
		.method_32101(0, 43).method_32098(-11.0F, -4.1F, -0.8F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F))
		.method_32101(73, 0).method_32098(-11.0F, -4.1F, -0.9F, 22.0F, 12.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -16.9042F, -11.3303F, -1.2654F, 0.0F, 0.0F));

		class_5610 controls6 = slope6.method_32117("controls6", class_5606.method_32108().method_32101(12, 15).method_32096().method_32098(1.5F, -3.1F, -3.7F, 2.0F, 2.0F, 4.0F, new class_5605(0.0F)).method_32106(false)
		.method_32101(12, 15).method_32098(-3.5F, -3.1F, -3.7F, 2.0F, 2.0F, 4.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.0F, 0.0F));

		class_5610 cube_r16 = controls6.method_32117("cube_r16", class_5606.method_32108().method_32101(44, 46).method_32098(-1.5F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new class_5605(0.1F)), class_5603.method_32091(0.0F, -2.1F, -2.7F, -0.7854F, 0.0F, 0.0F));

		class_5610 taps = controls6.method_32117("taps", class_5606.method_32108(), class_5603.method_32090(3.0F, -2.6F, -0.7F));

		class_5610 taps2 = taps.method_32117("taps2", class_5606.method_32108().method_32101(53, 24).method_32098(-0.5F, -0.5F, -1.5F, 1.0F, 1.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 34).method_32098(-0.6F, -0.5F, -1.3F, 2.0F, 1.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32090(-3.5F, 7.0F, -0.5F));

		class_5610 taps3 = taps.method_32117("taps3", class_5606.method_32108().method_32101(53, 24).method_32098(-0.5F, -0.5F, -1.5F, 1.0F, 1.0F, 3.0F, new class_5605(0.0F))
		.method_32101(20, 15).method_32098(-0.5F, -0.6F, -1.3F, 1.0F, 2.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32090(-1.5F, 4.0F, -0.5F));

		class_5610 taps4 = taps.method_32117("taps4", class_5606.method_32108().method_32101(53, 24).method_32098(-0.5F, -0.5F, -1.5F, 1.0F, 1.0F, 3.0F, new class_5605(0.0F))
		.method_32101(0, 34).method_32098(-1.4F, -0.5F, -1.3F, 2.0F, 1.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32090(-4.5F, 4.0F, -0.5F));

		class_5610 dividers = console.method_32117("dividers", class_5606.method_32108(), class_5603.method_32090(0.0F, -13.0F, 0.0F));

		class_5610 cube_r17 = dividers.method_32117("cube_r17", class_5606.method_32108().method_32101(28, 55).method_32098(-1.0F, -10.7123F, -4.1654F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-0.5F, -7.745F, 0.866F, -1.8762F, 0.5236F, -3.1416F));

		class_5610 cube_r18 = dividers.method_32117("cube_r18", class_5606.method_32108().method_32101(54, 54).method_32098(-1.0F, -1.0F, -12.4691F, 2.0F, 2.0F, 5.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, -7.9936F, 0.0F, -3.1416F, 0.5236F, -3.1416F));

		class_5610 cube_r19 = dividers.method_32117("cube_r19", class_5606.method_32108().method_32101(44, 35).method_32098(-1.0F, -4.3262F, 7.0526F, 2.0F, 4.0F, 15.0F, new class_5605(0.0F))
		.method_32101(44, 54).method_32098(-1.0F, -11.3251F, 7.0526F, 2.0F, 21.0F, 3.0F, new class_5605(0.002F))
		.method_32101(44, 35).method_32098(-1.0F, -4.3262F, -22.0526F, 2.0F, 4.0F, 15.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 2.3262F, 0.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 cube_r20 = dividers.method_32117("cube_r20", class_5606.method_32108().method_32101(29, 12).method_32098(-1.0F, 6.4233F, 3.39F, 2.0F, 15.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -3.3016F, 0.0F, 0.0F, 1.5708F, -1.2654F));

		class_5610 cube_r21 = dividers.method_32117("cube_r21", class_5606.method_32108().method_32101(20, 55).method_32098(-1.0F, 9.843F, -7.4559F, 2.0F, 8.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 2.3262F, 0.0F, 0.0F, 1.5708F, -1.2654F));

		class_5610 cube_r22 = dividers.method_32117("cube_r22", class_5606.method_32108().method_32101(28, 55).method_32098(-1.0F, -14.6945F, -7.1389F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 2.3262F, 0.0F, 0.0F, 1.5708F, 1.2654F));

		class_5610 cube_r23 = dividers.method_32117("cube_r23", class_5606.method_32108().method_32101(54, 54).method_32098(-1.0F, -1.0F, -2.5F, 2.0F, 2.0F, 5.0F, new class_5605(0.001F)), class_5603.method_32091(9.9691F, -7.9936F, 0.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 cube_r24 = dividers.method_32117("cube_r24", class_5606.method_32108().method_32101(28, 55).method_32098(-1.0F, -14.6945F, -7.1389F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 2.3262F, 0.0F, 0.0F, -1.5708F, -1.2654F));

		class_5610 cube_r25 = dividers.method_32117("cube_r25", class_5606.method_32108().method_32101(54, 54).method_32098(-1.0F, -1.0F, -2.5F, 2.0F, 2.0F, 5.0F, new class_5605(0.001F)), class_5603.method_32091(-9.9691F, -7.9936F, 0.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 cube_r26 = dividers.method_32117("cube_r26", class_5606.method_32108().method_32101(44, 54).method_32098(-1.0F, -10.5F, -1.5F, 2.0F, 21.0F, 3.0F, new class_5605(0.002F)), class_5603.method_32091(-8.5526F, 1.501F, 0.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 cube_r27 = dividers.method_32117("cube_r27", class_5606.method_32108().method_32101(20, 55).method_32098(-1.0F, -4.0F, -1.0F, 2.0F, 8.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-11.261F, 12.6459F, 0.0F, 0.0F, -1.5708F, 1.2654F));

		class_5610 cube_r28 = dividers.method_32117("cube_r28", class_5606.method_32108().method_32101(29, 12).method_32098(-1.0F, 6.4233F, -5.39F, 2.0F, 15.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -3.3016F, 0.0F, 0.0F, 1.5708F, 1.2654F));

		class_5610 cube_r29 = dividers.method_32117("cube_r29", class_5606.method_32108().method_32101(54, 54).method_32098(-1.0F, -1.0F, -2.5F, 2.0F, 2.0F, 5.0F, new class_5605(0.001F)), class_5603.method_32091(4.9845F, -7.9936F, 8.6335F, 3.1416F, -0.5236F, -3.1416F));

		class_5610 cube_r30 = dividers.method_32117("cube_r30", class_5606.method_32108().method_32101(28, 55).method_32098(-1.0F, 1.5F, 0.5F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(6.574F, -9.829F, 11.3864F, -1.2654F, 0.5236F, 0.0F));

		class_5610 cube_r31 = dividers.method_32117("cube_r31", class_5606.method_32108().method_32101(44, 54).method_32098(-1.0F, -10.499F, -1.5F, 2.0F, 21.0F, 3.0F, new class_5605(0.002F)), class_5603.method_32091(-4.2763F, 1.5F, 7.4067F, 0.0F, -0.5236F, 0.0F));

		class_5610 cube_r32 = dividers.method_32117("cube_r32", class_5606.method_32108().method_32101(44, 54).method_32098(-1.0F, -10.5F, 7.0526F, 2.0F, 21.0F, 3.0F, new class_5605(0.002F))
		.method_32101(66, 61).method_32098(-1.0F, 0.499F, 18.0526F, 2.0F, 11.0F, 2.0F, new class_5605(0.0F))
		.method_32101(44, 35).method_32098(-1.0F, -3.501F, 7.0526F, 2.0F, 4.0F, 15.0F, new class_5605(0.0F))
		.method_32101(44, 35).method_32098(-1.0F, -3.501F, -22.0526F, 2.0F, 4.0F, 15.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 1.501F, 0.0F, 0.0F, 0.5236F, 0.0F));

		class_5610 cube_r33 = dividers.method_32117("cube_r33", class_5606.method_32108().method_32101(20, 55).method_32098(-1.0F, -7.5F, 0.5F, 2.0F, 8.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-7.074F, 15.129F, 12.2525F, 1.2654F, -0.5236F, 0.0F));

		class_5610 cube_r34 = dividers.method_32117("cube_r34", class_5606.method_32108().method_32101(20, 55).method_32098(-1.0F, -7.5F, 0.5F, 2.0F, 8.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(7.074F, 15.129F, 12.2525F, 1.2654F, 0.5236F, 0.0F));

		class_5610 cube_r35 = dividers.method_32117("cube_r35", class_5606.method_32108().method_32101(29, 12).method_32098(-1.0F, 6.4233F, 3.39F, 2.0F, 15.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -3.3016F, 0.0F, 1.2654F, 0.5236F, 0.0F));

		class_5610 cube_r36 = dividers.method_32117("cube_r36", class_5606.method_32108().method_32101(29, 12).method_32098(-1.0F, 6.4233F, 3.39F, 2.0F, 15.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -3.3016F, 0.0F, 1.2654F, -0.5236F, 0.0F));

		class_5610 cube_r37 = dividers.method_32117("cube_r37", class_5606.method_32108().method_32101(44, 35).method_32098(-1.0F, -2.0F, 7.0526F, 2.0F, 4.0F, 15.0F, new class_5605(0.0F))
		.method_32101(44, 35).method_32098(-1.0F, -2.0F, -22.0526F, 2.0F, 4.0F, 15.0F, new class_5605(0.0F))
		.method_32101(54, 54).method_32098(-1.0F, -8.9936F, -12.4691F, 2.0F, 2.0F, 5.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, -0.5236F, 0.0F));

		class_5610 cube_r38 = dividers.method_32117("cube_r38", class_5606.method_32108().method_32101(44, 54).method_32098(-1.0F, -10.5F, -1.5F, 2.0F, 21.0F, 3.0F, new class_5605(0.002F)), class_5603.method_32091(4.2763F, 1.501F, -7.4067F, -3.1416F, 0.5236F, 3.1416F));

		class_5610 cube_r39 = dividers.method_32117("cube_r39", class_5606.method_32108().method_32101(66, 61).method_32098(-1.0F, -5.5F, -1.0F, 2.0F, 11.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(9.2763F, 7.5F, -16.067F, 0.0F, 2.618F, 0.0F));

		class_5610 cube_r40 = dividers.method_32117("cube_r40", class_5606.method_32108().method_32101(20, 55).method_32098(3.0408F, -2.7621F, -9.4769F, 2.0F, 8.0F, 2.0F, new class_5605(-0.1F)), class_5603.method_32091(9.8141F, 4.1891F, -8.917F, -1.8762F, 0.5236F, -3.1416F));

		class_5610 cube_r41 = dividers.method_32117("cube_r41", class_5606.method_32108().method_32101(20, 55).method_32098(-1.0F, -4.0F, -1.0F, 2.0F, 8.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-5.6305F, 12.6459F, -9.7523F, -1.8762F, -0.5236F, 3.1416F));

		class_5610 cube_r42 = dividers.method_32117("cube_r42", class_5606.method_32108().method_32101(54, 54).method_32098(-1.0F, -1.0F, -2.5F, 2.0F, 2.0F, 5.0F, new class_5605(0.001F)), class_5603.method_32091(-4.9845F, -7.9936F, -8.6335F, 0.0F, 0.5236F, 0.0F));

		class_5610 cube_r43 = dividers.method_32117("cube_r43", class_5606.method_32108().method_32101(28, 55).method_32098(-1.0F, -10.7123F, 2.1654F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-0.5F, -7.745F, -0.866F, 1.8762F, -0.5236F, -3.1416F));

		class_5610 cube_r44 = dividers.method_32117("cube_r44", class_5606.method_32108().method_32101(28, 55).method_32098(-1.0F, 1.5F, -2.5F, 2.0F, 3.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(6.574F, -9.829F, -11.3864F, 1.2654F, -0.5236F, 0.0F));

		class_5610 cube_r45 = dividers.method_32117("cube_r45", class_5606.method_32108().method_32101(29, 12).method_32098(-1.0F, 6.4233F, -5.39F, 2.0F, 15.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -3.3016F, 0.0F, -1.2654F, -0.5236F, 0.0F));

		class_5610 cube_r46 = dividers.method_32117("cube_r46", class_5606.method_32108().method_32101(0, 0).method_32098(-0.5F, 9.677F, -4.7853F, 1.0F, 11.0F, 0.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -4.1453F, 0.0F, 0.0F, -1.5708F, -1.2654F));

		class_5610 cube_r47 = dividers.method_32117("cube_r47", class_5606.method_32108().method_32101(0, 0).method_32096().method_32098(-0.5F, 9.677F, -4.7853F, 1.0F, 11.0F, 0.0F, new class_5605(-0.001F)).method_32106(false), class_5603.method_32091(0.0F, -4.1453F, 0.0F, 0.0F, 1.5708F, 1.2654F));

		class_5610 cube_r48 = dividers.method_32117("cube_r48", class_5606.method_32108().method_32101(0, 0).method_32098(-0.5F, 9.677F, -4.7853F, 1.0F, 11.0F, 0.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -4.1453F, 0.0F, -1.2654F, -0.5236F, 0.0F));

		class_5610 cube_r49 = dividers.method_32117("cube_r49", class_5606.method_32108().method_32101(0, 0).method_32096().method_32098(-0.5F, 9.677F, -4.7853F, 1.0F, 11.0F, 0.0F, new class_5605(-0.001F)).method_32106(false), class_5603.method_32091(0.0F, -4.1453F, 0.0F, 1.8762F, 0.5236F, -3.1416F));

		class_5610 cube_r50 = dividers.method_32117("cube_r50", class_5606.method_32108().method_32101(0, 0).method_32096().method_32098(-0.5F, -5.5F, 0.0F, 1.0F, 11.0F, 0.0F, new class_5605(-0.001F)).method_32106(false), class_5603.method_32091(7.9568F, -4.1453F, 13.7815F, 1.8762F, -0.5236F, -3.1416F));

		class_5610 cube_r51 = dividers.method_32117("cube_r51", class_5606.method_32108().method_32101(0, 0).method_32098(-0.5F, 9.4233F, -5.59F, 1.0F, 11.0F, 0.0F, new class_5605(-0.001F))
		.method_32101(29, 12).method_32098(-1.0F, 6.4233F, -5.39F, 2.0F, 15.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -3.3016F, 0.0F, -1.2654F, 0.5236F, 0.0F));

		class_5610 cube_r52 = dividers.method_32117("cube_r52", class_5606.method_32108().method_32101(44, 54).method_32098(-1.0F, -10.5F, -1.5F, 2.0F, 21.0F, 3.0F, new class_5605(0.002F)), class_5603.method_32091(-4.2763F, 1.501F, -7.4067F, -3.1416F, -0.5236F, 3.1416F));

		class_5610 dividercontrols5 = dividers.method_32117("dividercontrols5", class_5606.method_32108().method_32101(44, 41).method_32098(-1.0113F, -25.9936F, -10.4465F, 2.0F, 2.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 13.0F, 0.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 cube_r53 = dividercontrols5.method_32117("cube_r53", class_5606.method_32108().method_32101(26, 0).method_32098(-0.5F, -2.0F, 0.0F, 1.0F, 4.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(-0.0113F, -23.8937F, -8.9465F, 0.2182F, 0.0F, 0.0F));

		class_5610 dividercontrols4 = dividers.method_32117("dividercontrols4", class_5606.method_32108().method_32101(37, 24).method_32098(-2.5113F, -26.9936F, -8.9465F, 5.0F, 5.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 13.0F, 0.0F, 0.0F, 2.0944F, 0.0F));

		class_5610 hourglass2 = dividercontrols4.method_32117("hourglass2", class_5606.method_32108().method_32101(46, 37).method_32098(-1.0F, -2.5F, -1.0F, 2.0F, 2.0F, 2.0F, new class_5605(0.0F))
		.method_32101(20, 10).method_32098(-1.0F, -1.5F, -1.0F, 2.0F, 3.0F, 2.0F, new class_5605(-0.1F))
		.method_32101(46, 37).method_32098(-1.0F, 0.5F, -1.0F, 2.0F, 2.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(-0.0113F, -25.4936F, -9.0F));

		class_5610 dividercontrols = dividers.method_32117("dividercontrols", class_5606.method_32108().method_32101(0, 29).method_32098(-2.0F, -3.5F, -9.4732F, 4.0F, 4.0F, 1.0F, new class_5605(0.0F))
		.method_32101(0, 29).method_32098(-2.0F, -3.5F, 8.4733F, 4.0F, 4.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32091(-0.0113F, -9.4936F, 0.0267F, 0.0F, 1.5708F, 0.0F));

		class_5610 lever = dividercontrols.method_32117("lever", class_5606.method_32108().method_32101(2, 0).method_32098(-2.0F, 0.0F, 0.0F, 4.0F, 2.0F, 6.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, -3.5F, -8.4732F, 0.0F, 3.1416F, 0.0F));

		class_5610 lever2 = dividercontrols.method_32117("lever2", class_5606.method_32108().method_32101(2, 0).method_32098(-2.0F, -5.0F, -1.5F, 4.0F, 2.0F, 6.0F, new class_5605(0.001F)), class_5603.method_32090(0.0F, 1.5F, 9.9733F));

		class_5610 dividercontrols2 = dividers.method_32117("dividercontrols2", class_5606.method_32108().method_32101(0, 21).method_32098(-2.0F, -1.5F, 7.3733F, 4.0F, 2.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-0.0113F, -9.4936F, 0.0267F, 0.0F, -2.618F, 0.0F));

		class_5610 cube_r54 = dividercontrols2.method_32117("cube_r54", class_5606.method_32108().method_32101(2, 8).method_32098(-2.0F, -1.0F, -2.5F, 4.0F, 2.0F, 5.0F, new class_5605(0.001F)), class_5603.method_32091(0.0F, -0.9493F, 10.0089F, 0.1745F, 0.0F, 0.0F));

		class_5610 dividercontrols3 = dividers.method_32117("dividercontrols3", class_5606.method_32108().method_32101(37, 24).method_32098(-2.5F, -4.5F, 9.9733F, 5.0F, 5.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(-0.0113F, -9.4936F, 0.0267F, 0.0F, 2.618F, 0.0F));

		class_5610 hourglass = dividercontrols3.method_32117("hourglass", class_5606.method_32108().method_32101(46, 37).method_32096().method_32098(-1.0F, -2.5F, -1.0F, 2.0F, 2.0F, 2.0F, new class_5605(0.0F)).method_32106(false)
		.method_32101(20, 10).method_32098(-1.0F, -1.5F, -1.0F, 2.0F, 3.0F, 2.0F, new class_5605(-0.1F)), class_5603.method_32090(0.0F, -3.0F, 9.9733F));

		class_5610 cube_r55 = hourglass.method_32117("cube_r55", class_5606.method_32108().method_32101(46, 37).method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 1.5F, 0.0F, 0.0F, 0.0F, -3.1416F));

		class_5610 scanners = dividers.method_32117("scanners", class_5606.method_32108(), class_5603.method_32091(0.0F, -10.2436F, 0.0F, 0.0F, 1.0472F, 0.0F));

		class_5610 cube_r56 = scanners.method_32117("cube_r56", class_5606.method_32108().method_32101(57, 28).method_32098(-0.5F, -3.0F, -20.9691F, 1.0F, 1.0F, 5.0F, new class_5605(0.0F))
		.method_32101(0, 59).method_32098(0.0F, -3.0F, -16.4691F, 0.0F, 2.0F, 5.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 2.25F, 0.0F, -3.1416F, 0.5236F, -3.1416F));

		class_5610 cube_r57 = scanners.method_32117("cube_r57", class_5606.method_32108().method_32101(57, 28).method_32098(-0.5F, -1.0F, -11.0F, 1.0F, 1.0F, 5.0F, new class_5605(0.0F))
		.method_32101(0, 59).method_32098(0.0F, -1.0F, -6.5F, 0.0F, 2.0F, 5.0F, new class_5605(0.0F)), class_5603.method_32091(-4.9845F, 0.25F, -8.6335F, 0.0F, 0.5236F, 0.0F));

		class_5610 cube_r58 = scanners.method_32117("cube_r58", class_5606.method_32108().method_32101(57, 28).method_32098(-0.5F, -0.75F, -4.75F, 1.0F, 1.0F, 5.0F, new class_5605(0.001F))
		.method_32101(0, 59).method_32098(0.0F, -0.75F, -0.25F, 0.0F, 2.0F, 5.0F, new class_5605(0.0F)), class_5603.method_32091(16.2191F, 0.0F, 0.0F, 0.0F, -1.5708F, 0.0F));

		return class_5607.method_32110(meshdefinition, 128, 128);
	}
}