package net.maketendo.tardifmod.client.models.entities;

import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.client.renderers.entities.renderstates.TARDISEntityRenderState;
import net.minecraft.class_2960;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

public class PoliceBoxInteriorDoorModel extends class_583<TARDISEntityRenderState> {
	public static final class_5601 LAYER_LOCATION = new class_5601(class_2960.method_60655(TARDIFMod.MOD_ID, "police_box_interior_door"), "main");
	private final class_630 TARDIF;
	private final class_630 doors;
	private final class_630 RightDoor;
	private final class_630 window;
	private final class_630 LeftDoor;
	private final class_630 phone;
	private final class_630 phone2;
	private final class_630 button1;
	private final class_630 button2;
	private final class_630 window2;
	private final class_630 lamplid;
	private final class_630 window3;
	private final class_630 window4;
	private final class_630 window5;
	private final class_630 window6;
	private final class_630 window7;
	private final class_630 window8;

	public PoliceBoxInteriorDoorModel(class_630 root) {
		super(root);
		this.TARDIF = root.method_32086("TARDIF");
		this.doors = this.TARDIF.method_32086("doors");
		this.RightDoor = this.doors.method_32086("RightDoor");
		this.window = this.RightDoor.method_32086("window");
		this.LeftDoor = this.doors.method_32086("LeftDoor");
		this.phone = this.LeftDoor.method_32086("phone");
		this.phone2 = this.phone.method_32086("phone2");
		this.button1 = this.phone.method_32086("button1");
		this.button2 = this.phone.method_32086("button2");
		this.window2 = this.LeftDoor.method_32086("window2");
		this.lamplid = this.TARDIF.method_32086("lamplid");
		this.window3 = this.TARDIF.method_32086("window3");
		this.window4 = this.TARDIF.method_32086("window4");
		this.window5 = this.TARDIF.method_32086("window5");
		this.window6 = this.TARDIF.method_32086("window6");
		this.window7 = this.TARDIF.method_32086("window7");
		this.window8 = this.TARDIF.method_32086("window8");
	}

	public static class_5607 createBodyLayer() {
		class_5609 meshdefinition = new class_5609();
		class_5610 partdefinition = meshdefinition.method_32111();

		class_5610 TARDIF = partdefinition.method_32117("TARDIF", class_5606.method_32108().method_32101(12, 119).method_32098(-9.5F, -36.0F, -2.5F, 19.0F, 4.0F, 5.0F, new class_5605(0.0F))
		.method_32101(67, 90).method_32098(-9.5F, -37.0F, -2.5F, 19.0F, 1.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 24.0F, 0.0F));

		class_5610 snow_r1 = TARDIF.method_32117("snow_r1", class_5606.method_32108().method_32101(0, 123).method_32096().method_32098(8.0F, -22.0F, -11.0F, 3.0F, 2.0F, 3.0F, new class_5605(0.0F)).method_32106(false)
		.method_32101(54, 78).method_32096().method_32098(8.0F, -20.0F, -11.0F, 3.0F, 38.0F, 3.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32091(0.5F, -18.0F, 9.5F, 0.0F, 1.5708F, 0.0F));

		class_5610 snow_r2 = TARDIF.method_32117("snow_r2", class_5606.method_32108().method_32101(0, 123).method_32098(-11.0F, -23.0F, -11.0F, 3.0F, 2.0F, 3.0F, new class_5605(0.0F))
		.method_32101(54, 78).method_32098(-11.0F, -21.0F, -11.0F, 3.0F, 38.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(-0.5F, -17.0F, 9.5F, 0.0F, -1.5708F, 0.0F));

		class_5610 doors = TARDIF.method_32117("doors", class_5606.method_32108(), class_5603.method_32090(0.5F, 0.0F, 0.5F));

		class_5610 RightDoor = doors.method_32117("RightDoor", class_5606.method_32108().method_32101(1, 79).method_32098(-8.0F, -16.0F, -1.5F, 8.0F, 32.0F, 2.0F, new class_5605(-0.001F))
		.method_32101(0, 0).method_32098(-4.5F, -4.0F, -1.6F, 2.0F, 2.0F, 0.0F, new class_5605(-0.001F))
		.method_32101(0, 64).method_32098(-7.0F, -4.0F, -3.5F, 0.0F, 4.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(7.0F, -16.0F, 0.5F));

		class_5610 cube_r1 = RightDoor.method_32117("cube_r1", class_5606.method_32108().method_32101(0, 64).method_32098(0.0F, -2.0F, -1.0F, 0.0F, 4.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-7.0F, -2.0F, 1.5F, 0.0F, 3.1416F, 0.0F));

		class_5610 window = RightDoor.method_32117("window", class_5606.method_32108().method_32101(6, 15).method_32098(-2.5F, -6.0F, 0.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32090(-3.5F, -7.0F, -1.5F));

		class_5610 LeftDoor = doors.method_32117("LeftDoor", class_5606.method_32108().method_32101(23, 79).method_32098(0.0F, -16.0F, -1.5F, 7.0F, 32.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32090(-8.0F, -16.0F, 0.5F));

		class_5610 phone = LeftDoor.method_32117("phone", class_5606.method_32108().method_32101(0, 54).method_32098(0.0F, -3.0F, -0.25F, 5.0F, 6.0F, 2.0F, new class_5605(0.0F))
		.method_32101(14, 6).method_32098(0.0F, 0.0F, 1.75F, 2.0F, 0.0F, 1.0F, new class_5605(-0.001F))
		.method_32101(1, 65).method_32098(4.5F, -2.0F, -1.25F, 0.0F, 4.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(1.0F, -3.0F, -1.25F));

		class_5610 phone2 = phone.method_32117("phone2", class_5606.method_32108().method_32101(0, 13).method_32098(-1.0F, -2.5F, -1.0333F, 2.0F, 2.0F, 1.0F, new class_5605(-0.002F))
		.method_32101(8, 6).method_32098(-1.0F, -2.5F, -0.5333F, 2.0F, 5.0F, 1.0F, new class_5605(0.0F))
		.method_32101(0, 13).method_32098(-1.0F, 0.5F, -1.0333F, 2.0F, 2.0F, 1.0F, new class_5605(-0.002F)), class_5603.method_32090(1.0F, 0.0F, 2.5833F));

		class_5610 button1 = phone.method_32117("button1", class_5606.method_32108(), class_5603.method_32090(3.5F, -1.5F, 3.25F));

		class_5610 cube_r2 = button1.method_32117("cube_r2", class_5606.method_32108().method_32101(8, 12).method_32098(-1.0F, -1.0F, -1.5F, 2.0F, 2.0F, 1.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.7854F));

		class_5610 button2 = phone.method_32117("button2", class_5606.method_32108(), class_5603.method_32090(3.5F, 1.5F, 3.25F));

		class_5610 cube_r3 = button2.method_32117("cube_r3", class_5606.method_32108().method_32101(8, 12).method_32098(-1.0F, -1.0F, -1.5F, 2.0F, 2.0F, 1.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.7854F));

		class_5610 window2 = LeftDoor.method_32117("window2", class_5606.method_32108().method_32101(6, 15).method_32096().method_32098(-2.5F, -6.0F, 0.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.001F)).method_32106(false), class_5603.method_32090(3.5F, -7.0F, -1.5F));

		class_5610 lamplid = TARDIF.method_32117("lamplid", class_5606.method_32108(), class_5603.method_32090(2.5F, -44.0F, 9.0F));

		class_5610 window3 = TARDIF.method_32117("window3", class_5606.method_32108(), class_5603.method_32090(4.0F, -23.0F, 18.5F));

		class_5610 window4 = TARDIF.method_32117("window4", class_5606.method_32108(), class_5603.method_32090(-4.0F, -23.0F, 18.5F));

		class_5610 window5 = TARDIF.method_32117("window5", class_5606.method_32108(), class_5603.method_32091(-9.5F, -23.0F, 5.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 window6 = TARDIF.method_32117("window6", class_5606.method_32108(), class_5603.method_32091(-9.5F, -23.0F, 13.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 window7 = TARDIF.method_32117("window7", class_5606.method_32108(), class_5603.method_32091(9.5F, -23.0F, 13.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 window8 = TARDIF.method_32117("window8", class_5606.method_32108(), class_5603.method_32091(9.5F, -23.0F, 5.0F, 0.0F, 1.5708F, 0.0F));

		return class_5607.method_32110(meshdefinition, 128, 128);
	}

}