package net.maketendo.tardifmod.client.models.entities;


import net.maketendo.tardifmod.client.animations.tardis.PoliceBoxAnimations;
import net.maketendo.tardifmod.client.animations.tardis.TardisAnimation;
import net.maketendo.tardifmod.client.renderers.entities.renderstates.TARDISEntityRenderState;
import net.minecraft.class_11509;
import net.minecraft.class_2960;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

public class PoliceBoxModel extends class_583<TARDISEntityRenderState> {
	public static final class_5601 LAYER_LOCATION = new class_5601(class_2960.method_60655("tardif_mod", "police_box"), "main");
	private final class_630 TARDIF;
	private final class_630 doors;
	private final class_630 RightDoor;
	private final class_630 window;
	private final class_630 LeftDoor;
	private final class_630 phone;
	private final class_630 phone2;
	private final class_630 button1;
	private final class_630 button2;
	private final class_630 window2;
	private final class_630 lamplid;
	private final class_630 window3;
	private final class_630 window4;
	private final class_630 window5;
	private final class_630 window6;
	private final class_630 window7;
	private final class_630 window8;

	private final class_11509 doorRightOpen;
	private final class_11509 doorLeftOpen;

	private final class_11509 doorRightClose;
	private final class_11509 doorLeftClose;

	private final class_11509 phoneOpen;
	private final class_11509 phoneClose;
	private final class_11509 phoneRing;
	private final class_11509 phoneDial;

	private final class_11509 lampOpen;
	private final class_11509 lampClose;

	private final class_11509 fallingStart;
	private final class_11509 fallingLoop;

	public PoliceBoxModel(class_630 root) {
		super(root);
		this.TARDIF = root.method_32086("TARDIF");
		this.doors = this.TARDIF.method_32086("doors");
		this.RightDoor = this.doors.method_32086("RightDoor");
		this.window = this.RightDoor.method_32086("window");
		this.LeftDoor = this.doors.method_32086("LeftDoor");
		this.phone = this.LeftDoor.method_32086("phone");
		this.phone2 = this.phone.method_32086("phone2");
		this.button1 = this.phone.method_32086("button1");
		this.button2 = this.phone.method_32086("button2");
		this.window2 = this.LeftDoor.method_32086("window2");
		this.lamplid = this.TARDIF.method_32086("lamplid");
		this.window3 = this.TARDIF.method_32086("window3");
		this.window4 = this.TARDIF.method_32086("window4");
		this.window5 = this.TARDIF.method_32086("window5");
		this.window6 = this.TARDIF.method_32086("window6");
		this.window7 = this.TARDIF.method_32086("window7");
		this.window8 = this.TARDIF.method_32086("window8");

		this.doorRightOpen = PoliceBoxAnimations.door_right_open.method_71979(root);
		this.doorLeftOpen = PoliceBoxAnimations.door_left_open.method_71979(root);

		this.doorRightClose = PoliceBoxAnimations.right_door_close.method_71979(root);
		this.doorLeftClose = PoliceBoxAnimations.left_door_close.method_71979(root);

		this.phoneOpen = PoliceBoxAnimations.phone_booth_open.method_71979(root);
		this.phoneClose = PoliceBoxAnimations.phone_booth_close.method_71979(root);
		this.phoneRing = PoliceBoxAnimations.phone_ring.method_71979(root);
		this.phoneDial = PoliceBoxAnimations.phone_dial.method_71979(root);

		this.lampOpen = PoliceBoxAnimations.lamp_open.method_71979(root);
		this.lampClose = PoliceBoxAnimations.lamp_close.method_71979(root);

		this.fallingStart = PoliceBoxAnimations.falling_start.method_71979(root);
		this.fallingLoop = PoliceBoxAnimations.falling_loop.method_71979(root);
	}

	public static class_5607 createBodyLayer() {
		class_5609 meshdefinition = new class_5609();
		class_5610 partdefinition = meshdefinition.method_32111();

		class_5610 TARDIF = partdefinition.method_32117("TARDIF", class_5606.method_32108().method_32101(0, 0).method_32098(-11.5F, -1.0F, -11.5F, 23.0F, 1.0F, 23.0F, new class_5605(0.0F))
		.method_32101(0, 51).method_32098(-9.5F, -41.0F, -9.5F, 19.0F, 8.0F, 19.0F, new class_5605(0.0F))
		.method_32101(52, 97).method_32098(-9.5F, -43.0F, -9.5F, 19.0F, 2.0F, 19.0F, new class_5605(0.0F))
		.method_32101(84, 25).method_32098(-2.5F, -45.0F, -2.5F, 5.0F, 6.0F, 5.0F, new class_5605(-0.001F))
		.method_32101(61, 24).method_32098(-1.0F, -45.0F, -1.0F, 2.0F, 6.0F, 2.0F, new class_5605(-0.001F))
		.method_32101(0, 24).method_32098(-9.5F, -37.0F, -11.5F, 19.0F, 4.0F, 23.0F, new class_5605(0.0F))
		.method_32101(67, 90).method_32098(-9.5F, -38.0F, -11.5F, 19.0F, 1.0F, 2.0F, new class_5605(0.0F))
		.method_32101(67, 90).method_32098(-9.5F, -38.0F, 9.5F, 19.0F, 1.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 24.0F, 0.0F));

		class_5610 snow_r1 = TARDIF.method_32117("snow_r1", class_5606.method_32108().method_32101(67, 90).method_32096().method_32098(-9.5F, 1.0F, -11.5F, 19.0F, 1.0F, 2.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32091(0.0F, -39.0F, 0.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 snow_r2 = TARDIF.method_32117("snow_r2", class_5606.method_32108().method_32101(67, 90).method_32098(-9.5F, 1.0F, -11.5F, 19.0F, 1.0F, 2.0F, new class_5605(0.0F))
		.method_32101(0, 24).method_32098(-9.5F, 2.0F, -11.5F, 19.0F, 4.0F, 23.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -39.0F, 0.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 snow_r3 = TARDIF.method_32117("snow_r3", class_5606.method_32108().method_32101(0, 123).method_32098(8.0F, -22.0F, 8.0F, 3.0F, 2.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.5F, -19.0F, -0.5F, 0.0F, -1.5708F, 0.0F));

		class_5610 snow_r4 = TARDIF.method_32117("snow_r4", class_5606.method_32108().method_32101(0, 123).method_32096().method_32098(8.0F, -22.0F, -11.0F, 3.0F, 2.0F, 3.0F, new class_5605(0.0F)).method_32106(false)
		.method_32101(104, 0).method_32096().method_32098(8.0F, -20.0F, -11.0F, 3.0F, 38.0F, 3.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32091(0.5F, -19.0F, 0.5F, 0.0F, 1.5708F, 0.0F));

		class_5610 snow_r5 = TARDIF.method_32117("snow_r5", class_5606.method_32108().method_32101(0, 123).method_32098(-11.0F, -22.0F, 8.0F, 3.0F, 2.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(-0.5F, -19.0F, -0.5F, 0.0F, 1.5708F, 0.0F));

		class_5610 snow_r6 = TARDIF.method_32117("snow_r6", class_5606.method_32108().method_32101(0, 123).method_32098(-11.0F, -23.0F, -11.0F, 3.0F, 2.0F, 3.0F, new class_5605(0.0F))
		.method_32101(104, 0).method_32098(-11.0F, -21.0F, -11.0F, 3.0F, 38.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(-0.5F, -18.0F, 0.5F, 0.0F, -1.5708F, 0.0F));

		class_5610 cube_r1 = TARDIF.method_32117("cube_r1", class_5606.method_32108().method_32101(104, 0).method_32098(-1.5F, -19.0F, -1.5F, 3.0F, 38.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(9.0F, -20.0F, 9.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 cube_r2 = TARDIF.method_32117("cube_r2", class_5606.method_32108().method_32101(104, 0).method_32098(-1.5F, -19.0F, -1.5F, 3.0F, 38.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(-9.0F, -20.0F, 9.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 cube_r3 = TARDIF.method_32117("cube_r3", class_5606.method_32108().method_32101(77, 52).method_32098(-11.5F, -16.0F, -9.5F, 15.0F, 32.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -17.0F, 4.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 cube_r4 = TARDIF.method_32117("cube_r4", class_5606.method_32108().method_32101(77, 52).method_32098(-7.5F, -16.0F, -5.5F, 15.0F, 32.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -17.0F, 4.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 cube_r5 = TARDIF.method_32117("cube_r5", class_5606.method_32108().method_32101(77, 52).method_32098(-3.5F, -16.0F, -9.5F, 15.0F, 32.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, -17.0F, 4.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 doors = TARDIF.method_32117("doors", class_5606.method_32108(), class_5603.method_32090(0.5F, -1.0F, -8.5F));

		class_5610 RightDoor = doors.method_32117("RightDoor", class_5606.method_32108().method_32101(1, 79).method_32098(-8.0F, -16.0F, -1.5F, 8.0F, 32.0F, 2.0F, new class_5605(-0.001F))
		.method_32101(0, 0).method_32098(-4.5F, -4.0F, -1.6F, 2.0F, 2.0F, 0.0F, new class_5605(-0.001F))
		.method_32101(0, 64).method_32098(-7.0F, -5.0F, -3.5F, 0.0F, 4.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(7.0F, -16.0F, 0.5F));

		class_5610 cube_r6 = RightDoor.method_32117("cube_r6", class_5606.method_32108().method_32101(0, 64).method_32098(0.0F, -2.0F, -1.0F, 0.0F, 4.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(-7.0F, -3.0F, 1.5F, 0.0F, 3.1416F, 0.0F));

		class_5610 window = RightDoor.method_32117("window", class_5606.method_32108().method_32101(6, 15).method_32098(-2.5F, -6.0F, 0.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.002F)), class_5603.method_32090(-3.5F, -7.0F, -1.5F));

		class_5610 LeftDoor = doors.method_32117("LeftDoor", class_5606.method_32108().method_32101(23, 79).method_32098(0.0F, -16.0F, -1.5F, 7.0F, 32.0F, 2.0F, new class_5605(-0.001F)), class_5603.method_32090(-8.0F, -16.0F, 0.5F));

		class_5610 phone = LeftDoor.method_32117("phone", class_5606.method_32108().method_32101(0, 54).method_32098(0.0F, -3.0F, -0.25F, 5.0F, 6.0F, 2.0F, new class_5605(0.0F))
		.method_32101(14, 6).method_32098(0.0F, 0.0F, 1.75F, 2.0F, 0.0F, 1.0F, new class_5605(-0.001F))
		.method_32101(1, 65).method_32098(4.5F, -2.0F, -1.25F, 0.0F, 4.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(1.0F, -3.0F, -1.25F));

		class_5610 phone2 = phone.method_32117("phone2", class_5606.method_32108().method_32101(0, 13).method_32098(-1.0F, -2.5F, -1.0333F, 2.0F, 2.0F, 1.0F, new class_5605(-0.002F))
		.method_32101(8, 6).method_32098(-1.0F, -2.5F, -0.5333F, 2.0F, 5.0F, 1.0F, new class_5605(0.0F))
		.method_32101(0, 13).method_32098(-1.0F, 0.5F, -1.0333F, 2.0F, 2.0F, 1.0F, new class_5605(-0.002F)), class_5603.method_32090(1.0F, 0.0F, 2.5833F));

		class_5610 button1 = phone.method_32117("button1", class_5606.method_32108(), class_5603.method_32090(3.5F, -1.5F, 3.25F));

		class_5610 cube_r7 = button1.method_32117("cube_r7", class_5606.method_32108().method_32101(8, 12).method_32098(-1.0F, -1.0F, -1.5F, 2.0F, 2.0F, 1.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.7854F));

		class_5610 button2 = phone.method_32117("button2", class_5606.method_32108(), class_5603.method_32090(3.5F, 1.5F, 3.25F));

		class_5610 cube_r8 = button2.method_32117("cube_r8", class_5606.method_32108().method_32101(8, 12).method_32098(-1.0F, -1.0F, -1.5F, 2.0F, 2.0F, 1.0F, new class_5605(-0.001F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.7854F));

		class_5610 window2 = LeftDoor.method_32117("window2", class_5606.method_32108().method_32101(6, 15).method_32096().method_32098(-2.5F, -6.0F, 0.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.002F)).method_32106(false), class_5603.method_32090(3.5F, -7.0F, -1.5F));

		class_5610 lamplid = TARDIF.method_32117("lamplid", class_5606.method_32108().method_32101(0, 0).method_32098(-5.0F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F, new class_5605(0.0F)), class_5603.method_32090(2.5F, -45.0F, 0.0F));

		class_5610 window3 = TARDIF.method_32117("window3", class_5606.method_32108(), class_5603.method_32090(4.0F, -24.0F, 9.5F));

		class_5610 cube_r9 = window3.method_32117("cube_r9", class_5606.method_32108().method_32101(6, 15).method_32098(-2.5F, -6.0F, -2.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.002F)), class_5603.method_32091(0.0F, 0.0F, -2.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 window4 = TARDIF.method_32117("window4", class_5606.method_32108(), class_5603.method_32090(-4.0F, -24.0F, 9.5F));

		class_5610 cube_r10 = window4.method_32117("cube_r10", class_5606.method_32108().method_32101(6, 15).method_32096().method_32098(-2.5F, -6.0F, -2.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.002F)).method_32106(false), class_5603.method_32091(0.0F, 0.0F, -2.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 window5 = TARDIF.method_32117("window5", class_5606.method_32108(), class_5603.method_32091(-9.5F, -24.0F, -4.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 cube_r11 = window5.method_32117("cube_r11", class_5606.method_32108().method_32101(6, 15).method_32096().method_32098(-2.5F, -3.0F, -1.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.002F)).method_32106(false), class_5603.method_32091(0.0F, -3.0F, -1.0F, 0.0F, 3.1416F, 0.0F));

		class_5610 window6 = TARDIF.method_32117("window6", class_5606.method_32108().method_32101(6, 15).method_32096().method_32098(-2.5F, -6.0F, 0.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.002F)).method_32106(false), class_5603.method_32091(-9.5F, -24.0F, 4.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 window7 = TARDIF.method_32117("window7", class_5606.method_32108().method_32101(6, 15).method_32098(-2.5F, -6.0F, 0.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.002F)), class_5603.method_32091(9.5F, -24.0F, 4.0F, 0.0F, -1.5708F, 0.0F));

		class_5610 window8 = TARDIF.method_32117("window8", class_5606.method_32108(), class_5603.method_32091(9.5F, -24.0F, -4.0F, 0.0F, 1.5708F, 0.0F));

		class_5610 cube_r12 = window8.method_32117("cube_r12", class_5606.method_32108().method_32101(6, 15).method_32098(-2.5F, -3.0F, -1.0F, 5.0F, 6.0F, 2.0F, new class_5605(-0.002F)), class_5603.method_32091(0.0F, -3.0F, -1.0F, 0.0F, 3.1416F, 0.0F));

		return class_5607.method_32110(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(TARDISEntityRenderState state) {
		super.method_2819(state);

		this.doorRightOpen.method_71985(state.doorRightOpenAnimationState, state.field_53328);
		this.doorLeftOpen.method_71985(state.doorLeftOpenAnimationState, state.field_53328);

		this.doorRightClose.method_71985(state.doorRightCloseAnimationState, state.field_53328);
		this.doorLeftClose.method_71985(state.doorLeftCloseAnimationState, state.field_53328);

		this.phoneOpen.method_71985(state.phoneBoothOpenAnimationState, state.field_53328);
		this.phoneClose.method_71985(state.phoneBoothCloseAnimationState, state.field_53328);

		this.lampOpen.method_71985(state.lampOpenAnimationState, state.field_53328);
		this.lampClose.method_71985(state.lampCloseAnimationState, state.field_53328);

		this.phoneRing.method_71985(state.phoneRingAnimationState, state.field_53328);
		this.phoneDial.method_71985(state.phoneDialAnimationState, state.field_53328);

		this.fallingStart.method_71985(state.fallingStartAnimationState, state.field_53328);
		this.fallingLoop.method_71985(state.fallingLoopAnimationState, state.field_53328);
	}
}