package net.maketendo.tardifmod.client.packets;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.maketendo.tardifmod.TARDIFMod;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class TardisAnimPackets {

    public static void register() {
        PayloadTypeRegistry.playS2C().register(
                TardisAnimPackets.TardisAnimPayload.ID,
                TardisAnimPackets.TardisAnimPayload.CODEC
        );

    }

    public static void send(class_3218 world, class_1297 entity, int animId) {
        TardisAnimPayload payload =
                new TardisAnimPayload(entity.method_5628(), animId);

        for (class_3222 player : PlayerLookup.tracking(entity)) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    public record TardisAnimPayload(int entityId, int animId) implements class_8710 {

        public static final class_9154<TardisAnimPayload> ID =
                new class_9154<>(class_2960.method_60655(TARDIFMod.MOD_ID, "tardis_anim"));

        public static final class_9139<class_9129, TardisAnimPayload> CODEC =
                class_9139.method_56435(
                        class_9135.field_49675, TardisAnimPayload::entityId,
                        class_9135.field_49675, TardisAnimPayload::animId,
                        TardisAnimPayload::new
                );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return ID;
        }
    }
}
