package net.maketendo.tardifmod.client.animations.tardis;


import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;

public class PoliceBoxAnimations {
	public static final class_7184 door_right_open = class_7184.class_7185.method_41818(1.0F)
			.method_41820("RightDoor", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.2F, class_7187.method_41829(0.0F, 77.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.36F, class_7187.method_41829(0.0F, 72.5F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.52F, class_7187.method_41829(0.0F, 77.5F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.64F, class_7187.method_41829(0.0F, 75.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.76F, class_7187.method_41829(0.0F, 77.5F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41821();

	public static final class_7184 door_left_open = class_7184.class_7185.method_41818(1.0F)
			.method_41820("LeftDoor", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.24F, class_7187.method_41829(0.0F, -77.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.35F, class_7187.method_41829(0.0F, -72.5F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.49F, class_7187.method_41829(0.0F, -77.5F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.63F, class_7187.method_41829(0.0F, -75.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.77F, class_7187.method_41829(0.0F, -77.5F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41821();

	public static final class_7184 left_door_close = class_7184.class_7185.method_41818(0.96F)
			.method_41820("LeftDoor", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, -77.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.2057F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.3429F, class_7187.method_41829(0.0F, -7.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.48F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.6171F, class_7187.method_41829(0.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.7543F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			))
			.method_41820("LeftDoor", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, -77.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.2057F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.3429F, class_7187.method_41829(0.0F, -7.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.48F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.6171F, class_7187.method_41829(0.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.7543F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			))
			.method_41821();

	public static final class_7184 right_door_close = class_7184.class_7185.method_41818(0.8F)
			.method_41820("RightDoor", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 77.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.24F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.4F, class_7187.method_41829(0.0F, 7.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.52F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.68F, class_7187.method_41829(0.0F, 2.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.8F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			))
			.method_41820("RightDoor", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 77.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.24F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.4F, class_7187.method_41829(0.0F, 7.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.52F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.68F, class_7187.method_41829(0.0F, 2.5F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.8F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			))
			.method_41821();

	public static final class_7184 phone_booth_open = class_7184.class_7185.method_41818(1.001F)
			.method_41820("phone", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.5F, class_7187.method_41829(0.0F, 123.02F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.0F, class_7187.method_41829(0.0F, 123.02F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41821();

	public static final class_7184 phone_booth_close = class_7184.class_7185.method_41818(0.5F)
			.method_41820("phone", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 123.02F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.5F, class_7187.method_41829(0.0F, 0.52F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41821();

	public static final class_7184 lamp_open = class_7184.class_7185.method_41818(0.68F)
			.method_41820("lamplid", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.32F, class_7187.method_41829(0.0F, 0.0F, 112.5F), class_7179.class_7181.field_37885),
					new class_7186(0.64F, class_7187.method_41829(0.0F, 0.0F, 112.5F), class_7179.class_7181.field_37885)
			))
			.method_41821();

	public static final class_7184 lamp_close = class_7184.class_7185.method_41818(0.7F)
			.method_41820("lamplid", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 112.5F), class_7179.class_7181.field_37884),
					new class_7186(0.14F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.28F, class_7187.method_41829(0.0F, 0.0F, 5.0F), class_7179.class_7181.field_37884),
					new class_7186(0.42F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
					new class_7186(0.54F, class_7187.method_41829(0.0F, 0.0F, 2.5F), class_7179.class_7181.field_37884),
					new class_7186(0.68F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
			))
			.method_41821();

	public static final class_7184 phone_ring = class_7184.class_7185.method_41818(0.7492F).method_41817()
			.method_41820("phone2", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -5.0F), class_7179.class_7181.field_37885),
					new class_7186(0.12F, class_7187.method_41829(0.0F, 0.0F, 5.0F), class_7179.class_7181.field_37885),
					new class_7186(0.24F, class_7187.method_41829(0.0F, 0.0F, -5.0F), class_7179.class_7181.field_37885),
					new class_7186(0.37F, class_7187.method_41829(0.0F, 0.0F, 5.0F), class_7179.class_7181.field_37885),
					new class_7186(0.49F, class_7187.method_41829(0.0F, 0.0F, -5.0F), class_7179.class_7181.field_37885),
					new class_7186(0.62F, class_7187.method_41829(0.0F, 0.0F, 5.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41829(0.0F, 0.0F, -5.0F), class_7179.class_7181.field_37885)
			))
			.method_41821();

	public static final class_7184 phone_dial = class_7184.class_7185.method_41818(3.5F)
			.method_41820("button1", new class_7179(class_7179.class_7183.field_37886,
					new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, -0.5F), class_7179.class_7181.field_37885),
					new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.0F, class_7187.method_41823(0.0F, 0.0F, -0.5F), class_7179.class_7181.field_37885),
					new class_7186(1.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(2.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(2.25F, class_7187.method_41823(0.0F, 0.0F, -0.5F), class_7179.class_7181.field_37885),
					new class_7186(2.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(3.25F, class_7187.method_41823(0.0F, 0.0F, -0.5F), class_7179.class_7181.field_37885),
					new class_7186(3.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41820("button2", new class_7179(class_7179.class_7183.field_37886,
					new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, -0.5F), class_7179.class_7181.field_37885),
					new class_7186(1.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.75F, class_7187.method_41823(0.0F, 0.0F, -0.5F), class_7179.class_7181.field_37885),
					new class_7186(2.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(2.39F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(2.64F, class_7187.method_41823(0.0F, 0.0F, -0.5F), class_7179.class_7181.field_37885),
					new class_7186(2.76F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(2.89F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(3.01F, class_7187.method_41823(0.0F, 0.0F, -0.5F), class_7179.class_7181.field_37885),
					new class_7186(3.26F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41821();

	public static final class_7184 falling_start = class_7184.class_7185.method_41818(4.0064F)
			.method_41820("TARDIF", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.2019F, class_7187.method_41829(-5.0429F, -7.4713F, 0.6574F), class_7179.class_7181.field_37885),
					new class_7186(2.4038F, class_7187.method_41829(-5.8752F, 5.4396F, 4.3908F), class_7179.class_7181.field_37885),
					new class_7186(4.0064F, class_7187.method_41829(4.8523F, -3.7228F, -4.5826F), class_7179.class_7181.field_37885)
			))
			.method_41820("TARDIF", new class_7179(class_7179.class_7183.field_37886,
					new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.2019F, class_7187.method_41823(0.0F, 5.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(2.4038F, class_7187.method_41823(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(4.0064F, class_7187.method_41823(0.0F, 20.0F, 0.0F), class_7179.class_7181.field_37885)
			))
			.method_41821();

	public static final class_7184 falling_loop = class_7184.class_7185.method_41818(10.0F).method_41817()
			.method_41820("TARDIF", new class_7179(class_7179.class_7183.field_37887,
					new class_7186(0.0F, class_7187.method_41829(4.8523F, -3.7228F, -4.5826F), class_7179.class_7181.field_37885),
					new class_7186(2.0F, class_7187.method_41829(2.6179F, -10.7235F, 0.7792F), class_7179.class_7181.field_37885),
					new class_7186(4.0F, class_7187.method_41829(-3.3373F, -10.9103F, 5.8662F), class_7179.class_7181.field_37885),
					new class_7186(6.0F, class_7187.method_41829(-3.8532F, -0.799F, 0.3305F), class_7179.class_7181.field_37885),
					new class_7186(8.0F, class_7187.method_41829(1.3491F, -8.5713F, -0.5815F), class_7179.class_7181.field_37885),
					new class_7186(10.0F, class_7187.method_41829(4.8523F, -3.7228F, -4.5826F), class_7179.class_7181.field_37885)
			))
			.method_41820("TARDIF", new class_7179(class_7179.class_7183.field_37886,
					new class_7186(0.0F, class_7187.method_41823(0.0F, 20.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(1.0F, class_7187.method_41823(0.0F, 22.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(2.0F, class_7187.method_41823(0.0F, 20.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(3.0F, class_7187.method_41823(0.0F, 22.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(4.0F, class_7187.method_41823(0.0F, 20.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(5.0F, class_7187.method_41823(0.0F, 22.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(6.0F, class_7187.method_41823(0.0F, 20.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(7.0F, class_7187.method_41823(0.0F, 22.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(8.0F, class_7187.method_41823(0.0F, 20.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(9.0F, class_7187.method_41823(0.0F, 22.0F, 0.0F), class_7179.class_7181.field_37885),
					new class_7186(10.0F, class_7187.method_41823(0.0F, 20.0F, 0.0F), class_7179.class_7181.field_37885)
			))
	.method_41821();
}

