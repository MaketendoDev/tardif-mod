package net.maketendo.tardifmod.client.screens;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.main.entities.tardis.TardisEntity;
import net.maketendo.tardifmod.main.entities.tardis.TardisInteriorDoorEntity;
import net.minecraft.class_10799;
import net.minecraft.class_1132;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_332;
import net.minecraft.class_3966;
import net.minecraft.class_9779;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

public class DevOverlay implements HudRenderCallback {
    @Override
    public void onHudRender(@NonNull class_332 drawContext, @NonNull class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        if (client.field_1690.field_1842) return;
        class_3218 serverWorld = getServerWorld(client);

        drawContext.method_25290(
                class_10799.field_56883,
                class_2960.method_60655(
                        TARDIFMod.MOD_ID,
                        "textures/gui/wrench_ui.png"
                ),
                1, 2,
                0, 0,
                16, 16,
                16, 16
        );



        drawContext.method_27535(
                client.field_1772,
                class_2561.method_43470("TARDIF Mod " + client.method_1547() + " " + FabricLoader.getInstance().getRawGameVersion() + " - Development Build")
                        .method_27692(class_124.field_1067),
                18,
                5,
                0xFFFFFFFF
        );

        drawContext.method_51439(
                client.field_1772,
                class_2561.method_43470("---------------------------------------").method_27692(class_124.field_1067),
                18,
                13,
                0xFFFFFFFF,
                true
        );

        drawContext.method_51439(
                client.field_1772,
                class_2561.method_43470("FPS: " + client.method_47599()),
                18,
                23,
                0xFFFFFFFF,
                false
        );

        if (client.field_1765 instanceof class_3966 entityHit) {
            class_1297 entity = entityHit.method_17782();

            drawContext.method_51439(
                    client.field_1772,
                    class_2561.method_43470("Looking at: " + entity.method_5477().getString()),
                    18,
                    33,
                    0xFFFFFFFF,
                    false
            );

            if (entity instanceof TardisEntity tardisEntity) {
                drawContext.method_51439(
                        client.field_1772,
                        class_2561.method_43470("ID: " + tardisEntity.getTardisId()),
                        18,
                        43,
                        0xFFFFFFFF,
                        false
                );
            }

            if (entity instanceof TardisInteriorDoorEntity tardisEntity) {
                drawContext.method_51439(
                        client.field_1772,
                        class_2561.method_43470("ID: " + tardisEntity.getTardisId()),
                        18,
                        43,
                        0xFFFFFFFF,
                        false
                );
            }
        }



    }

    private @Nullable class_3218 getServerWorld(class_310 client) {
        if (client.field_1687 == null) {
            return null;
        } else {
            class_1132 integratedServer = client.method_1576();
            return integratedServer != null ? integratedServer.method_3847(client.field_1687.method_27983()) : null;
        }
    }

}
