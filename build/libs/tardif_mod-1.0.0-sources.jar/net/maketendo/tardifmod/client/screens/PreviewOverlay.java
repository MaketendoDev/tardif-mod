package net.maketendo.tardifmod.client.screens;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.jspecify.annotations.NonNull;

public class PreviewOverlay implements HudRenderCallback {
    @Override
    public void onHudRender(@NonNull class_332 drawContext, @NonNull class_9779 tickCounter) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_2561 text = class_2561.method_43470("FEATURES SUBJECT TO CHANGE")
                .method_27692(class_124.field_1067);

        int screenWidth = client.method_22683().method_4486();
        int textWidth = client.field_1772.method_27525(text);

        int x = (screenWidth - textWidth) / 2;
        int y = 5;

        drawContext.method_27535(
                client.field_1772,
                text,
                x,
                y,
                0x88FFFFFF
        );
    }
}
