package net.maketendo.tardifmod.client.renderers.entities;

import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.client.models.entities.PoliceBoxInteriorDoorModel;
import net.maketendo.tardifmod.client.renderers.entities.renderstates.TARDISEntityRenderState;
import net.maketendo.tardifmod.main.entities.tardis.TardisInteriorDoorEntity;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_922;

public class TardisInteriorDoorEntityRenderer extends class_922<TardisInteriorDoorEntity, TARDISEntityRenderState, PoliceBoxInteriorDoorModel> {

    public static final class_2960 TEXTURE = TARDIFMod.id("textures/entity/tardis/skins/police_box_troughton.png");

    public TardisInteriorDoorEntityRenderer(class_5617.class_5618 context) {
        super(context, new PoliceBoxInteriorDoorModel(context.method_32167(PoliceBoxInteriorDoorModel.LAYER_LOCATION)), 0.5F);
    }

    @Override
    public void extractRenderState(TardisInteriorDoorEntity entity, TARDISEntityRenderState state, float tickDelta) {
        super.method_62355(entity, state, tickDelta);
    }

    @Override
    public TARDISEntityRenderState method_55269() {
        return new TARDISEntityRenderState();
    }

    @Override
    public void submit(TARDISEntityRenderState entityRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState) {
        super.method_4054(entityRenderState, poseStack, submitNodeCollector, cameraRenderState);
    }

    @Override
    public class_2960 getTextureLocation(TARDISEntityRenderState livingEntityRenderState) {
        return TEXTURE;
    }

    @Override
    protected boolean shouldShowName(TardisInteriorDoorEntity livingEntity, double d) {
        return false;
    }
}