package net.maketendo.tardifmod.client.renderers.entities;

import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.client.models.entities.PoliceBoxModel;
import net.maketendo.tardifmod.client.renderers.entities.renderstates.TARDISEntityRenderState;
import net.maketendo.tardifmod.main.TARDIFItems;
import net.maketendo.tardifmod.main.entities.tardis.TardisEntity;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_922;

public class TARDISEntityRenderer extends class_922<TardisEntity, TARDISEntityRenderState, PoliceBoxModel> {

    public static final class_2960 TEXTURE = TARDIFMod.id("textures/entity/tardis/skins/police_box_troughton.png");

    public TARDISEntityRenderer(class_5617.class_5618 context) {
        super(context, new PoliceBoxModel(context.method_32167(PoliceBoxModel.LAYER_LOCATION)), 0.5F);
    }

    @Override
    public void extractRenderState(TardisEntity entity, TARDISEntityRenderState state, float tickDelta) {
        super.method_62355(entity, state, tickDelta);

        //state.ageInTicks = entity.tickCount + tickDelta;

        state.doorRightOpenAnimationState.method_61401(entity.doorRightOpenAnimationState);
        state.doorLeftOpenAnimationState.method_61401(entity.doorLeftOpenAnimationState);

        state.doorRightCloseAnimationState.method_61401(entity.doorRightCloseAnimationState);
        state.doorLeftCloseAnimationState.method_61401(entity.doorLeftCloseAnimationState);

        state.phoneBoothOpenAnimationState.method_61401(entity.phoneBoothOpenAnimationState);
        state.phoneBoothCloseAnimationState.method_61401(entity.phoneBoothCloseAnimationState);

        state.lampOpenAnimationState.method_61401(entity.lampOpenAnimationState);
        state.lampCloseAnimationState.method_61401(entity.lampCloseAnimationState);

        state.phoneRingAnimationState.method_61401(entity.phoneRingAnimationState);
        state.phoneDialAnimationState.method_61401(entity.phoneDialAnimationState);

        state.fallingStartAnimationState.method_61401(entity.fallingStartAnimationState);
        state.fallingLoopAnimationState.method_61401(entity.fallingLoopAnimationState);
    }

    @Override
    public TARDISEntityRenderState method_55269() {
        return new TARDISEntityRenderState();
    }

    @Override
    public void submit(TARDISEntityRenderState entityRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState) {
        super.method_4054(entityRenderState, poseStack, submitNodeCollector, cameraRenderState);
    }

    @Override
    public class_2960 getTextureLocation(TARDISEntityRenderState livingEntityRenderState) {
        return TEXTURE;
    }

    @Override
    protected boolean shouldShowName(TardisEntity entity, double distance) {

        class_310 client = class_310.method_1551();
        class_1657 player = client.field_1724;

        if (player == null) return false;

        class_1799 main = player.method_6047();
        class_1799 off = player.method_6079();

        return main.method_7909() == TARDIFItems.SONIC_SCREWDRIVER
                || off.method_7909() == TARDIFItems.SONIC_SCREWDRIVER;
    }
}