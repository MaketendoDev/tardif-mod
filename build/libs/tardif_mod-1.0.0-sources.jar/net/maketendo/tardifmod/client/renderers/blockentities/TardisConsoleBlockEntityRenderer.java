package net.maketendo.tardifmod.client.renderers.blockentities;

import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.client.models.console.CrystallineConsoleModel;
import net.maketendo.tardifmod.client.renderers.blockentities.renderstates.TardisConsoleBlockEntityRenderState;
import net.maketendo.tardifmod.main.blockentities.TardisConsoleBlockEntity;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import org.jetbrains.annotations.Nullable;

public class TardisConsoleBlockEntityRenderer implements class_827<TardisConsoleBlockEntity, TardisConsoleBlockEntityRenderState> {

    public static final class_2960 TEXTURE = TARDIFMod.id("textures/entity/consoles/crystal.png");

    public TardisConsoleBlockEntityRenderer(class_5614.class_5615 context) {
        super();
    }



    @Override
    public boolean method_3563() {
        return true;
    }

    @Override
    public TardisConsoleBlockEntityRenderState method_74335() {
        return new TardisConsoleBlockEntityRenderState();
    }

    @Override
    public void extractRenderState(TardisConsoleBlockEntity blockEntity, TardisConsoleBlockEntityRenderState state, float tickProgress, class_243 cameraPos, @Nullable class_11683.class_11792 crumblingOverlay) {
    }

    @Override
    public void submit(TardisConsoleBlockEntityRenderState blockEntityRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState) {
        poseStack.method_22903();


        submitNodeCollector.method_73489(
                new CrystallineConsoleModel(CrystallineConsoleModel.createBodyLayer().method_32109()),
                13f,
                poseStack,
                class_12249.method_75990(TEXTURE),
                0,
                class_4608.field_21444,
                2,
                null
        );

        poseStack.method_22909();
    }
}
