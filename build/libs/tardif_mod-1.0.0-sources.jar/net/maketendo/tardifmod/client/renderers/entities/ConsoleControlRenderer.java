package net.maketendo.tardifmod.client.renderers.entities;

import net.maketendo.tardifmod.main.entities.controls.ConsoleControlEntity;
import net.minecraft.class_10017;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class ConsoleControlRenderer extends class_897<ConsoleControlEntity, class_10017> {

    public ConsoleControlRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public class_10017 method_55269() {
        return new class_10017();
    }
}

