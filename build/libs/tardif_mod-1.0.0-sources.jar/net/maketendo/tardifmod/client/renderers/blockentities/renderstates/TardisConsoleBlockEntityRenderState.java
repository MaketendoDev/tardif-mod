package net.maketendo.tardifmod.client.renderers.blockentities.renderstates;

import net.minecraft.class_11954;

public class TardisConsoleBlockEntityRenderState extends class_11954 {
}
