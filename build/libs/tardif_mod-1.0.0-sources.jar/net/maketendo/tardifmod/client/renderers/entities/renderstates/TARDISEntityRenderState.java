package net.maketendo.tardifmod.client.renderers.entities.renderstates;

import net.maketendo.tardifmod.client.animations.tardis.TardisAnimation;
import net.minecraft.class_10042;
import net.minecraft.class_7094;
import java.util.ArrayList;
import java.util.List;

public class TARDISEntityRenderState extends class_10042 {
    private boolean door_open = false;

    //public float ageInTicks;

    public class_7094 doorRightOpenAnimationState = new class_7094();
    public class_7094 doorLeftOpenAnimationState = new class_7094();

    public class_7094 doorRightCloseAnimationState = new class_7094();
    public class_7094 doorLeftCloseAnimationState = new class_7094();

    public class_7094 phoneBoothOpenAnimationState = new class_7094();
    public class_7094 phoneBoothCloseAnimationState = new class_7094();

    public class_7094 lampOpenAnimationState = new class_7094();
    public class_7094 lampCloseAnimationState = new class_7094();

    public class_7094 phoneRingAnimationState = new class_7094();
    public class_7094 phoneDialAnimationState = new class_7094();

    public class_7094 fallingStartAnimationState = new class_7094();
    public class_7094 fallingLoopAnimationState = new class_7094();

    public Boolean getDoorOpened() {
        return door_open;
    }

    public void setDoorOpened(boolean opened) {
        this.door_open = opened;
    }

}
