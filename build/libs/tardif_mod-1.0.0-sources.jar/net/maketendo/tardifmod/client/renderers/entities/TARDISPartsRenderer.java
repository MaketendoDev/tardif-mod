package net.maketendo.tardifmod.client.renderers.entities;

import net.maketendo.tardifmod.main.entities.tardis.TardisPartEntity;
import net.minecraft.class_10017;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class TARDISPartsRenderer extends class_897<TardisPartEntity, class_10017> {

    public TARDISPartsRenderer(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @Override
    public class_10017 method_55269() {
        return new class_10017();
    }

}


