package net.maketendo.tardifmod.main;

import net.maketendo.tardifmod.TARDIFMod;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class TARDIFDimensions {

    public static final class_2960 TARDIS_DIM_ID =
            class_2960.method_60655(TARDIFMod.MOD_ID, "tardis");

    public static final class_5321<class_1937> TARDIS_WORLD =
            class_5321.method_29179(class_7924.field_41223, TARDIS_DIM_ID);

}
