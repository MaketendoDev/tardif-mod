package net.maketendo.tardifmod.main.blockentities.panels;

import net.maketendo.tardifmod.main.TARDIFBlockEntities;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

public class CoordinatesPanelBlockEntity extends class_2586 implements GeoBlockEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int increment = 1;

    public CoordinatesPanelBlockEntity(class_2338 pos, class_2680 state) {
        super(TARDIFBlockEntities.TARDIS_LIGHT_BLOCK, pos, state);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    public int getIncrement() {
        return increment;
    }

    public void adjustIncrement(int delta) {
        increment = Math.max(1, increment + delta);
    }

    public void cycleIncrement() {
        if (increment == 1) increment = 10;
        else if (increment == 10) increment = 100;
        else if (increment == 100) increment = 1000;
        else increment = 1;
    }


}
