package net.maketendo.tardifmod.main.blockentities;


import net.maketendo.tardifmod.main.TARDIFBlockEntities;
import net.maketendo.tardifmod.main.blocks.TardisLightBlock;
import net.maketendo.tardifmod.main.tardis.TardisData;
import net.maketendo.tardifmod.main.tardis.TardisManager;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class TardisLightBlockEntity extends class_2586 {

    public TardisLightBlockEntity(class_2338 pos, class_2680 state) {
        super(TARDIFBlockEntities.TARDIS_LIGHT_BLOCK, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, TardisLightBlockEntity be) {
        if (world.method_8608()) return;

        TardisData data = TardisManager.getTardisData(world, pos);
        if (data == null) return;

        int targetLight;

        if (!data.powered) {
            targetLight = 0;
        } else {
            targetLight = Math.max(0, Math.min(15, data.roundelLight));
        }

        if (state.method_11654(TardisLightBlock.LEVEL) != targetLight) {
            world.method_8652(
                    pos,
                    state.method_11657(TardisLightBlock.LEVEL, targetLight),
                    class_2248.field_31028
            );
        }
    }

    
}

