package net.maketendo.tardifmod.main.blockentities;


import net.maketendo.tardifmod.main.TARDIFBlockEntities;
import net.maketendo.tardifmod.main.blocks.RoundelBlock;
import net.maketendo.tardifmod.main.tardis.TardisData;
import net.maketendo.tardifmod.main.tardis.TardisManager;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class RoundelBlockEntity extends class_2586 {

    public RoundelBlockEntity(class_2338 pos, class_2680 state) {
        super(TARDIFBlockEntities.ROUNDELS, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, RoundelBlockEntity be) {
        if (world.method_8608()) return;

        TardisData data = TardisManager.getTardisData(world, pos);
        if (data == null) return;

        int targetLight;

        if (!data.powered) {
            targetLight = 0;
        } else {
            targetLight = Math.max(0, Math.min(15, data.roundelLight));
        }

        if (state.method_11654(RoundelBlock.LIGHT) != targetLight) {
            world.method_8652(
                    pos,
                    state.method_11657(RoundelBlock.LIGHT, targetLight),
                    class_2248.field_31028
            );
        }
    }
}

