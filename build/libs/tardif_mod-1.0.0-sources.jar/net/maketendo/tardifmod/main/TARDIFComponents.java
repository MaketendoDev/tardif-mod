package net.maketendo.tardifmod.main;

import com.mojang.serialization.Codec;
import net.maketendo.tardifmod.TARDIFMod;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class TARDIFComponents {
    public static final class_9331<Integer> LINKED_ID = class_2378.method_10230(
            class_7923.field_49658,
            class_2960.method_60655(TARDIFMod.MOD_ID, "linked_id"),
            class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57880()
    );

    public static void register() {}
}
