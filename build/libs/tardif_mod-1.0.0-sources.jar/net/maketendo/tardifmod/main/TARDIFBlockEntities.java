package net.maketendo.tardifmod.main;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.main.blockentities.RoundelBlockEntity;
import net.maketendo.tardifmod.main.blockentities.TardisConsoleBlockEntity;
import net.maketendo.tardifmod.main.blockentities.TardisLightBlockEntity;
import net.maketendo.tardifmod.main.blockentities.panels.CoordinatesPanelBlockEntity;
import net.maketendo.tardifmod.main.blockentities.panels.DematPanelBlockEntity;
import net.maketendo.tardifmod.main.blockentities.panels.PowerPanelBlockEntity;
import net.maketendo.tardifmod.main.blocks.RoundelBlock;
import net.maketendo.tardifmod.main.blocks.StainedBlock;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.function.Function;

public class TARDIFBlockEntities {

//    public static final BlockEntityType<PowerPanelBlockEntity> POWER_PANEL =
//            Registry.register(Registries.BLOCK_ENTITY_TYPE, Identifier.of(TARDIFMod.MOD_ID, "power_panel"),
//                    FabricBlockEntityTypeBuilder.create(PowerPanelBlockEntity::new, TARDIFBlocks.POWER_PANEL).build(null));
//
//    public static final BlockEntityType<CoordinatesPanelBlockEntity> COORDINATES_PANEL =
//            Registry.register(Registries.BLOCK_ENTITY_TYPE, Identifier.of(TARDIFMod.MOD_ID, "coordinates_panel"),
//                    FabricBlockEntityTypeBuilder.create(CoordinatesPanelBlockEntity::new, TARDIFBlocks.COORDINATES_PANEL).build(null));
//
//    public static final BlockEntityType<DematPanelBlockEntity> DEMATERIALISATION_PANEL =
//            Registry.register(Registries.BLOCK_ENTITY_TYPE, Identifier.of(TARDIFMod.MOD_ID, "dematerialisation_panel"),
//                    FabricBlockEntityTypeBuilder.create(DematPanelBlockEntity::new, TARDIFBlocks.DEMATERIALISATION_PANEL).build(null));

    public static final class_2591<TardisLightBlockEntity> TARDIS_LIGHT_BLOCK =
            class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(TARDIFMod.MOD_ID, "tardis_light_block"),
                    FabricBlockEntityTypeBuilder.create(TardisLightBlockEntity::new, TARDIFBlocks.TARDIS_LIGHT_BLOCK).build(null));

    public static final class_2591<TardisConsoleBlockEntity> TARDIS_CONSOLE_BLOCK =
            class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(TARDIFMod.MOD_ID, "tardis_console_block"),
                    FabricBlockEntityTypeBuilder.create(TardisConsoleBlockEntity::new, TARDIFBlocks.TARDIS_CONSOLE_BLOCK).build(null));

    public static final class_2591<RoundelBlockEntity> ROUNDELS =
            class_2378.method_10230(
                    class_7923.field_41181,
                    class_2960.method_60655(TARDIFMod.MOD_ID, "roundel"),
                    FabricBlockEntityTypeBuilder.create(
                            RoundelBlockEntity::new,
                            TARDIFBlocks.WHITE_ROUNDEL,
                            TARDIFBlocks.WHITE_ROUNDEL_HALF,
                            TARDIFBlocks.GRAY_ROUNDEL,
                            TARDIFBlocks.GRAY_ROUNDEL_HALF,
                            TARDIFBlocks.DARK_GRAY_ROUNDEL,
                            TARDIFBlocks.DARK_GRAY_ROUNDEL_HALF,
                            TARDIFBlocks.BLACK_ROUNDEL,
                            TARDIFBlocks.BLACK_ROUNDEL_HALF,
                            TARDIFBlocks.BROWN_ROUNDEL,
                            TARDIFBlocks.BROWN_ROUNDEL_HALF,
                            TARDIFBlocks.RED_ROUNDEL,
                            TARDIFBlocks.RED_ROUNDEL_HALF,
                            TARDIFBlocks.ORANGE_ROUNDEL,
                            TARDIFBlocks.ORANGE_ROUNDEL_HALF,
                            TARDIFBlocks.YELLOW_ROUNDEL,
                            TARDIFBlocks.YELLOW_ROUNDEL_HALF,
                            TARDIFBlocks.LIME_ROUNDEL,
                            TARDIFBlocks.LIME_ROUNDEL_HALF,
                            TARDIFBlocks.GREEN_ROUNDEL,
                            TARDIFBlocks.GREEN_ROUNDEL_HALF,
                            TARDIFBlocks.CYAN_ROUNDEL,
                            TARDIFBlocks.CYAN_ROUNDEL_HALF,
                            TARDIFBlocks.LIGHT_BLUE_ROUNDEL,
                            TARDIFBlocks.LIGHT_BLUE_ROUNDEL_HALF,
                            TARDIFBlocks.BLUE_ROUNDEL,
                            TARDIFBlocks.BLUE_ROUNDEL_HALF,
                            TARDIFBlocks.PURPLE_ROUNDEL,
                            TARDIFBlocks.PURPLE_ROUNDEL_HALF,
                            TARDIFBlocks.MAGENTA_ROUNDEL,
                            TARDIFBlocks.MAGENTA_ROUNDEL_HALF,
                            TARDIFBlocks.PINK_ROUNDEL,
                            TARDIFBlocks.PINK_ROUNDEL_HALF
                    ).build()
            );


    public static void register() {
    }
}
