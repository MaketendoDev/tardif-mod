package net.maketendo.tardifmod.main.entities;

import org.jspecify.annotations.NonNull;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.stateless.StatelessGeoEntity;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

public abstract class ObjectEntity extends class_1309 {

    public ObjectEntity(class_1299<?> type, class_1937 world) {
        super((class_1299<? extends class_1309>) type, world);
    }

    @Override
    public boolean method_63612(class_243 oldPos, class_243 newPos, List<class_238> boxes) {
        return super.method_63612(oldPos, newPos, boxes);
    }

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        return false;
    }

    @Override
    public boolean method_5732() {
        return true;
    }

    @Override
    public boolean method_5863() {
        return true;
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_5807() {
        return false;
    }

    @Override
    public boolean method_5733() {
        return false;
    }

    @Override
    public @NonNull class_1306 method_6068() {
        return null;
    }

    @Override
    protected void method_6070() {
        // disables the living entity push entities back.
        //super.pushEntities();
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1309.method_26827()
                .method_26868(class_5134.field_23716, 1000.0)
                .method_26868(class_5134.field_23719, 0.0)
                .method_26868(class_5134.field_23718, 1.0);
    }
}
