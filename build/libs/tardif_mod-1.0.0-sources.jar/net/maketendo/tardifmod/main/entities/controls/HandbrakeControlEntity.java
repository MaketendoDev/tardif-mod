package net.maketendo.tardifmod.main.entities.controls;

import net.minecraft.class_1299;
import net.minecraft.class_1937;

public class HandbrakeControlEntity extends ConsoleControlEntity {

    public HandbrakeControlEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

//    @Override
//    public void onUse(PlayerEntity player) {
//        BlockPos pos = getConsolePos();
//        if (pos == null) return;
//
//        if (getEntityWorld().getBlockEntity(pos) instanceof TardisConsoleBlockEntity console) {
//            TardisData tardis = TardisWorldUtil.getTardisData(getEntityWorld(), getConsolePos());
//            //console.toggleHandbrake(player);
//            assert tardis != null;
//            tardis.dematerialised = true;
//        }
//    }
}

