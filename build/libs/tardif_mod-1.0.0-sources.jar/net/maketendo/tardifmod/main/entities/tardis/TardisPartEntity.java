package net.maketendo.tardifmod.main.entities.tardis;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2945;
import net.minecraft.class_3218;

public class TardisPartEntity extends class_1297 {
    private TardisEntity parent;

    public TardisPartEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    public void setParent(TardisEntity parent) {
        this.parent = parent;
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (parent == null || parent.method_31481()) {
            this.method_31472();
            return;
        }

        this.method_5808(
                parent.method_23317(),
                parent.method_23318(),
                parent.method_23321(),
                parent.method_36454(),
                parent.method_36455()
        );
    }

    @Override
    public boolean method_5767() {
        return true;
    }

    @Override
    public boolean method_5740() {
        return true;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {}

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        return false;
    }

    @Override
    protected void method_5749(class_11368 view) {}

    @Override
    protected void method_5652(class_11372 view) {}
}
