package net.maketendo.tardifmod.main.entities.controls;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import org.jspecify.annotations.Nullable;

public class ConsoleControlEntity extends class_1297 {

    private static final class_2940<Float> LENGTH =
            class_2945.method_12791(ConsoleControlEntity.class, class_2943.field_13320);
    private static final class_2940<Float> HEIGHT =
            class_2945.method_12791(ConsoleControlEntity.class, class_2943.field_13320);
    private static final class_2940<Float> WIDTH =
            class_2945.method_12791(ConsoleControlEntity.class, class_2943.field_13320);

    public ConsoleControlEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(LENGTH, 1f);
        builder.method_56912(HEIGHT, 1f);
        builder.method_56912(WIDTH, 1f);
    }

    @Override
    protected void method_5652(class_11372 view) {
        view.method_71464("Length", this.field_6011.method_12789(LENGTH));
        view.method_71464("Height", this.field_6011.method_12789(HEIGHT));
        view.method_71464("Width", this.field_6011.method_12789(WIDTH));
    }

    @Override
    protected void method_5749(class_11368 view) {
        if (view.contains("Length")) {
            this.field_6011.method_12778(LENGTH, view.method_71423("Length", 0L));
        }

        if (view.contains("Height")) {
            this.field_6011.method_12778(HEIGHT, view.method_71423("Height", 0L));
        }

        if (view.contains("Width")) {
            this.field_6011.method_12778(WIDTH, view.method_71423("Width", 0L));
        }

        this.method_18382();
    }


    @Override
    public boolean method_5767() {
        return true;
    }

    @Override
    public boolean method_5727(double cameraX, double cameraY, double cameraZ) {
        return false;
    }

    public void setSize(float length, float height, float width) {
        this.field_6011.method_12778(LENGTH, length);
        this.field_6011.method_12778(HEIGHT, height);
        this.field_6011.method_12778(WIDTH, width);

        this.method_18382();
    }

    @Override
    public class_238 method_65341(class_243 pos) {
        double length = this.field_6011.method_12789(LENGTH);
        double height = this.field_6011.method_12789(HEIGHT);
        double width = this.field_6011.method_12789(WIDTH);

        double x = this.method_23317();
        double y = this.method_23318();
        double z = this.method_23321();

        return new class_238(
                x - width / 2.0,
                y,
                z - length / 2.0,
                x + width / 2.0,
                y + height,
                z + length / 2.0
        );
    }




    @Override
    public boolean method_30948(@Nullable class_1297 entity) {
        return false;
    }

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        return false;
    }
}
