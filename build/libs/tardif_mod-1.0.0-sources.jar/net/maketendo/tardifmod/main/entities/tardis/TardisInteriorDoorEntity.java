package net.maketendo.tardifmod.main.entities.tardis;

import net.maketendo.tardifmod.main.entities.ObjectEntity;
import net.maketendo.tardifmod.main.items.extendable.LinkableItem;
import net.maketendo.tardifmod.main.tardis.TardisData;
import net.maketendo.tardifmod.main.tardis.TardisManager;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import org.jspecify.annotations.NonNull;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.Set;

public class TardisInteriorDoorEntity extends ObjectEntity implements GeoAnimatable {
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    private static final class_2940<Integer> TARDIS_ID =
            class_2945.method_12791(TardisInteriorDoorEntity.class, class_2943.field_13327);
    private static final class_2940<Boolean> DOOR_OPEN =
            class_2945.method_12791(TardisInteriorDoorEntity.class, class_2943.field_13323);


    public TardisInteriorDoorEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    public int getTardisId() {
        return this.field_6011.method_12789(TARDIS_ID);
    }

    public void setTardisId(int id) {
        this.field_6011.method_12778(TARDIS_ID, id);
    }

    public void setDoorOpen(boolean open) {
        field_6011.method_12778(DOOR_OPEN, open);
    }

    public boolean isDoorOpen() {
        return field_6011.method_12789(DOOR_OPEN);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);

        builder.method_56912(TARDIS_ID, -1);
        builder.method_56912(DOOR_OPEN, false);
    }

    @Override
    protected void method_5652(class_11372 view) {
        view.method_71465("TardisId", getTardisId());
    }

    @Override
    protected void method_5749(class_11368 view) {
        setTardisId(view.method_71424("TardisId", -1));
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (method_73183().method_8608()) return;

        TardisData data = TardisManager.getFromId(method_73183().method_8503(), getTardisId());
        setDoorOpen(data.doorOpen);

        method_73183().method_8398().method_12124(method_31476(), true);

        data.interiorPos = method_73189();
        data.interiorYaw = method_36454();
    }

    @Override
    public class_1269 method_5664(class_1657 player, class_243 hitPos, class_1268 hand) {

        if (this.method_73183().method_8608()) return class_1269.field_5812;

        class_1799 stack = player.method_5998(hand);
        TardisData data = TardisManager.getFromId(method_73183().method_8503(), getTardisId());

        if (stack.method_7909() instanceof LinkableItem item) {
            linkItem(item,  stack, player);
        } else {
            if (!player.method_5715()) {
                if (!data.doorLocked) {
                    if (data.doorOpen == true) {
                        data.doorOpen = false;
                    } else {
                        data.doorOpen = true;
                    }
                } else {
                    player.method_7353(class_2561.method_43470("The door is locked...").method_27692(class_124.field_1080), true);
                    playSoundAtTardisDoor(class_3417.field_14562, 0.5f);
                }
            } else {
                lockTardisDoor(data, player);
            }
        }

        return class_1269.field_21466;
    }

    @Override
    public void method_5694(class_1657 player) {
        super.method_5694(player);

        if (method_73183().method_8608()) return;

        TardisData data = TardisManager.getFromId(method_73183().method_8503(), getTardisId());
        if (data != null && !data.doorOpen) return;

        double maxDistance = 0.3D;

        if (player.method_73189().method_1025(this.method_73189()) <= maxDistance * maxDistance) {
            class_243 offset = class_243.method_1030(0, data.exteriorYaw).method_1021(0.45);

            player.method_48105(
                    method_73183().method_8503().method_3847(class_5321.method_29179(class_7924.field_41223, data.exteriorDimension)),
                    data.exteriorPos.method_10216() + offset.field_1352, data.exteriorPos.method_10214(), data.exteriorPos.method_10215() + offset.field_1350,
                    Set.of(),
                    data.exteriorYaw,
                    player.method_36455(),
                    true
            );

            player.method_6092(
                    new class_1293(
                            class_1294.field_5919,
                            25,
                            1,
                            false,
                            false
                    )
            );
        }
    }

    @Override
    protected class_238 method_65341(class_243 pos) {
        return new class_238(
                method_23317() - 0.6, method_23318(),
                method_23321() - 0.1,
                method_23317() + 0.6, method_23318() + 2.5,
                method_23321() + 0.1
        );
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>("DoorAnim", state -> {
            if (isDoorOpen())
                return state.setAndContinue(RawAnimation.begin().thenPlayAndHold("open"));
            else
                return state.setAndContinue(RawAnimation.begin().thenPlayAndHold("close"));
        }));
    }

    @Override
    public @NonNull AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }

    public void lockTardisDoor(TardisData data, class_1657 player) {
        if (!data.doorOpen) {
            if (data.doorLocked) {
                data.doorLocked = false;
                player.method_7353(class_2561.method_43470("\uDD13").method_27692(class_124.field_1080), true);
            } else {
                data.doorLocked = true;
                player.method_7353(class_2561.method_43470("\uDD12").method_27692(class_124.field_1080), true);
            }
            playSoundAtTardisDoor(class_3417.field_23199, 0.5f);
        }
    }

    public void linkItem(LinkableItem item, class_1799 stack, class_1657 player) {
        if (!(LinkableItem.getLinkedId(stack) == getTardisId())) {
            int id = this.getTardisId();

            if (id < 0) {
                player.method_7353(class_2561.method_43470("TARDIS Door is not linked to an ID").method_27692(class_124.field_1061), true);
            }

            LinkableItem.setLinkedId(stack, id);
            player.method_7353(class_2561.method_43470("Linked to TARDIS #" + id + "!").method_27692(class_124.field_1060), true);
        }
    }

    public void playSoundAtTardisDoor(class_3414 soundEvent, Float volume) {
        method_73183().method_43128(
                null,
                method_23317(), method_23318(), method_23321(),
                soundEvent,
                class_3419.field_15254,
                volume,
                1.0f
        );
    }
}
