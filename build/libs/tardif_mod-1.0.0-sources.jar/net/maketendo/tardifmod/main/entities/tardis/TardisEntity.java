package net.maketendo.tardifmod.main.entities.tardis;

import net.maketendo.tardifmod.client.animations.tardis.TardisAnimation;
import net.maketendo.tardifmod.client.managers.AnimationManager;
import net.maketendo.tardifmod.main.*;
import net.maketendo.tardifmod.main.entities.TardisExteriorBase;
import net.maketendo.tardifmod.main.tardis.TardisData;
import net.maketendo.tardifmod.main.tardis.TardisManager;
import net.maketendo.tardifmod.utils.animation.FadeTimeline;
import net.maketendo.tardifmod.utils.TardisInteriorUtil;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_5819;
import net.minecraft.class_7094;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.*;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;

import static net.maketendo.tardifmod.utils.CommandUtil.runCommandAsEntity;

public class TardisEntity extends TardisExteriorBase {
    private static final class_2940<Integer> TARDIS_ID =
            class_2945.method_12791(TardisEntity.class, class_2943.field_13327);
    private static final class_2940<Boolean> DOOR_OPEN =
            class_2945.method_12791(TardisEntity.class, class_2943.field_13323);
    private static final class_2940<Boolean> TARDIS_INITIALISED =
            class_2945.method_12791(TardisEntity.class, class_2943.field_13323);

    private int dematTicks = 0;
    private float fade = 1.0f;
    private class_1923 forcedChunk;
    private boolean dematAnimStarted = false;

    public static final class_2940<Integer> DATA_ANIMATION =
            class_2945.method_12791(TardisEntity.class, class_2943.field_13327);

    // Animations
    public final class_7094 doorRightOpenAnimationState = new class_7094();
    public final class_7094 doorLeftOpenAnimationState = new class_7094();

    public final class_7094 doorRightCloseAnimationState = new class_7094();
    public final class_7094 doorLeftCloseAnimationState = new class_7094();

    public final class_7094 phoneBoothOpenAnimationState = new class_7094();
    public final class_7094 phoneBoothCloseAnimationState = new class_7094();

    public final class_7094 lampOpenAnimationState = new class_7094();
    public final class_7094 lampCloseAnimationState = new class_7094();

    public final class_7094 phoneRingAnimationState = new class_7094();
    public final class_7094 phoneDialAnimationState = new class_7094();

    public final class_7094 fallingStartAnimationState = new class_7094();
    public final class_7094 fallingLoopAnimationState = new class_7094();

    public TardisEntity(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Override
    public @NonNull class_2561 method_5477() {
        return class_2561.method_43470("§bTARDIS Exterior §7| ID: " + getTardisId());
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(TARDIS_ID, -1);
        builder.method_56912(DOOR_OPEN, false);
        builder.method_56912(TARDIS_INITIALISED, false);
        builder.method_56912(DATA_ANIMATION, 0);
    }

    public int getTardisId() {
        return this.field_6011.method_12789(TARDIS_ID);
    }

    public void setTardisId(int id) {
        this.field_6011.method_12778(TARDIS_ID, id);
    }

    public void setDoorOpen(boolean open) {
        field_6011.method_12778(DOOR_OPEN, open);
    }

    public boolean isDoorOpen() {
        return field_6011.method_12789(DOOR_OPEN);
    }

    public void preInitialised() {this.field_6011.method_12778(TARDIS_INITIALISED, true);}

    public void setOpacity(Float opacity) {
        this.fade = opacity;
    }

    public void playAnimation(TardisAnimation animation) {
        this.field_6011.method_12778(DATA_ANIMATION, animation.ordinal());
    }

    @Override
    protected void method_5652(class_11372 view) {
        view.method_71472("TardisInit", this.field_6011.method_12789(TARDIS_INITIALISED));
        view.method_71465("TardisId", getTardisId());

    }

    @Override
    protected void method_5749(class_11368 view) {
        this.field_6011.method_12778(TARDIS_INITIALISED, view.method_71433("TardisInit", false));
        setTardisId(view.method_71424("TardisId", -1));
    }

    @Override
    public void method_5674(class_2940<?> key) {

        if (DATA_ANIMATION.equals(key)) {

            switch (TardisAnimation.values()[this.field_6011.method_12789(DATA_ANIMATION)]) {

                case DOOR_OPEN -> {
                    //this.doorRightCloseAnimationState.stop();
                    //this.doorLeftCloseAnimationState.stop();

                    this.doorRightOpenAnimationState.method_41324(this.field_6012);
                    this.doorLeftOpenAnimationState.method_41324(this.field_6012);
                }

                case DOOR_CLOSE -> {
                    //this.doorLeftOpenAnimationState.stop();
                    //this.doorRightOpenAnimationState.stop();

                    this.doorRightCloseAnimationState.method_41324(this.field_6012);
                    this.doorLeftCloseAnimationState.method_41324(this.field_6012);
                }

                case PHONE_OPEN -> this.phoneBoothOpenAnimationState.method_41322(this.field_6012);

                case PHONE_CLOSE -> this.phoneBoothCloseAnimationState.method_41322(this.field_6012);

                case LAMP_OPEN -> this.lampOpenAnimationState.method_41322(this.field_6012);

                case LAMP_CLOSE -> this.lampCloseAnimationState.method_41322(this.field_6012);

                case PHONE_RING -> this.phoneRingAnimationState.method_41322(this.field_6012);

                case PHONE_DIAL -> this.phoneDialAnimationState.method_41322(this.field_6012);

                case FALLING_START -> this.fallingStartAnimationState.method_41322(this.field_6012);

                case FALLING_LOOP -> this.fallingLoopAnimationState.method_41322(this.field_6012);
            }
        }

        super.method_5674(key);
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.field_6011.method_12789(TARDIS_INITIALISED) && method_73183().method_8608()) {
            TardisData data = TardisManager.getFromId(method_73183().method_8503(), getTardisId());
            clientTick(data);
        }

        if (method_73183().method_8608()) return;

        forceLoadChunk();

        if (this.field_6011.method_12789(TARDIS_INITIALISED)) {
            TardisData data = TardisManager.getFromId(method_73183().method_8503(), getTardisId());
            setDoorOpen(data.doorOpen);

            if (!data.dematerialised) {
                dematAnimStarted = false;
                setOpacity(1.0f);
            }

            data.exteriorPos = method_73189();
            data.exteriorYaw = this.method_36454();

            if (data.dematerialised) {
                dematTicks++;
                if (dematTicks % 16  == 0) {
                    runCommandAsEntity(this, "particle flash{color:[1.0,1.0,1.0,1.0]} ~ ~3 ~ 0 0 0 0.1 1 normal");
                }
                if (dematTicks >= 20 * 15) {method_5650(class_5529.field_26999);}
            }
        }

        // TARDIS Vector (hehe bananas)
        //tardisMovement();

        // Tardis Initialising
        initTardis();
    }

    private void clientTick(TardisData data) {
        if (data.dematerialised && !dematAnimStarted) {
            dematAnimStarted = true;

            AnimationManager.trigger(
                    new FadeTimeline(1.0f, this::setOpacity)
                            .fadeTo(20, 1.0f)
                            .fadeTo(20, 0.7f)
                            .fadeTo(20, 1.0f)
                            .fadeTo(20, 0.6f)
                            .fadeTo(20, 0.9f)
                            .fadeTo(20, 0.5f)
                            .fadeTo(15, 0.7f)
                            .fadeTo(20, 0.3f)
                            .fadeTo(15, 0.5f)
                            .fadeTo(20, 0.2f)
                            .fadeTo(30, 0f)
                            .onTick(this::spawnWind)
            );
        }
    }

    private void spawnWind() {
        class_1937 world = method_73183();
        class_5819 random = world.method_8409();

        for (int i = 0; i < 6; i++) {
            double angle = random.method_43058() * Math.PI * 2;
            double speed = 0.05 + random.method_43058() * 0.05;
            double vx = Math.cos(angle) * speed;
            double vz = Math.sin(angle) * speed;
            double vy = 0.1 + random.method_43058() * 0.05;

            double x = method_23317() + (random.method_43058() - 0.5) * 0.3;
            double y = method_23318() + 0.02;
            double z = method_23321() + (random.method_43058() - 0.5) * 0.3;

            class_2680 ground = world.method_8320(method_24515().method_10074());
            if (!ground.method_26215()) {
                world.method_8406(
                        new class_2388(class_2398.field_11217, ground),
                        x, y, z,
                        vx, vy, vz
                );
            }
        }
    }


    @Override
    public class_1269 method_5664(class_1657 player, class_243 hitPos, class_1268 hand) {

        if (this.method_73183().method_8608()) return class_1269.field_5812;

        initParts();

        class_1799 itemStack = player.method_5998(hand);
        TardisData data = TardisManager.getFromId(method_73183().method_8503(), getTardisId());

        if (itemStack.method_7909() == class_1802.field_8719) {
            leadTardis(player, hand);
        } else if (itemStack.method_31573(TARDIFTags.Items.TARDIS_KEYS)) {
            lockTardisDoor(data, player);
        } else {
            if (!(hitPos.field_1351 >= this.method_17682() - 0.25)) {
                tardisDoor(data, player);
            } else {
                player.method_5804(this);
            }
        }
        return class_1269.field_21466;
    }

    @Override
    public void method_5694(class_1657 player) {
        super.method_5694(player);

        if (!this.field_6011.method_12789(TARDIS_INITIALISED)) return;
        TardisData data = TardisManager.getFromId(method_73183().method_8503(), getTardisId());

        if (method_73183().method_8608()) return;
        if (!data.doorOpen) return;

        double maxDistance = 0.40D;

        if (player.method_73189().method_1025(this.method_73189()) <= maxDistance * maxDistance) {
            class_243 offset = class_243.method_1030(0, data.interiorYaw).method_1021(0.6);

            player.method_48105(
                    method_73183().method_8503().method_3847(TARDIFDimensions.TARDIS_WORLD),
                    data.interiorPos.method_10216() - offset.field_1352, data.interiorPos.method_10214(), data.interiorPos.method_10215() - offset.field_1350,
                    Set.of(),
                    data.interiorYaw + 180f,
                    player.method_36455(),
                    true
            );

            player.method_6092(
                    new class_1293(
                            class_1294.field_5919,
                            25,
                            1,
                            false,
                            false
                    )
            );
        }
    }

    @Override
    public boolean method_5698(class_1297 attacker) {
        playSoundAtTardis(class_3417.field_14562, 0.5f);
        return super.method_5698(attacker);
    }

    @Override
    public boolean method_30948(@Nullable class_1297 entity) {
        return !isDoorOpen();
    }

    public void leadTardis(class_1657 player, class_1268 hand) {
        if (!player.method_5715()) {
            this.method_60964(player, true);

            if (!player.method_31549().field_7477) {
                player.method_5998(hand).method_7934(1);
            }
        } else {
            this.method_5932();
        }
    }

    public void lockTardisDoor(TardisData data, class_1657 player) {
        if (!data.doorOpen) {
            if (data.doorLocked) {
                data.doorLocked = false;
                player.method_7353(class_2561.method_43470("\uD83D\uDD12").method_27692(class_124.field_1080), true);
            } else {
                data.doorLocked = true;
                player.method_7353(class_2561.method_43470("\uD83D\uDD12").method_27692(class_124.field_1080), true);
            }
            playSoundAtTardis(class_3417.field_23199, 0.5f);
        }
    }

    public void tardisDoor(TardisData data, class_1657 player) {
        if (!data.doorLocked) {

            player.method_7281(TARDIFPlayerStatistics.INTERACT_WITH_TARDIS);

            if (data.doorOpen) {

                data.doorOpen = false;
                playAnimation(TardisAnimation.DOOR_CLOSE);
                this.doorRightCloseAnimationState.method_41322(this.field_6012);
                this.doorLeftCloseAnimationState.method_41322(this.field_6012);
            } else {
                data.doorOpen = true;
                playAnimation(TardisAnimation.DOOR_OPEN);
                this.doorRightOpenAnimationState.method_41322(this.field_6012);
                this.doorLeftOpenAnimationState.method_41322(this.field_6012);
            }
            this.method_18382();
        } else {

            player.method_7353(class_2561.method_43470("The door is locked...").method_27692(class_124.field_1080), true);
            playSoundAtTardis(class_3417.field_14562, 0.5f);

        }
    }

    public void forceLoadChunk() {
        if (method_73183() instanceof class_3218 world) {
            class_1923 current = new class_1923(method_24515());

            if (!current.equals(forcedChunk)) {
                if (forcedChunk != null) {
                    world.method_17988(forcedChunk.field_9181, forcedChunk.field_9180, false);
                }

                world.method_17988(current.field_9181, current.field_9180, true);
                forcedChunk = current;
            }
        }
    }

    public void initTardis() {
        if (this.field_6011.method_12789(TARDIS_INITIALISED)) return;

        class_3218 serverWorld = (class_3218) method_73183();

        try {
            initializeTardis(serverWorld);
            this.field_6011.method_12778(TARDIS_INITIALISED, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private TardisPartEntity leftArm;
    private TardisPartEntity rightArm;

    private void initParts() {
        if (this.method_73183().method_8608()) return;

        leftArm = TARDIFEntities.TARDIS_PART.method_5883(this.method_73183(), class_3730.field_16461);
        rightArm = TARDIFEntities.TARDIS_PART.method_5883(this.method_73183(), class_3730.field_16461);

        if (leftArm != null) {
            leftArm.setParent(this);
            leftArm.method_5808(
                    this.method_23317() - 1.0,
                    this.method_23318(),
                    this.method_23321(),
                    this.method_36454(),
                    this.method_36455()
            );
            this.method_73183().method_8649(leftArm);
        }

        if (rightArm != null) {
            rightArm.setParent(this);
            rightArm.method_5808(
                    this.method_23317() + 1.0,
                    this.method_23318(),
                    this.method_23321(),
                    this.method_36454(),
                    this.method_36455()
            );
            this.method_73183().method_8649(rightArm);
        }
    }

    public void initializeTardis(class_3218 exteriorWorld) throws IOException {
        MinecraftServer server = exteriorWorld.method_8503();
        TardisData data = new TardisData();

        data.owner =  UUID.randomUUID();

        data.doorOpen = false;
        data.doorLocked = false;
        data.powered = true;
        data.emergencyMode = false;
        data.roundelLight = 10;

        data.exteriorPos = method_73189();
        data.exteriorDimension = exteriorWorld.method_27983().method_29177();
        data.exteriorYaw = 0f;


        class_3218 tardisWorld = server.method_3847(TARDIFDimensions.TARDIS_WORLD);
        class_2338 interiorOrigin = TardisInteriorUtil.allocate(server);

        data.interiorOrigin = interiorOrigin;
        data.interiorPos = class_243.method_24954(class_2338.method_49637(data.interiorOrigin.method_10263() + 0.5, data.interiorOrigin.method_10264() + 1, data.interiorOrigin.method_10260() + 3.5));
        data.interiorYaw = 0f;
        data.interiorDimension = tardisWorld.method_27983().method_29177();

        data.previousPos = method_73189();
        data.setPos = method_73189();

        data.dematerialised = false;

        int id = TardisManager.createTardis(server, data);

        setTardisId(id);

        TardisInteriorUtil.generate(tardisWorld, interiorOrigin, data);

    }
}
