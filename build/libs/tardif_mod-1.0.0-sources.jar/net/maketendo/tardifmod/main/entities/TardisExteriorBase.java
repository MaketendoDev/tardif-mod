package net.maketendo.tardifmod.main.entities;

import net.maketendo.tardifmod.main.TARDIFItems;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_9817;
import org.jspecify.annotations.Nullable;

public abstract class TardisExteriorBase extends ObjectEntity implements class_9817 {

    private class_9817.@Nullable class_9818 leashData;

    public TardisExteriorBase(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    public class_9817.@Nullable class_9818 method_60955() {
        return this.leashData;
    }

    @Override
    public class_243 method_52538(class_1297 passenger) {
        class_243 forward = class_243.method_1030(0, this.method_36454()).method_1029();

        return this.method_73189()
                .method_1031(0, this.method_17682() - 0.1, 0)
                .method_1019(forward.method_1021(0.4));
    }

    public void method_60960(class_9817.@Nullable class_9818 leashData) {
        this.leashData = leashData;
    }

    public class_243 method_29919() {
        return new class_243(0.0F, (0.88F * this.method_17682()), (0.64F * this.method_17681()));
    }

    public boolean method_70991() {
        return true;
    }

    public class_243[] method_70992() {
        return class_9817.method_70993(this, 0.0F, 0.64, 0.382, 0.88);
    }

    @Override
    public @Nullable class_1799 method_31480() {
        return TARDIFItems.TARDIS_ITEM.method_7854();
    }

    // Helper Methods
    public void playSoundAtTardis(class_3414 soundEvent, Float volume) {
        method_73183().method_43128(
                null,
                method_23317(), method_23318(), method_23321(),
                soundEvent,
                class_3419.field_15254,
                volume,
                1.0f
        );
    }
}

