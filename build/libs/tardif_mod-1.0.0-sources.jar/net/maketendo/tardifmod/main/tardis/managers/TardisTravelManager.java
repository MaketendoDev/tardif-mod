package net.maketendo.tardifmod.main.tardis.managers;

import net.maketendo.tardifmod.client.packets.TardisAnimPackets;
import net.maketendo.tardifmod.main.TARDIFDimensions;
import net.maketendo.tardifmod.main.TARDIFEntities;
import net.maketendo.tardifmod.main.TARDIFSounds;
import net.maketendo.tardifmod.main.entities.tardis.TardisEntity;
import net.maketendo.tardifmod.main.tardis.TardisData;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;

public class TardisTravelManager {
    public static void dematTardis(TardisData data, class_1297 entity, MinecraftServer server) {
        data.dematerialised = true;

        class_3218 intWorld = server.method_3847(TARDIFDimensions.TARDIS_WORLD);
        if (intWorld == null) return;

        intWorld.method_43128(
                null,
                data.interiorOrigin.method_10263(),
                data.interiorOrigin.method_10264(),
                data.interiorOrigin.method_10260(),
                TARDIFSounds.DEMATERIALISATION,
                class_3419.field_15245,
                10.0f,
                1.0f
        );

        class_3218 extWorld = server.method_3847(TARDIFDimensions.TARDIS_WORLD);
        if (extWorld == null) return;

        extWorld.method_43128(
                null,
                data.exteriorPos.method_10216(),
                data.exteriorPos.method_10214(),
                data.exteriorPos.method_10215(),
                TARDIFSounds.DEMATERIALISATION,
                class_3419.field_15245,
                5.0f,
                1.0f
        );

        TardisAnimPackets.send(extWorld, entity, 0);

    }

    public static void rematTardis(TardisData data, class_1297 entity, MinecraftServer server) {
        data.dematerialised = false;

        class_3218 intWorld = server.method_3847(TARDIFDimensions.TARDIS_WORLD);
        if (intWorld != null) {
            intWorld.method_8396(
                    null,
                    data.interiorOrigin,
                    TARDIFSounds.MATERIALISATION,
                    class_3419.field_15245,
                    10.0f,
                    1.0f
            );
        }

        class_3218 extWorld = server.method_3847(TARDIFDimensions.TARDIS_WORLD);
        if (extWorld != null) {
            extWorld.method_43128(
                    null,
                    data.exteriorPos.method_10216(),
                    data.exteriorPos.method_10214(),
                    data.exteriorPos.method_10215(),
                    TARDIFSounds.MATERIALISATION,
                    class_3419.field_15245,
                    5.0f,
                    1.0f
            );

            class_3218 landingWorld = server.method_3847(class_5321.method_29179(class_7924.field_41223, data.exteriorDimension));
            if (landingWorld != null) {

                landingWorld.method_17988((int) data.setPos.method_10216(), (int) data.setPos.method_10214(), true);

                class_1297 rematTardis = TARDIFEntities.TARDIS.method_47821(
                        landingWorld,
                        class_2338.method_49638(data.exteriorPos),
                        class_3730.field_16461
                );

                if (rematTardis instanceof TardisEntity tardis) {
                    tardis.preInitialised();
                    tardis.setTardisId(data.id);

                    data.exteriorPos = new class_243(
                            data.setPos.method_10216() + 0.5,
                            data.setPos.method_10214(),
                            data.setPos.method_10215() + 0.5
                    );

                    tardis.method_23327(
                            data.setPos.method_10216() + 0.5,
                            data.setPos.method_10214(),
                            data.setPos.method_10215() + 0.5
                    );

                    extWorld.method_8649(tardis);
                }
            }

        }
    }

}