package net.maketendo.tardifmod.main;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.maketendo.tardifmod.TARDIFMod;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class TARDIFItemGroups {
    public static final class_1761 ITEMS = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_60655(TARDIFMod.MOD_ID, "items"),
            FabricItemGroup.builder().method_47320(() -> new class_1799(TARDIFItems.TARDIS_ITEM))
                    .method_47321(class_2561.method_43471("itemgroup.tardif_mod.items"))
                    .method_47317((displayContext, entries) -> {

                        entries.method_45421(TARDIFItems.TARDIS_ITEM);

                        entries.method_45421(TARDIFItems.SILVER_TARDIS_KEY);
                        entries.method_45421(TARDIFItems.GOLD_TARDIS_KEY);

                        entries.method_45421(TARDIFItems.SONIC_SCREWDRIVER);

                        //entries.add(TARDIFBlocks.POWER_PANEL);
                        //entries.add(TARDIFBlocks.COORDINATES_PANEL);
                        //entries.add(TARDIFBlocks.DEMATERIALISATION_PANEL);

                        entries.method_45421(TARDIFBlocks.TARDIS_CONSOLE_BLOCK);

                    }).method_47324());

    public static final class_1761 DECORATION = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_60655(TARDIFMod.MOD_ID, "decoration"),
            FabricItemGroup.builder().method_47320(() -> new class_1799(TARDIFBlocks.WHITE_ROUNDEL_HALF.method_8389()))
                    .method_47321(class_2561.method_43471("itemgroup.tardif_mod.decoration"))
                    .method_47317((displayContext, entries) -> {

                        entries.method_45421(TARDIFBlocks.HALF_CHISELED_QUARTZ);

                        entries.method_45421(TARDIFBlocks.REDSTONE_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.REDSTONE_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.WHITE_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.WHITE_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.GRAY_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.GRAY_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.DARK_GRAY_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.DARK_GRAY_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.BLACK_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.BLACK_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.BROWN_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.BROWN_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.RED_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.RED_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.ORANGE_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.ORANGE_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.YELLOW_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.YELLOW_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.LIME_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.LIME_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.GREEN_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.GREEN_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.CYAN_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.CYAN_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.LIGHT_BLUE_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.LIGHT_BLUE_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.BLUE_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.BLUE_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.PURPLE_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.PURPLE_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.MAGENTA_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.MAGENTA_ROUNDEL_HALF);
                        entries.method_45421(TARDIFBlocks.PINK_ROUNDEL);
                        entries.method_45421(TARDIFBlocks.PINK_ROUNDEL_HALF);

                        entries.method_45421(TARDIFBlocks.GRAY_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.BLACK_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.BROWN_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.RED_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.ORANGE_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.YELLOW_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.LIME_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.GREEN_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.CYAN_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.BLUE_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.PURPLE_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.MAGENTA_STAINED_QUARTZ);
                        entries.method_45421(TARDIFBlocks.PINK_STAINED_QUARTZ);

                        entries.method_45421(TARDIFBlocks.GRAY_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.BLACK_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.BROWN_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.RED_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.ORANGE_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.YELLOW_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.LIME_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.GREEN_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.CYAN_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.BLUE_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.PURPLE_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.MAGENTA_STAINED_QUARTZ_SLAB);
                        entries.method_45421(TARDIFBlocks.PINK_STAINED_QUARTZ_SLAB);

                        entries.method_45421(TARDIFBlocks.GRAY_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.DARK_GRAY_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.BLACK_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.BROWN_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.RED_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.ORANGE_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.YELLOW_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.LIME_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.GREEN_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.CYAN_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.BLUE_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.PURPLE_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.MAGENTA_STAINED_QUARTZ_STAIRS);
                        entries.method_45421(TARDIFBlocks.PINK_STAINED_QUARTZ_STAIRS);

                        entries.method_45421(TARDIFBlocks.CRYSTALLINE_BLOCK);
                        entries.method_45421(TARDIFBlocks.CRYSTALLINE_SLAB);
                        entries.method_45421(TARDIFBlocks.CRYSTALLINE_STAIR);

                    }).method_47324());


    public static void register() {}

}
