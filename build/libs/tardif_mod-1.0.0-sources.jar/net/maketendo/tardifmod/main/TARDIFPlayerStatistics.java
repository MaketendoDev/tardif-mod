package net.maketendo.tardifmod.main;

import net.maketendo.tardifmod.TARDIFMod;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3446;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

public class TARDIFPlayerStatistics {

    public static final class_2960 INTERACT_WITH_TARDIS = registerStatistic("interact_with_tardis");
    public static final class_2960 LOCKED_TARDIS = registerStatistic("locked_tardis");
    public static final class_2960 DEMAT_TARDIS = registerStatistic("demat_tardis");

    public static void register() {
        class_3468.field_15419.method_14955(INTERACT_WITH_TARDIS, class_3446.field_16975);
        class_3468.field_15419.method_14955(LOCKED_TARDIS, class_3446.field_16975);
        class_3468.field_15419.method_14955(DEMAT_TARDIS, class_3446.field_16975);
    }

    private static class_2960 registerStatistic(String id) {
        class_2960 identifier = class_2960.method_60655(TARDIFMod.MOD_ID, id);
        class_2378.method_10226(class_7923.field_41183, id, identifier);
        return identifier;
    }
}
