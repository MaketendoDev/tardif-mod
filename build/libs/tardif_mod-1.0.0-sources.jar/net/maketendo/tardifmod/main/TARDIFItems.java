package net.maketendo.tardifmod.main;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.main.items.TardisItem;
import net.maketendo.tardifmod.main.items.TardisKeyItem;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8055;
import java.util.function.Function;

public class TARDIFItems {

    public static final class_1792 TARDIS_ITEM = registerItem("tardis_item",
            setting -> new TardisItem(setting.method_24359().method_7889(1)));

    public static final class_1792 SONIC_SCREWDRIVER = registerItem("sonic_screwdriver",
            setting -> new class_1792(setting.method_24359().method_7889(1)));

    public static final class_1792 SILVER_TARDIS_KEY = registerItem("silver_tardis_key",
            setting -> new TardisKeyItem(setting.method_24359().method_7889(1).method_7894(class_1814.field_8906), "Silver"));

    public static final class_1792 GOLD_TARDIS_KEY = registerItem("gold_tardis_key",
            setting -> new TardisKeyItem(setting.method_24359().method_7889(1).method_7894(class_1814.field_8906), "Gold"));

    // Materials

    public static final class_1792 CRYSTALLINE_SHARD = registerItem("crystalline_shard",
            setting -> new class_1792(setting.method_67189(class_8055.field_55049).method_7894(class_1814.field_8906)));

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> function) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TARDIFMod.MOD_ID, name),
                function.apply(new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(TARDIFMod.MOD_ID, name)))));
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(SILVER_TARDIS_KEY);
            entries.method_45421(GOLD_TARDIS_KEY);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries -> {
            entries.method_45421(CRYSTALLINE_SHARD);
        });
    }
}
