package net.maketendo.tardifmod.main.commands;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.maketendo.tardifmod.main.entities.tardis.TardisEntity;
import net.maketendo.tardifmod.main.tardis.TardisData;
import net.maketendo.tardifmod.main.tardis.TardisManager;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_5242;
import java.util.UUID;

public class TardifCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    class_2170.method_9247("tardif")
                            .then(class_2170.method_9247("data")
                                    .then(class_2170.method_9247("getFromId")
                                            .then(class_2170.method_9244("uuid", class_5242.method_27643())
                                                    .executes(ctx -> getData(ctx.getSource(),
                                                            class_5242.method_27645(ctx, "uuid")))
                                            )
                                    )
                            )
            );
        });
    }

    private static int getData(class_2168 source, UUID uuid) {
        try {
            var world = source.method_9225();

            var entity = world.method_66347(uuid);
            if (!(entity instanceof TardisEntity tardis)) {
                source.method_9213(class_2561.method_43470("That entity is not a TARDIS Linked Entity.")
                        .method_27692(class_124.field_1061));
                return 0;
            }

            int tardisId = tardis.getTardisId();
            if (tardisId == -1) {
                source.method_9213(class_2561.method_43470("TARDIS has no ID.")
                        .method_27692(class_124.field_1061));
                return 0;
            }

            TardisData data = TardisManager.getFromId(source.method_9211(), tardisId);
            if (data == null) {
                source.method_9213(class_2561.method_43470("No data found for TARDIS ID " + tardisId)
                        .method_27692(class_124.field_1061));
                return 0;
            }

            JsonObject json = data.toJson();
            String pretty = new GsonBuilder()
                    .setPrettyPrinting()
                    .create()
                    .toJson(json);

            source.method_9226(() ->
                            class_2561.method_43470("TARDIS DATA (id=" + tardisId + ")\n")
                                    .method_27692(class_124.field_1065)
                                    .method_10852(class_2561.method_43470(pretty).method_27692(class_124.field_1080)),
                    false
            );

            return 1;

        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("Error reading TARDIS data.")
                    .method_27692(class_124.field_1061));
            e.printStackTrace();
            return 0;
        }
    }
}

