package net.maketendo.tardifmod.main;

import net.maketendo.tardifmod.TARDIFMod;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;
import java.util.List;

public class TARDIFSounds {

    public static final class_3414 DEMATERIALISATION = registerSound("tardis/tardis_demat");
    public static final class_3414 MATERIALISATION = registerSound("tardis/tardis_mat");
    public static final class_3414 FLIGHT_LOOP = registerSound("tardis/flight_loop");
    public static final class_3414 ADVANCEMENT_EARN = registerSound("ui/advancement_earn");

    public static void register() {
    }

    private static class_3414 registerSound(String id) {
        class_2960 identifier = class_2960.method_60655(TARDIFMod.MOD_ID, id);
        return class_2378.method_10230(class_7923.field_41172, identifier, class_3414.method_47908(identifier));
    }

    public static List<class_3414> getSounds(String modid) {
        return class_7923.field_41172.method_10220().filter(sound -> sound.comp_3319().method_12836().equals(modid)).toList();
    }
}