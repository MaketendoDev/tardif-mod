package net.maketendo.tardifmod.main.blocks;

import com.mojang.serialization.MapCodec;
import net.maketendo.tardifmod.main.TARDIFBlockEntities;
import net.maketendo.tardifmod.main.blockentities.RoundelBlockEntity;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;

public class RoundelBlock extends class_2237 {

    public static final class_2758 LIGHT = class_2758.method_11867("light", 0, 15);
    public static final class_2754<class_2350> FACING = class_2741.field_12481;


    public RoundelBlock(class_2251 settings) {
        super(settings.method_9631(state -> state.method_11654(LIGHT)));
        this.method_9590(
                this.field_10647.method_11664()
                        .method_11657(LIGHT, 0)
                        .method_11657(FACING, class_2350.field_11043)
        );
    }


    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(
            class_1937 world, class_2680 state, class_2591<T> type) {

        if (type == TARDIFBlockEntities.ROUNDELS) {
            return (world1, pos, state1, be) ->
                    RoundelBlockEntity.tick(world1, pos, state1, (RoundelBlockEntity) be);
        }
        return null;

    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return RoundelBlock.method_54094(RoundelBlock::new);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new RoundelBlockEntity(pos, state);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(LIGHT, FACING);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564()
                .method_11657(FACING, ctx.method_8042().method_10153());
    }

}

