package net.maketendo.tardifmod.main.blocks;

import com.mojang.serialization.MapCodec;
import net.maketendo.tardifmod.main.TARDIFBlockEntities;
import net.maketendo.tardifmod.main.blockentities.RoundelBlockEntity;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import org.jetbrains.annotations.Nullable;

public class InteriorDoorGenBlock extends class_2248 {

    public static final class_2754<class_2350> FACING = class_2741.field_12481;

    public InteriorDoorGenBlock(class_2251 settings) {
        super(settings);
        this.method_9590(
                this.field_10647.method_11664()
                        .method_11657(FACING, class_2350.field_11043)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564()
                .method_11657(FACING, ctx.method_8042().method_10153());
    }
}

