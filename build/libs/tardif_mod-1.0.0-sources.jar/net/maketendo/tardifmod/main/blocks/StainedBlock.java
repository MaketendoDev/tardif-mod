package net.maketendo.tardifmod.main.blocks;

import net.maketendo.tardifmod.main.TARDIFTags;
import net.maketendo.tardifmod.utils.StainedQuartzRegistry;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

public class StainedBlock extends class_2248 {

    public StainedBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {

        if (world.method_8608()) {
            return class_1269.field_5811;
        }

        if (player.method_6079().method_31573(TARDIFTags.Items.PAINT_BRUSH)) {
            class_2248 replacement = StainedQuartzRegistry.getFromDye(stack);
            if (replacement == null) {
                return class_1269.field_5811;
            }

            world.method_8501(pos, replacement.method_9564());
            world.method_8396(null, pos, class_3417.field_29543, class_3419.field_15245, 0.5f, 1f);

            if (!player.method_68878()) {
                stack.method_7934(1);
            }

            return class_1269.field_21466;
        }

        return class_1269.field_5811;
    }
}
