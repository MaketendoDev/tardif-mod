package net.maketendo.tardifmod.main.blocks;

import com.mojang.serialization.MapCodec;
import net.maketendo.tardifmod.main.TARDIFBlockEntities;
import net.maketendo.tardifmod.main.blockentities.RoundelBlockEntity;
import net.maketendo.tardifmod.main.blockentities.TardisConsoleBlockEntity;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import org.jetbrains.annotations.Nullable;

public class TardisConsoleBlock extends class_2237 {

    public static final class_2758 LIGHT = class_2758.method_11867("light", 0, 15);

    public TardisConsoleBlock(class_2251 settings) {
        super(settings.method_9631(state -> state.method_11654(LIGHT)));
        this.method_9590(
                this.field_10647.method_11664()
                        .method_11657(LIGHT, 0)
        );
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return TardisConsoleBlock.method_54094(TardisConsoleBlock::new);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new TardisConsoleBlockEntity(pos, state);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(LIGHT);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11455;
    }
}

