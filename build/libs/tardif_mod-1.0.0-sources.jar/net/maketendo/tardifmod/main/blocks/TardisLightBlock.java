package net.maketendo.tardifmod.main.blocks;

import com.mojang.serialization.MapCodec;
import java.util.function.ToIntFunction;

import net.maketendo.tardifmod.main.TARDIFBlockEntities;
import net.maketendo.tardifmod.main.TARDIFBlocks;
import net.maketendo.tardifmod.main.blockentities.TardisLightBlockEntity;
import net.minecraft.class_10225;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.class_9275;
import net.minecraft.class_9334;
import org.jspecify.annotations.Nullable;

public class TardisLightBlock extends class_2237 implements class_3737 {
    public static final MapCodec<TardisLightBlock> CODEC = method_54094(TardisLightBlock::new);
    public static final class_2758 LEVEL = class_2758.method_11867("level", 0, 15);
    public static final class_2746 WATERLOGGED;
    public static final ToIntFunction<class_2680> STATE_TO_LUMINANCE;

    public MapCodec<TardisLightBlock> method_53969() {
        return field_46280;
    }

    public TardisLightBlock(class_4970.class_2251 settings) {
        super(settings);
        this.method_9590((class_2680)((class_2680)((class_2680)this.field_10647.method_11664()).method_11657(LEVEL, 2)).method_11657(WATERLOGGED, false));
    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{LEVEL, WATERLOGGED});
    }

    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.method_8608() && player.method_7338()) {
            world.method_8652(pos, state.method_28493(LEVEL), 2);
            return class_1269.field_52422;
        } else {
            return class_1269.field_21466;
        }
    }

    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return context.method_17785(class_1792.method_7867(TARDIFBlocks.TARDIS_LIGHT_BLOCK)) ? class_259.method_1077() : class_259.method_1073();
    }

    protected boolean method_9579(class_2680 state) {
        return state.method_26227().method_15769();
    }

    protected float method_9575(class_2680 state, class_1922 world, class_2338 pos) {
        return 1.0F;
    }

    protected class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView, class_2338 pos, class_2350 direction, class_2338 neighborPos, class_2680 neighborState, class_5819 random) {
        if (state.method_11654(WATERLOGGED)) {
            tickView.method_64312(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        }

        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    protected class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    protected class_1799 method_9574(class_4538 world, class_2338 pos, class_2680 state, boolean includeData) {
        return addNbtForLevel(super.method_9574(world, pos, state, includeData), (Integer)state.method_11654(LEVEL));
    }

    public static class_1799 addNbtForLevel(class_1799 stack, int level) {
        stack.method_57379(class_9334.field_49623, class_9275.field_49284.method_57420(LEVEL, level));
        return stack;
    }

    static {
        WATERLOGGED = class_2741.field_12508;
        STATE_TO_LUMINANCE = (state) -> (Integer)state.method_11654(LEVEL);
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new TardisLightBlockEntity(pos, state);
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(
            class_1937 world, class_2680 state, class_2591<T> type) {

        if (type == TARDIFBlockEntities.TARDIS_LIGHT_BLOCK) {
            return (world1, pos, state1, be) ->
                    TardisLightBlockEntity.tick(world1, pos, state1, (TardisLightBlockEntity) be);
        }
        return null;

    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11455;
    }
}

