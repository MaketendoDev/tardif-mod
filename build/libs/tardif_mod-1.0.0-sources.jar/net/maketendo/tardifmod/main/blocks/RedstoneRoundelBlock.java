package net.maketendo.tardifmod.main.blocks;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2459;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import net.minecraft.class_9904;
import org.jspecify.annotations.Nullable;

public class RedstoneRoundelBlock extends class_2248 {
    public static final MapCodec<RedstoneRoundelBlock> CODEC = method_54094(RedstoneRoundelBlock::new);
    public static final class_2746 LIT;

    public MapCodec<RedstoneRoundelBlock> method_53969() {
        return field_46280;
    }

    public RedstoneRoundelBlock(class_4970.class_2251 properties) {
        super(properties);
        this.method_9590((class_2680)this.method_9564().method_11657(LIT, false));
    }

    public @Nullable class_2680 method_9605(class_1750 blockPlaceContext) {
        return (class_2680)this.method_9564().method_11657(LIT, blockPlaceContext.method_8045().method_49803(blockPlaceContext.method_8037()));
    }

    protected void method_9612(class_2680 blockState, class_1937 level, class_2338 blockPos, class_2248 block, @Nullable class_9904 orientation, boolean bl) {
        if (!level.method_8608()) {
            boolean bl2 = (Boolean)blockState.method_11654(LIT);
            if (bl2 != level.method_49803(blockPos)) {
                if (bl2) {
                    level.method_64310(blockPos, this, 4);
                } else {
                    level.method_8652(blockPos, (class_2680)blockState.method_28493(LIT), 2);
                }
            }

        }
    }

    protected void method_9588(class_2680 blockState, class_3218 serverLevel, class_2338 blockPos, class_5819 randomSource) {
        if ((Boolean)blockState.method_11654(LIT) && !serverLevel.method_49803(blockPos)) {
            serverLevel.method_8652(blockPos, (class_2680)blockState.method_28493(LIT), 2);
        }

    }

    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(new class_2769[]{LIT});
    }

    static {
        LIT = class_2459.field_11446;
    }
}
