package net.maketendo.tardifmod.main;

import net.maketendo.tardifmod.TARDIFMod;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class TARDIFTags {
    public static class Blocks {
        public static final class_6862<class_2248> ROUNDELS = createTag("roundels");
        public static final class_6862<class_2248> STAINED_QUARTZ = createTag("stained_quartz");

        private static class_6862<class_2248> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(TARDIFMod.MOD_ID, name));
        }
    }

    public static class Items {
        public static final class_6862<class_1792> TARDIS_KEYS = createTag("tardis_keys");
        public static final class_6862<class_1792> LINKABLE_ITEMS = createTag("linkable_items");
        public static final class_6862<class_1792> PAINT_BRUSH = createTag("paint_brush");

        private static class_6862<class_1792> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(TARDIFMod.MOD_ID, name));
        }
    }
}
