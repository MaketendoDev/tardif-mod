package net.maketendo.tardifmod.main;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.main.blocks.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2465;
import net.minecraft.class_2482;
import net.minecraft.class_2510;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.world.level.block.*;
import java.util.function.Function;
import java.util.function.ToIntFunction;

public class TARDIFBlocks {

    public static final class_2248 HALF_CHISELED_QUARTZ = registerBlock("half_chiseled_quartz",
            properties -> new class_2465(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));

    public static final class_2248 REDSTONE_ROUNDEL = registerBlock("redstone_roundel",
            properties -> new RedstoneRoundelBlock(properties.method_31710(class_3620.field_16025).method_9631(litBlockEmission(15)).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));

    public static final class_2248 REDSTONE_ROUNDEL_HALF = registerBlock("redstone_roundel_half",
            properties -> new RedstoneRoundelBlock(properties.method_31710(class_3620.field_16025).method_9631(litBlockEmission(15)).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));

    public static final class_2248 WHITE_ROUNDEL = registerBlock("white_roundel",
            properties -> new RoundelBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));

    public static final class_2248 WHITE_ROUNDEL_HALF = registerBlock("white_roundel_half",
            properties -> new RoundelBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));

    public static final class_2248 GRAY_ROUNDEL = registerBlock("gray_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16025)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 GRAY_ROUNDEL_HALF = registerBlock("gray_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16025)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 DARK_GRAY_ROUNDEL = registerBlock("dark_gray_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16025)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 DARK_GRAY_ROUNDEL_HALF = registerBlock("dark_gray_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16025)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 BLACK_ROUNDEL = registerBlock("black_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16009)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 BLACK_ROUNDEL_HALF = registerBlock("black_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16009)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 BROWN_ROUNDEL = registerBlock("brown_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15977)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 BROWN_ROUNDEL_HALF = registerBlock("brown_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15977)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 RED_ROUNDEL = registerBlock("red_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16020)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 RED_ROUNDEL_HALF = registerBlock("red_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16020)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 ORANGE_ROUNDEL = registerBlock("orange_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15987)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 ORANGE_ROUNDEL_HALF = registerBlock("orange_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15987)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 YELLOW_ROUNDEL = registerBlock("yellow_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16010)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 YELLOW_ROUNDEL_HALF = registerBlock("yellow_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16010)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 LIME_ROUNDEL = registerBlock("lime_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15997)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 LIME_ROUNDEL_HALF = registerBlock("lime_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15997)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 GREEN_ROUNDEL = registerBlock("green_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15995)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 GREEN_ROUNDEL_HALF = registerBlock("green_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15995)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 CYAN_ROUNDEL = registerBlock("cyan_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16026)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 CYAN_ROUNDEL_HALF = registerBlock("cyan_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16026)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 LIGHT_BLUE_ROUNDEL = registerBlock("light_blue_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16024)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 LIGHT_BLUE_ROUNDEL_HALF = registerBlock("light_blue_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16024)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 BLUE_ROUNDEL = registerBlock("blue_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15984)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 BLUE_ROUNDEL_HALF = registerBlock("blue_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15984)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 PURPLE_ROUNDEL = registerBlock("purple_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16014)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 PURPLE_ROUNDEL_HALF = registerBlock("purple_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16014)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 MAGENTA_ROUNDEL = registerBlock("magenta_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15998)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 MAGENTA_ROUNDEL_HALF = registerBlock("magenta_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_15998)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 PINK_ROUNDEL = registerBlock("pink_roundel",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16030)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));

    public static final class_2248 PINK_ROUNDEL_HALF = registerBlock("pink_roundel_half",
            props -> createRoundelBlock(props.method_31710(class_3620.field_16030)
                    .method_51368(class_2766.field_12653)
                    .method_29292()
                    .method_9632(0.8F)));


    public static final class_2248 GRAY_STAINED_QUARTZ = registerBlock("gray_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 DARK_GRAY_STAINED_QUARTZ = registerBlock("dark_gray_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 BLACK_STAINED_QUARTZ = registerBlock("black_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 BROWN_STAINED_QUARTZ = registerBlock("brown_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 RED_STAINED_QUARTZ = registerBlock("red_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 ORANGE_STAINED_QUARTZ = registerBlock("orange_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 YELLOW_STAINED_QUARTZ = registerBlock("yellow_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 LIME_STAINED_QUARTZ = registerBlock("lime_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 GREEN_STAINED_QUARTZ = registerBlock("green_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 CYAN_STAINED_QUARTZ = registerBlock("cyan_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 LIGHT_BLUE_STAINED_QUARTZ = registerBlock("light_blue_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 BLUE_STAINED_QUARTZ = registerBlock("blue_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 PURPLE_STAINED_QUARTZ = registerBlock("purple_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 MAGENTA_STAINED_QUARTZ = registerBlock("magenta_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 PINK_STAINED_QUARTZ = registerBlock("pink_stained_quartz",
            properties -> new StainedBlock(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));

    // Kill me.
    public static final class_2248 GRAY_STAINED_QUARTZ_SLAB = registerBlock("gray_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 DARK_GRAY_STAINED_QUARTZ_SLAB = registerBlock("dark_gray_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 BLACK_STAINED_QUARTZ_SLAB = registerBlock("black_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 BROWN_STAINED_QUARTZ_SLAB = registerBlock("brown_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 RED_STAINED_QUARTZ_SLAB = registerBlock("red_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 ORANGE_STAINED_QUARTZ_SLAB = registerBlock("orange_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 YELLOW_STAINED_QUARTZ_SLAB = registerBlock("yellow_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 LIME_STAINED_QUARTZ_SLAB = registerBlock("lime_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 GREEN_STAINED_QUARTZ_SLAB = registerBlock("green_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 CYAN_STAINED_QUARTZ_SLAB = registerBlock("cyan_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 LIGHT_BLUE_STAINED_QUARTZ_SLAB = registerBlock("light_blue_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 BLUE_STAINED_QUARTZ_SLAB = registerBlock("blue_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 PURPLE_STAINED_QUARTZ_SLAB = registerBlock("purple_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 MAGENTA_STAINED_QUARTZ_SLAB = registerBlock("magenta_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 PINK_STAINED_QUARTZ_SLAB = registerBlock("pink_stained_quartz_slab",
            properties -> new class_2482(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));

    public static final class_2248 GRAY_STAINED_QUARTZ_STAIRS = registerBlock("gray_stained_quartz_stairs",
            properties -> new class_2510(GRAY_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 DARK_GRAY_STAINED_QUARTZ_STAIRS = registerBlock("dark_gray_stained_quartz_stairs",
            properties -> new class_2510(DARK_GRAY_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 BLACK_STAINED_QUARTZ_STAIRS = registerBlock("black_stained_quartz_stairs",
            properties -> new class_2510(BLACK_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 BROWN_STAINED_QUARTZ_STAIRS = registerBlock("brown_stained_quartz_stairs",
            properties -> new class_2510(BROWN_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 RED_STAINED_QUARTZ_STAIRS = registerBlock("red_stained_quartz_stairs",
            properties -> new class_2510(RED_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 ORANGE_STAINED_QUARTZ_STAIRS = registerBlock("orange_stained_quartz_stairs",
            properties -> new class_2510(ORANGE_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 YELLOW_STAINED_QUARTZ_STAIRS = registerBlock("yellow_stained_quartz_stairs",
            properties -> new class_2510(YELLOW_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 LIME_STAINED_QUARTZ_STAIRS = registerBlock("lime_stained_quartz_stairs",
            properties -> new class_2510(LIME_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 GREEN_STAINED_QUARTZ_STAIRS = registerBlock("green_stained_quartz_stairs",
            properties -> new class_2510(GREEN_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 CYAN_STAINED_QUARTZ_STAIRS = registerBlock("cyan_stained_quartz_stairs",
            properties -> new class_2510(CYAN_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 LIGHT_BLUE_STAINED_QUARTZ_STAIRS = registerBlock("light_blue_stained_quartz_stairs",
            properties -> new class_2510(LIGHT_BLUE_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 BLUE_STAINED_QUARTZ_STAIRS = registerBlock("blue_stained_quartz_stairs",
            properties -> new class_2510(BLUE_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 PURPLE_STAINED_QUARTZ_STAIRS = registerBlock("purple_stained_quartz_stairs",
            properties -> new class_2510(PURPLE_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 MAGENTA_STAINED_QUARTZ_STAIRS = registerBlock("magenta_stained_quartz_stairs",
            properties -> new class_2510(MAGENTA_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 PINK_STAINED_QUARTZ_STAIRS = registerBlock("pink_stained_quartz_stairs",
            properties -> new class_2510(PINK_STAINED_QUARTZ.method_9564(), properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));

    public static final class_2248 CRYSTALLINE_BLOCK = registerBlock("crystalline_block",
            properties -> new class_2248(properties.method_31710(class_3620.field_16025).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F).method_26247(class_2246::method_26113).method_26249(class_2246::method_26113).method_9631((blockStatex) -> 10)));
    public static final class_2248 CRYSTALLINE_SLAB = registerBlock("crystalline_slab",
            properties -> new class_2482(properties.method_22488().method_9632(0.6F).method_26247(class_2246::method_26113).method_26249(class_2246::method_26113).method_9631((blockStatex) -> 10)));
    public static final class_2248 CRYSTALLINE_STAIR = registerBlock("crystalline_stair",
            properties -> new class_2510(CRYSTALLINE_BLOCK.method_9564(), properties.method_22488().method_9632(0.6F).method_26247(class_2246::method_26113).method_26249(class_2246::method_26113).method_9631((blockStatex) -> 10)));

    public static final class_2248 TARDIS_CONSOLE_BLOCK = registerBlock("tardis_console_block",
            properties -> new TardisConsoleBlock(properties.method_22488().method_9632(0.6F)));
    public static final class_2248 TARDIS_MONITOR = registerBlock("tardis_monitor",
            properties -> new class_2248(properties.method_22488().method_9632(0.6F)));
    public static final class_2248 INTERIOR_DOOR_GENERATOR_BLOCK = registerDevBlock("interior_door_generator_block",
            properties -> new InteriorDoorGenBlock(properties.method_22488().method_9632(0.6F)));
    public static final class_2248 TARDIS_LIGHT_BLOCK = registerDevBlock(
            "tardis_light_block",
            properties -> new TardisLightBlock(
                    properties
                            .method_51371()
                            .method_9629(-1.0F, 3600000.8F)
                            .method_51520(createMapColorFromWaterloggedBlockState(class_3620.field_16008))
                            .method_42327()
                            .method_22488()
                            .method_9631(TardisLightBlock.STATE_TO_LUMINANCE)
            )
    );


    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> function) {
        class_2248 toRegister = function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(TARDIFMod.MOD_ID, name))));
        registerBlockItem(name, toRegister);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TARDIFMod.MOD_ID, name), toRegister);
    }

    private static class_2248 registerDevBlock(String name, Function<class_4970.class_2251, class_2248> function) {
        class_2248 toRegister = function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(TARDIFMod.MOD_ID, name))));
        registerEpicItem(name, toRegister);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TARDIFMod.MOD_ID, name), toRegister);
    }

    private static class_2248 registerBlockWithoutBlockItem(String name, Function<class_4970.class_2251, class_2248> function) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TARDIFMod.MOD_ID, name),
                function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(TARDIFMod.MOD_ID, name)))));
    }

    private static class_2248 createRoundelBlock(class_4970.class_2251 settings) {
        return new RoundelBlock(
                settings.method_9631(state -> state.method_11654(RoundelBlock.LIGHT))
        );
    }

    private static void registerBlockItem(String name, class_2248 block) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TARDIFMod.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(TARDIFMod.MOD_ID, name)))));
    }

    private static void registerEpicItem(String name, class_2248 block) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TARDIFMod.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793().method_63685().method_7894(class_1814.field_8904)
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(TARDIFMod.MOD_ID, name)))));
    }

    private static Function<class_2680, class_3620> createMapColorFromWaterloggedBlockState(class_3620 mapColor) {
        return (state) -> (Boolean)state.method_11654(class_2741.field_12508) ? class_3620.field_16019 : mapColor;
    }

    public static ToIntFunction<class_2680> litBlockEmission(int i) {
        return (blockState) -> (Boolean)blockState.method_11654(class_2741.field_12548) ? i : 0;
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41063).register(entries -> {
            entries.method_45421(INTERIOR_DOOR_GENERATOR_BLOCK);
            entries.method_45421(TARDIS_LIGHT_BLOCK);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register(entries -> {
            entries.method_45421(TARDIFBlocks.CRYSTALLINE_BLOCK);
            entries.method_45421(TARDIFBlocks.CRYSTALLINE_SLAB);
            entries.method_45421(TARDIFBlocks.CRYSTALLINE_STAIR);
        });

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40198).register(entries -> {
            entries.method_45421(TARDIFBlocks.REDSTONE_ROUNDEL);
            entries.method_45421(TARDIFBlocks.REDSTONE_ROUNDEL_HALF);

        });
    }
}
