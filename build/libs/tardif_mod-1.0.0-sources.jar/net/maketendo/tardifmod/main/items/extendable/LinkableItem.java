package net.maketendo.tardifmod.main.items.extendable;

import net.maketendo.tardifmod.main.TARDIFComponents;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import java.util.function.Consumer;

public class LinkableItem extends class_1792 {

    public LinkableItem(class_1793 settings) {
        super(settings);
    }

    public static void setLinkedId(class_1799 stack, int id) {stack.method_57379(TARDIFComponents.LINKED_ID, id);}
    public static boolean hasLinkedId(class_1799 stack) {return stack.method_57826(TARDIFComponents.LINKED_ID);}
    public static int getLinkedId(class_1799 stack) {return stack.method_58695(TARDIFComponents.LINKED_ID, -1);}
    public static void clearLinkedId(class_1799 stack) {stack.method_57381(TARDIFComponents.LINKED_ID);}

    @Override
    public void method_67187(class_1799 stack, class_9635 context,
                              class_10712 displayComponent,
                              Consumer<class_2561> textConsumer, class_1836 type) {

        super.method_67187(stack, context, displayComponent, textConsumer, type);

        if (hasLinkedId(stack)) {

            textConsumer.accept(
                    class_2561.method_43471("tooltip.tardif_mod.linkable_item.id")
                            .method_27692(class_124.field_1080)
            );

            textConsumer.accept(
                    class_2561.method_43470(String.valueOf(getLinkedId(stack)))
                            .method_27692(class_124.field_1078)
            );

        } else {

            textConsumer.accept(
                    class_2561.method_43471("tooltip.tardif_mod.linkable_item.1")
                            .method_27692(class_124.field_1080)
            );

            textConsumer.accept(
                    class_2561.method_43471("tooltip.tardif_mod.linkable_item.2")
                            .method_27692(class_124.field_1080)
            );
        }
    }
}
