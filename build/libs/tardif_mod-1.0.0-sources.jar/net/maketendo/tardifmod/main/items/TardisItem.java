package net.maketendo.tardifmod.main.items;

import net.maketendo.tardifmod.main.TARDIFEntities;
import net.maketendo.tardifmod.main.entities.tardis.TardisEntity;
import net.maketendo.tardifmod.main.tardis.TardisData;
import net.maketendo.tardifmod.main.tardis.TardisManager;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import java.io.IOException;

public class TardisItem extends class_1792 {
    public TardisItem(class_1793 settings) {
        super(settings.method_7894(class_1814.field_8904));
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();

        if (!world.method_8608()) {
            class_2338 pos = context.method_8037();
            class_2680 state = world.method_8320(pos);
            class_3218 serverWorld = (class_3218) world;
            class_1657 player = context.method_8036();

            double y;

            if (context.method_8038() == class_2350.field_11036) {

                TardisEntity tardis = TARDIFEntities.TARDIS.method_5883(world, class_3730.field_16465);
                try {
                    assert tardis != null;
                    tardis.initializeTardis(serverWorld);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                TardisData data = TardisManager.getFromId(world.method_8503(), tardis.getTardisId());
                if (player != null) {
                    data.owner = player.method_5667();
                }

                double x = pos.method_10263() + 0.5;
                double z = pos.method_10260() + 0.5;

                if (state.method_26234(world, pos)) {
                    y = pos.method_10264() + 1;
                } else {
                    y = pos.method_10264();
                }

                tardis.method_5808(x, y, z, context.method_8044() - 180, 0);
                serverWorld.method_8649(tardis);

                if (!player.method_68878()) {
                    context.method_8041().method_7934(1);
                }

                player.method_7353(class_2561.method_43471("message.tardif_mod.tardis_item.created_tardis").method_27692(class_124.field_1060),true);
                return class_1269.field_5812;
            }
        }
        return class_1269.field_5811;
    }
}
