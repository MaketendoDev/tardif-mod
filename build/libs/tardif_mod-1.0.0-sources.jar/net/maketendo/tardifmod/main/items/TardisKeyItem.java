package net.maketendo.tardifmod.main.items;

import net.maketendo.tardifmod.main.items.extendable.LinkableItem;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import java.util.function.Consumer;

public class TardisKeyItem extends LinkableItem {

    private final String material;

    public TardisKeyItem(class_1793 settings, String material) {
        super(settings);
        this.material = material;
    }

    @Override
    public void method_67187(class_1799 stack, class_9635 context,
                              class_10712 displayComponent,
                              Consumer<class_2561> textConsumer, class_1836 type) {

        super.method_67187(stack, context, displayComponent, textConsumer, type);

        textConsumer.accept(class_2561.method_43473());

        textConsumer.accept(
                class_2561.method_43471("tooltip.tardif_mod.tardis_key.type")
                        .method_27692(class_124.field_1080)
        );

        textConsumer.accept(
                class_2561.method_43470(material)
                        .method_27692(class_124.field_1078)
        );
    }
}

