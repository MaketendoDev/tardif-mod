package net.maketendo.tardifmod.main;

import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.main.entities.controls.ConsoleControlEntity;
import net.maketendo.tardifmod.main.entities.tardis.TardisEntity;
import net.maketendo.tardifmod.main.entities.tardis.TardisInteriorDoorEntity;
import net.maketendo.tardifmod.main.entities.tardis.TardisPartEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class TARDIFEntities {
    private static final class_5321<class_1299<?>> TARDIS_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TARDIFMod.MOD_ID, "tardis"));

    private static final class_5321<class_1299<?>> TARDIS_INTERIOR_DOOR_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TARDIFMod.MOD_ID, "tardis_interior_door"));

    private static final class_5321<class_1299<?>> CONSOLE_CONTROL_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TARDIFMod.MOD_ID, "console_control"));

    private static final class_5321<class_1299<?>> TARDIS_PART_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TARDIFMod.MOD_ID, "tardis_part"));

    public static final class_1299<TardisEntity> TARDIS = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TARDIFMod.MOD_ID, "tardis"),
            class_1299.class_1300.method_5903(TardisEntity::new, class_1311.field_17715)
                    .method_17687(1.18f, 2.55f).method_5905(TARDIS_KEY));

    public static final class_1299<TardisInteriorDoorEntity> TARDIS_INTERIOR_DOOR = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TARDIFMod.MOD_ID, "tardis_interior_door"),
            class_1299.class_1300.method_5903(TardisInteriorDoorEntity::new, class_1311.field_17715)
                    .method_17687(0.1f, 2.3f).method_5901().method_5905(TARDIS_INTERIOR_DOOR_KEY));

    public static final class_1299<ConsoleControlEntity> CONSOLE_CONTROL = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TARDIFMod.MOD_ID, "console_control"),
            class_1299.class_1300.method_5903(ConsoleControlEntity::new, class_1311.field_17715)
                    .method_17687(0.1f, 2.3f).method_5905(CONSOLE_CONTROL_KEY));

    public static final class_1299<TardisPartEntity> TARDIS_PART = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TARDIFMod.MOD_ID, "tardis_part"),
            class_1299.class_1300.method_5903(TardisPartEntity::new, class_1311.field_17715)
                    .method_17687(0.1f, 2.5f).method_5905(TARDIS_PART_KEY));

    public static void register() {
    }
}
