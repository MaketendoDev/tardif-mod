package net.maketendo.tardifmod.utils;

import net.minecraft.class_12096;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public class CommandUtil {

    public static void runCommandAsEntity(class_1297 entity, String command) {
        if (entity.method_73183().method_8608()) return;

        class_3218 serverWorld = (class_3218) entity.method_73183();
        MinecraftServer server = serverWorld.method_8503();

        if (server == null) return;

        class_2168 source = entity.method_5671(serverWorld)
                .method_9217()
                .method_9206(class_12096.field_63208);

        try {
            server.method_3734().method_44252(source, command);
        } catch (Exception e) {
            server.method_43496(class_2561.method_43470("Failed to run command for entity: " + e.getMessage()));
        }
    }
}