package net.maketendo.tardifmod.utils;

import net.maketendo.tardifmod.main.TARDIFBlocks;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import java.util.HashMap;
import java.util.Map;

public class StainedQuartzRegistry {

    private static final Map<class_1792, class_2248> DYE_TO_BLOCK = new HashMap<>();

    public static void register() {
        DYE_TO_BLOCK.put(class_1802.field_8446, class_2246.field_10153);
        DYE_TO_BLOCK.put(class_1802.field_8298, TARDIFBlocks.DARK_GRAY_ROUNDEL);
        DYE_TO_BLOCK.put(class_1802.field_8851, TARDIFBlocks.GRAY_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8226, TARDIFBlocks.BLACK_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8264, TARDIFBlocks.RED_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8492, TARDIFBlocks.ORANGE_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8192, TARDIFBlocks.YELLOW_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8131, TARDIFBlocks.LIME_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8408, TARDIFBlocks.GREEN_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8632, TARDIFBlocks.CYAN_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8273, TARDIFBlocks.LIGHT_BLUE_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8345, TARDIFBlocks.BLUE_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8296, TARDIFBlocks.PURPLE_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8669, TARDIFBlocks.MAGENTA_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8330, TARDIFBlocks.PINK_STAINED_QUARTZ);
        DYE_TO_BLOCK.put(class_1802.field_8099, TARDIFBlocks.BROWN_STAINED_QUARTZ);
    }

    public static class_2248 getFromDye(class_1799 stack) {
        return DYE_TO_BLOCK.get(stack.method_7909());
    }
}

