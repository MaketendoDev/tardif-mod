package net.maketendo.tardifmod.utils;

import net.maketendo.tardifmod.TARDIFMod;
import net.maketendo.tardifmod.main.TARDIFBlocks;
import net.maketendo.tardifmod.main.TARDIFEntities;
import net.maketendo.tardifmod.main.entities.tardis.TardisInteriorDoorEntity;
import net.maketendo.tardifmod.main.tardis.TardisData;
import net.maketendo.tardifmod.main.tardis.TardisManager;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3485;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;

public class TardisInteriorUtil {

    public static final int SPACING = 128;

    public static class_2338 allocate(MinecraftServer server) throws IOException {
        int count = TardisManager.getTardisCount(server);

        int x = (count % 64) * (SPACING* 2 );
        int z = (count / 64) * (SPACING * 2);

        return new class_2338(x, 64, z);
    }

    public static void generate(class_3218 world, class_2338 center, TardisData data) {
        class_3485 manager = world.method_14183();
        class_3499 template = manager.method_15094(
                class_2960.method_60655(TARDIFMod.MOD_ID, "crystal")
        ).orElse(null);

        if (template == null) {
            TARDIFMod.LOGGER.error("TARDIS interior structure not found!");
            return;
        }

        class_2382 sizeVec = template.method_15160();
        class_2338 size = new class_2338(sizeVec.method_10263(), sizeVec.method_10264(), sizeVec.method_10260());

        class_2338 placementPos = center.method_10069(
                -size.method_10263() / 2,
                0,
                -size.method_10260() / 2
        );


        class_3492 placement = new class_3492();

        template.method_15172(
                world,
                placementPos,
                placementPos,
                placement,
                world.field_9229,
                2
        );

        handleMarkers(world, placementPos, size, data);
    }

    private static void handleMarkers(class_3218 world, class_2338 start, class_2338 size, TardisData data) {
        class_2338 end = start.method_10081(size).method_10069(-1, -1, -1);

        class_2338.method_10097(start, end).forEach(pos -> {
            var state = world.method_8320(pos);

            if (state.method_27852(TARDIFBlocks.INTERIOR_DOOR_GENERATOR_BLOCK)) {
                spawnTardisDoor(world, pos, state, data);
                world.method_8501(pos, class_2246.field_10124.method_9564());
            }
        });
    }


    private static void spawnTardisDoor(class_3218 world, class_2338 pos, class_2680 state, TardisData data) {
        class_2350 facing = state.method_11654(class_2741.field_12481);

        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264();
        double z = pos.method_10260() + 0.5;

        data.interiorPos = new class_243(x, y, z);

        x -= facing.method_10148() * 0.45;
        z -= facing.method_10165() * 0.45;

        float yaw = yawFromFacing(facing);

        TardisInteriorDoorEntity door =
                new TardisInteriorDoorEntity(TARDIFEntities.TARDIS_INTERIOR_DOOR, world);

        door.method_5808(x, y, z, yaw, 0);
        door.setTardisId(data.id);
        world.method_17988((int) x, (int) z, true);
        world.method_8649(door);
    }

    private static float yawFromFacing(class_2350 facing) {
        return switch (facing) {
            case field_11035 -> 180f;
            case field_11039  -> -90f;
            case field_11043 -> -180f;
            case field_11034  -> -270f;
            default -> 180f;
        };
    }

    public static boolean isInside(class_2338 origin, int radius, class_2338 pos) {
        return Math.abs(pos.method_10263() - origin.method_10263()) <= radius
                && Math.abs(pos.method_10264() - origin.method_10264()) <= radius
                && Math.abs(pos.method_10260() - origin.method_10260()) <= radius;
    }
}

