package net.maketendo.tardifmod.utils;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_259;
import net.minecraft.class_265;

public class ShapeUtil {

    private final List<class_265> shapes = new ArrayList<>();

    private ShapeUtil() {}

    public static ShapeUtil builder() {
        return new ShapeUtil();
    }

    /**
     * Add a box using position + size (Blockbench coords 0–16)
     *
     * @param x starting X
     * @param y starting Y
     * @param z starting Z
     * @param width X size
     * @param height Y size
     * @param length Z size
     */
    public ShapeUtil box(
            double x, double y, double z,
            double width, double height, double length
    ) {
        shapes.add(class_259.method_1081(
                x / 16.0,
                y / 16.0,
                z / 16.0,
                (x + width) / 16.0,
                (y + height) / 16.0,
                (z + length) / 16.0
        ));
        return this;
    }

    /**
     * Build the merged shape
     */
    public class_265 build() {
        return shapes.stream()
                .reduce(class_259.method_1073(), class_259::method_1084);
    }

    public static class_265 rotateY(class_265 shape, class_2350 direction) {
        int times = switch (direction) {
            case field_11034  -> 1;
            case field_11035 -> 2;
            case field_11039  -> 3;
            default    -> 0;
        };

        return rotateY(shape, times);
    }

    public static class_265 rotateY(class_265 shape, int times) {
        class_265 result = shape;

        for (int i = 0; i < times; i++) {
            class_265 rotated = class_259.method_1073();

            for (class_238 box : result.method_1090()) {
                rotated = class_259.method_1084(rotated,
                        class_259.method_1081(
                                1.0 - box.field_1324,
                                box.field_1322,
                                box.field_1323,
                                1.0 - box.field_1321,
                                box.field_1325,
                                box.field_1320
                        )
                );
            }

            result = rotated;
        }

        return result;
    }

}

