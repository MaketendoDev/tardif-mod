package net.maketendo.tardifmod.mixins.client;

import net.maketendo.tardifmod.main.TARDIFItems;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import net.minecraft.class_9064;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public abstract class EntityRendererMixin {

    @Inject(method = "submit", at = @At("TAIL"))
    private void renderScannerTag(
            class_10017 state,
            class_4587 poseStack,
            class_11659 collector,
            class_12075 cameraState,
            CallbackInfo ci
    ) {

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        if (!client.field_1724.method_6047().method_31574(TARDIFItems.SONIC_SCREWDRIVER) &&
                !client.field_1724.method_6079().method_31574(TARDIFItems.SONIC_SCREWDRIVER))
            return;

        if (!(client.field_1692 instanceof class_1309 living))
            return;

        int hp = Math.round(living.method_6032());
        int maxHp = Math.round(living.method_6063());

        class_2561 text = class_2561.method_43470("HP: " + hp + "/" + maxHp);

        int offset = state.field_53337 != null ? -11 : 0;

        collector.method_73482(
                poseStack,
                living.method_56072().method_55675(
                        class_9064.field_47745,
                        0,
                        living.method_36454()
                ),
                offset,
                text,
                true,
                state.field_61820,
                state.field_53332,
                cameraState
        );
    }
}