package net.maketendo.tardifmod.mixins.client;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public abstract class CameraRotateShakeMixin {

    @Shadow private float xRot;
    @Shadow private float yRot;
    @Shadow protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "setup", at = @At("TAIL"))
    private void rotateVerticalShake(class_1937 area, class_1297 focusedEntity, boolean thirdPerson,
                                     boolean inverseView, float tickProgress, CallbackInfo ci) {

        if (focusedEntity != null) return;

        float time = focusedEntity.field_6012 + tickProgress;
        float intensity = 1.0F + class_3532.method_15374(time * 0.05F) * 0.4F;

        float pitchShake =
                class_3532.method_15374(time * 0.37F) * 0.6F +
                        class_3532.method_15374(time * 0.13F) * 0.35F +
                        class_3532.method_15374(time * 0.07F) * 0.2F;

        pitchShake *= intensity;

        float yawShake =
                class_3532.method_15362(time * 0.52F) * 0.25F +
                        class_3532.method_15374(time * 0.21F) * 0.12F;

        yawShake *= intensity * 0.8F;
        yawShake += class_3532.method_15374(time * 0.017F) * 0.05F;

        this.setRotation(this.yRot + yawShake, this.xRot + pitchShake);
    }
}
