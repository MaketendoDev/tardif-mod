package net.maketendo.tardifmod.mixins.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_3532;
import net.minecraft.class_3940;
import net.minecraft.class_638;
import net.minecraft.class_677;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_677.class_678.class)
public abstract class FlashMixin extends class_3940 {

    protected FlashMixin(class_638 clientWorld, double x, double y, double z, class_1058 sprite) {
        super(clientWorld, x, y, z, sprite);
    }

    @Inject(method = "getQuadSize", at = @At("HEAD"), cancellable = true)
    private void slowBreathSize(float tickProgress, CallbackInfoReturnable<Float> cir) {
        float minSize = 3.5F;
        float maxSize = 1.5F;
        float speed = 0.02F;

        // Smooth inhale/exhale using sine mapped to 0..1
        float normalized = (class_3532.method_15374(((float)this.field_3866 + tickProgress) * speed * (float)Math.PI) + 1f) / 2f;
        float size = minSize + (maxSize - minSize) * normalized;

        cir.setReturnValue(size);
    }
}


